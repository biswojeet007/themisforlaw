<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<?php 



$file = fopen("sigmaoriginal20210217.csv","r");
while(! feof($file))
  {
  print_r(fgetcsv($file));
  }
fclose($file);
?>
</body>
</html>