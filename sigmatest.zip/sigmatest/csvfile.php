<?php 
include "sigmatest.php";
include "simple_html_dom.php";
?>


<?php
$str = strip_tags($table);
$html = str_get_html($str);
header('Content-type: application/ms-excel');
header('Content-Disposition: attachment; filename=sigma.csv');

$fp = fopen("php://output", "w");

foreach($html->find('tr') as $element)
{
        $th = array();
        foreach( $element->find('th') as $row)  
        {
            //$th [] = $row->plaintext;
        }

        //$td = array();
        foreach( $element->find('td') as $row)  
        {
           // $td [] = $row->plaintext;
        }
        !empty($th) ? fputcsv($fp, $th) : fputcsv($fp, $td);
}
?>