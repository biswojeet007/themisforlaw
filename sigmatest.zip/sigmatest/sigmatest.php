<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php

$api_url = 'https://reqres.in/api/users?per_page=20';

$json_data = file_get_contents($api_url);

$response_data = json_decode($json_data);

$user_data = $response_data->data;


$user_data = array_slice($user_data, 0, 12);
?>
        
	   $table= <table >
	        <thead>
	            <tr >
	                <th>id</th>
	                <th>email</th>
	                <th>first_name</th>
	                <th>last_name</th>
	                <th>avatar</th>
	                
	            </tr>
	        </thead>
	        <tbody> 
	         <?php
	           foreach ($user_data as $user) { ?>
			 <tr>
			 	<td><?php echo $user->id; ?></td>
	            <td><?php echo $user->email; ?></td>
	            <td><?php echo $user->first_name; ?></td>
	            <td><?php echo $user->last_name; ?></td>
	             <td><?php echo $user->avatar; ?></td>
	               </tr>         
			     <?php  } ?>
	        </tbody>

	         </table>;
              <a href="csvfile.php"> Generate csv file </a>

	</body>
	</html>