<?php 
defined("BASEPATH") or exit("no direct script allowed");
class Pagination_model extends CI_Model{
    function __construct(){
    parent::__construct();    
        $this->load->library(array('session','pagination'));
        $this->load->helper('url');
        $this->load->database();    
    }
    
    
    public function allrecord($title){
        if(!empty($title)){
            $this->db->like('post_title',$title);
        }
        $v = 1;
        $this->db->select('*');
        $this->db->from('tbl_posts');
        $this->db->where('status=',$v);
        $rs = $this->db->get();
        return $rs->num_rows();
    }


    public function data_list($limit,$offset,$title){
        if(!empty($title)){
            $this->db->like('post_title',$title);
        }
        $v1 = 1;
        $this->db->select('*');
        $this->db->from('tbl_posts');
        $this->db->where('status=',$v1);
        $this->db->order_by('post_id','desc');
        $this->db->limit($limit,$offset);
        $res = $this->db->get();
        return $res->result_array();
    }


    function highlightKeywords($text, $title) {
        $wordsAry = explode("  ", $title);
        $wordsCount = count($wordsAry);

        
        for($i=0;$i<$wordsCount;$i++) {

            $highlighted_text = "<span style='font-weight:bold;background-color: #d0ca185c;'>$wordsAry[$i]</span>";
            $text = str_ireplace($wordsAry[$i], $highlighted_text, $text);


            
        }

        return $text;
    }


}
?>