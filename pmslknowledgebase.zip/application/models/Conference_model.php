<?php
class Conference_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
        //error_reporting(E_ALL & ~E_NOTICE);
    }
    public $currency = "$";
    public $from_mail_id = "demo@dev.demopmsl.com"; // Server mail id from which mail will be forwarded
    public $company_mail_id = "demo@dev.demopmsl.com"; // Company mail id to which mail will be forwarded
    public $per_page = 10 ; //Used in Pagination => display no. of items in per page 
    public $num_links = 5; //Used in Pagination => display no. of page links in the pagination bar 
    public $costvalue = 10; //Password hashing estimated cost time
        
    /* insert record to database */
    public function insert_records($table, $insert_arr)
    {
        $insert = $this->db->insert($table, $insert_arr);
        if($insert)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    /* get records from database */
    public function get_records($fields,$table,$where='',$orderby='',$limit='',$start='')
    {
        $this->db->select($fields);
        $this->db->from($table);
        
        if($where != '') 
            $this->db->where($where); 
            
        if($orderby != '') 
            $this->db->order_by($orderby); 
        
        if($limit != '')
        {
            //if($start != '')
                $this->db->limit($limit,$start);
            //else
                //$this->db->limit($limit);
        }
        $query = $this->db->get();
        
        if($query->num_rows() > 0)
        {
            return $query->result_array();
        }
        else
        {
            return false;
        }
    }
    
    /* Join table records from database */
    public function join_records($fields,$table1,$table2,$joinon,$where='',$orderby='',$limit='',$start='')
    {
        $this->db->select($fields);
        $this->db->from($table1);
        $this->db->join($table2, $joinon);
        
        if($where != '') 
            $this->db->where($where); 
            
        if($orderby != '') 
            $this->db->order_by($orderby); 
        
        if($limit != '')
        {
            //if($start != '')
                $this->db->limit($limit,$start);
            //else
                //$this->db->limit($limit);
        }
        $query = $this->db->get();
        
        if($query->num_rows() > 0)
        {
            return $query->result_array();
        }
        else
        {
            return false;
        }
    }
    
    /*COUNT AUTO COMPLETE RESULT SET START*/
     public function GetRow($post_tag) {        
        $this->db->order_by('tag_id', 'DESC');
        $this->db->like("tag_name", $post_tag);
        return $this->db->get('tbl_tags')->result_array();
    }

    /*COUNT AUTO COMPLETE RESULT SET END*/

    /* count no. of record from database */
    public function noof_records($fields,$table,$where='')
    {
        $this->db->select($fields);
        $this->db->from($table);
        
        if($where != '') 
            $this->db->where($where);
            
        $query = $this->db->get();
        
        if($query->num_rows() > 0)
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }   
        
    /* delete record from database */
    public function delete_records($table, $where)
    {
        $this->db->where($where);
        $delquery = $this->db->delete($table);
        if($delquery) 
        {
            return true;
        }
        else
        {
            return false;
        }
    }

     public function delete_pic($fields,$table, $where)
    {
        $this->db->select($fields);
        $this->db->from($table);
        $this->db->where($where);
        $delquery = $this->db->delete($table);
        if($delquery) 
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    /* update record in database */
    public function update_records($table, $fields, $where)
    {
        $this->db->where($where);
        $query = $this->db->get($table);
        
        if($query->num_rows() > 0)
        {
            $this->db->where($where);
            $update = $this->db->update($table, $fields);
            if($update)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }   
    
    /* populate selectbox from database */
    public function populate_select($dispid=0,$fid,$fname,$table,$where='',$orderby='',$joininfid='')
    {
        $this->db->select($fid);
        $this->db->select($fname);
        $this->db->from($table);
        
        if($where != '')
            $this->db->where($where);
        
        if($orderby != '')
            $this->db->order_by($orderby);
        
        $query = $this->db->get();
        if($query->num_rows() > 0)
        {
            $options = '';
            $rows = $query->result_array();
            foreach ($rows as $row)
            {
                $selectid = $row[$fid];
                if($joininfid != '')
                    $selectid = $selectid.'__'.$joininfid;
                
                $selectname = $row[$fname];
                if($selectid == $dispid)
                    $options .= "<option value=\"$selectid\" selected>$selectname</option>";
                else
                    $options .= "<option value=\"$selectid\">$selectname</option>";
            }
            return $options;
        }
        else
        {
            return false;
        }
    }
    
    /* show name from an id */
    public function showname_fromid($field,$table,$where='')
    {
        $this->db->select($field);
        $this->db->from($table);
        
        if($where != '') 
            $this->db->where($where);
             
        $query = $this->db->get();
        
        if($query->num_rows() > 0)
        {
            $row = $query->row();
            return $row->$field;
        }
        else
        {
            return false;
        }
    }


    
    
    /* populate number combo box */
    public function generate_numberbox($startval,$endval,$shwval=0,$intvl=1)
    {
        $showDetails = '';
        for ($i=$startval; $i<=$endval; $i=$i+$intvl)
        {
            if($shwval == $i)
                $showDetails .= "<OPTION value=\"$i\" selected>$i</OPTION>"; 
            else
                $showDetails .= "<OPTION value=\"$i\">$i</OPTION>";
        }
        return $showDetails;
    }
    
    /** Short String Cut **/
    public function short_str($inputstring, $char=100)
    {
        $inputstring = strip_tags($inputstring);
        $inputstring = trim(preg_replace('/\s+/', ' ', $inputstring));
        if( strlen( $inputstring) > $char) {
            $string = explode( "\n", wordwrap( $inputstring, $char));
            $inputstring = $string[0] . '...';
        }
        return $inputstring;
    }
    
    public function truncate($string, $length=100, $append="&hellip;") {
        $string = trim($string);

        if(strlen($string) > $length) {
            $string = wordwrap($string, $length);
            $string = explode("\n", $string, 2);
            $string = $string[0] . $append;
        }
        return $string;
    }
    
    /** Display Price **/
    public function numberformat($price)
    {
        if( $price > 0 )
            return number_format($price,0,"",",");
        else
            return $price;
    }

    /* Display Date */
 public function dateformat($date)
 {
  if($date != "")
   return date('dS M Y',strtotime($date));
  else
   return $date;
 }
    
    /** Remove White Space and replace with Underscore **/
    public function remove_whitespace($str)
    {
        return preg_replace('/\s+/', '_', trim($str));  
    }
    
    public function remove_underscore($str)
    {
        return str_replace('_', ' ', trim($str));   
    }
    
    /** Encode & Decode **/
    public function encode($str)
    {
        return base64_encode($str);
    }
    public function decode($str)
    {
        return base64_decode($str);
    }
    
    /* get distinct records from database */
    public function get_distinctrecords($fields,$table,$where='',$orderby='',$limit='',$start='')
    {
        $this->db->distinct();
        $this->db->select($fields);
        $this->db->from($table);
        
        if($where != '') 
            $this->db->where($where); 
            
        if($orderby != '') 
            $this->db->order_by($orderby); 
        
        if($limit != '')
        {
            //if($start != '')
                $this->db->limit($limit,$start);
            //else
                //$this->db->limit($limit);
        }
        $query = $this->db->get();
        
        if($query->num_rows() > 0)
        {
            return $query->result_array();
        }
        else
        {
            return false;
        }
    }

     
    
    /* get groupby records from database */
    public function get_groupbyrecords($groupbycol,$fields,$table,$where='',$orderby='',$limit='',$start='')
    {
        $this->db->select($fields);
        $this->db->group_by($groupbycol);
        $this->db->from($table);
        
        if($where != '') 
            $this->db->where($where); 
            
        if($orderby != '') 
            $this->db->order_by($orderby); 
        
        if($limit != '')
        {
            //if($start != '')
                $this->db->limit($limit,$start);
            //else
                //$this->db->limit($limit);
        }
        $query = $this->db->get();
        
        if($query->num_rows() > 0)
        {
            return $query->result_array();
        }
        else
        {
            return false;
        }
    }
    
    /* group by count no. of record from database */
    public function noof_recordsgrpby($groupbycol,$fields,$table,$where='')
    {
        $this->db->select($fields);
        $this->db->group_by($groupbycol);
        $this->db->from($table);
        
        if($where != '') 
            $this->db->where($where);
            
        $query = $this->db->get();
        
        if($query->num_rows() > 0)
        {
            return $query->num_rows();
        }
        else
        {
            return 0;
        }
    }

        /* Display random password */
        function randomPassword() {
            $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
            $pass = array(); //remember to declare $pass as an array
            $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
            for ($i = 0; $i < 8; $i++) {
                $n = rand(0, $alphaLength);
                $pass[] = $alphabet[$n];
            }
            return implode($pass); //turn the array into a string
        }

     function makeSeoUrl($url) {
        if ($url) {
            $url = trim($url);
            $value = preg_replace("![^a-z0-9]+!i", "-", $url);
            $value = trim($value, "-");
            return strtolower($value);
        }
    }

    function getRealIpAddr() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {   //check ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {   //to check ip is pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
    }
    
}
