<?php
$ret_pos = $this->Conference_model->get_records("*","tbl_comments");
if(!empty($ret_pos)){
foreach ($ret_pos as $keyuu) {
  $pos = $keyuu['post_id'];
  $use = $keyuu['user_id'];
  //echo $pos.'P--->U'.$use;

 }
 
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>PMSL</title>
         <?php include('head.php'); ?>
    </head>
    <body>

         <?php include('header1.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">

            <section class="home-body-sec">
                <div class="container">
                   <?php include('sidebar.php'); ?>
                    <div class="right-sec">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <h1 class="">Recent Activity </h1>
                                <?php echo $message;?>
                                <div class="add-txt-sec single-sec">


                                    <div class="clearfix"></div>



                                    <div class="activity-question-answer-list ">
                        <?php
                         $userid = $this->session->userdata('userid');
                          $noof_r = $this->Conference_model->noof_records("cmt_id","tbl_comments","user_id='$userid'");

                        ?>
                      <div class="activity-title">Recent Answers <?php //(echo $noof_r; )?></div>
                                        <ul>
                                          <!--- ALL QUESTION AND ANSWER SECTION DETAILS START -->	
                                         <?php
                                          
                                        //$data['row'] = $this->Conference_model->get_records("*","tbl_posts","user_id='$userid'","post_id ASC","$per_page","$startfrom");
                                          $rec_noffy = $this->db->query("SELECT COUNT( DISTINCT post_id) AS U FROM `tbl_comments` WHERE user_id='".$userid."' ORDER BY post_id DESC"); 
                            $rec_qgh = $rec_noffy->result(); 
                            if(!empty($rec_qgh)){
                              foreach ($rec_qgh as $gen) {
                                $selpoi = $gen->U;

                              }

                            }
                               

                          $config['base_url'] = base_url().'comment-details/page/';
                          $config['first_url'] = base_url().'comment_details';
                          $config["uri_segment"] = 3;
                          $config['total_rows'] = $selpoi;
                          $config['per_page'] = $this->Conference_model->per_page;
                          $config["num_links"] = $this->Conference_model->num_links;
                          $config["use_page_numbers"] = TRUE;
                          //config for bootstrap pagination class integration
                          $config['full_tag_open'] = '<ul class="pagination">';
                          $config['full_tag_close'] = '</ul>';
                          $config['first_link'] = "&laquo First";
                          $config['last_link'] = "Last &raquo";
                          $config['first_tag_open'] = '<li  class="page-item ">';
                          $config['first_tag_close'] = '</li>';
                          $config['prev_link'] = 'Prev';
                          $config['prev_tag_open'] = '<li class="page-item">';
                          $config['prev_tag_close'] = '</li>';
                          $config['next_link'] = 'Next';
                          $config['next_tag_open'] = '<li  class="page-item">';
                          $config['next_tag_close'] = '</li>';
                          $config['last_tag_open'] = '<li  class="page-item">';
                          $config['last_tag_close'] = '</li>';
                          $config['cur_tag_open'] = '<li class="page-item active"><a href="#">';
                          $config['cur_tag_close'] = '</a></li>';
                          $config['num_tag_open'] = '<li  class="page-item">';
                          $config['num_tag_close'] = '</li>';
                          $this->pagination->initialize($config);

                          $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
                          $per_page = $config["per_page"];
                          $startm = $page;
                          if($page>1)
                          $startm = $page-1;
                          $startfrom = $per_page*$startm;
                          $data['startfrom'] = $startfrom;
                          $data['pagination'] = $this->pagination->create_links(); 
                          


//$data['row'] = $this->Conference_model->get_records("*","tbl_comments","user_id='$userid'","post_id DESC","$per_page","$startfrom");
                         //PAGINATION BLOCK END                
                          $rec_dcmt = $this->db->query("SELECT DISTINCT `post_id` FROM `tbl_comments` WHERE `user_id`='".$userid."' ORDER BY `post_id` DESC LIMIT $per_page OFFSET $startfrom ");
                            $rec_exicute = $rec_dcmt->result();
                            if(!empty($rec_exicute)){
                            foreach ($rec_exicute as $podeta) {
                            	$post_id = $podeta->post_id;
                              $fff_poid = base64_encode($post_id);


$rec_qu = $this->db->query("SELECT DISTINCT `post_title`,`posted_date` FROM `tbl_posts` WHERE  post_id='".$post_id."' ORDER BY `post_id` DESC "); 
                            $rec_ques = $rec_qu->result();
                            	
                            //	$rec_ques = $this->Conference_model->get_records("*","tbl_posts","post_id='$post_id'");
                            	if(!empty($rec_ques)){
                                   foreach ($rec_ques as $postdetails) {
                                   	$post_titles = $postdetails->post_title;
                                   	$posted_dates = $postdetails->posted_date;
                                   	$final_posteddate = date('d.m.Y' , strtotime($posted_dates));

                            //$rec_commde = $this->Conference_model->get_records("*","tbl_comments","user_id='$userid' and post_id='$post_id'","cmt_id DESC");  

                            $rec_com = $this->db->query("SELECT DISTINCT `user_cmt`,`commented_date` FROM `tbl_comments` WHERE `user_id`='".$userid."' AND post_id='".$post_id."' ORDER BY `cmt_id` DESC   "); 
                            $rec_commde = $rec_com->result();

        
                          ?>
                                            <li>
                                                
                                                <a href="<?php echo base_url() . 'home/post/'.$fff_poid; ?>"><?php echo $post_titles;?> </a>
                                            
                                            <div class="activity-date"> <i class="fa fa-calendar-alt"></i> <?php echo $final_posteddate;?></div>
                                            <?php
                                            if(!empty($rec_commde)){
                            	            foreach ($rec_commde as $commentdetails) {
				                            		$cmt_user = $commentdetails->user_cmt;
				                            		$cmt_date = $commentdetails->commented_date;
				                            		$final_commenteddate = date('d.m.Y' , strtotime($cmt_date));
                                                    

                                            ?>




                                                <div class="activity-question-answer"> 
                                                   <?php echo $cmt_user; ?>
                                                    <div class="activity-date mtp10"> <i class="fa fa-calendar-alt"></i>  <?php echo $final_commenteddate;?></div>
                                                </div>
                                             <?php
                                               }
                                              }
                                             ?>

                                            </li>
                                            <?php
         
                                             }

                            	            }
                                           }
                                          } 

                                           ?>
                                             <!--- ALL QUESTION AND ANSWER SECTION DETAILS END -->

                                        </ul>

                                   

                                    </div>
                           
                                   <div class="user-pagination" style="float: right;">                                        
                                                <?php print_r($data['pagination']); ?>
                                  </div>
                                    
                                </div>


  


                            </div>


                        </div>
                    </div>
                </div>
                <!--- SECOND MODAL FOR EDIT START  -->
        <div class="modal" id="myMod">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">

                    <!-- Modal Header -->
                    
                </div>
            </div>
        </div>
        <!--- SECOND MODAL FOR EDIT END --->
            </section>
            <div class="clearfix"></div>

        </div>
        <?php include('footer.php'); ?>
        <script type="text/javascript">
        	//url: "<?php //echo base_url(); ?>activity/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity,
       
    function likedislikesave(employeeid,jobid,activity,currentactivity = "")
          {
    var base_url = "";      	
	var currentactivity = $("#curractivity_"+jobid).val();
         //var url= "<?php //echo base_url(); ?>activity/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity;
		$.ajax({
			url:"<?php echo base_url(); ?>comment_details/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity,
			success:function(result)
			{
				location.href = location.href;
				
				if(result=="new1") {
					$("#curractivity_"+jobid).val("1");
					$('#likefrs_'+jobid).css({'color':'green'});
					$('#dislikefrs_'+jobid).css({'color':''});
				}
				else if(result=="new2") {
					$("#curractivity_"+jobid).val("2");
					$('#likefrs_'+jobid).css({'color':''});
					$('#dislikefrs_'+jobid).css({'color':'red'});
				}
				else if(result=="updt1") {
					$("#curractivity_"+jobid).val("");
					$('#likefrs_'+jobid).css({'color':''});
				}
				else if(result=="updt2") {
					$("#curractivity_"+jobid).val("");
					$('#dislikefrs_'+jobid).css({'color':''});
				}
				
			}
		});
	
 }

       
</script>
        <script type="text/javascript">
$(document).on('click', '.edit', function(){
    jQuery('#myMod .modal-content').html('<div style="text-align:center;margin-top:150px;margin-bottom:100px;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-3x"></i> <span>Processing...</span></div>');
    var val = $(this).data("id");
    
    $.ajax({
        url: "<?php echo base_url(); ?>comment_details/post_pop/"+val,
        type: 'post',
        cache: false,
        
        processData: false,
        success: function (modal_content) {
            jQuery('#myMod .modal-content').html(modal_content);
            // LOADING THE AJAX MODAL
            $('#myMod').modal('show');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
            $('#errMessaged').html('<div class="errormsg"><i class="fa fa-times"></i> Your query could not executed. Please try again.</div>');
        }
    });
});

</script>
<!---	VOTING JS START ---->


<!--- VOTING JS END --->

    </body>
</html>
<script type="text/javascript">
$(document).ready(function(){ 
$("#rev").on('click',function(){
  var hides = $("#h_id").val();
  console.log(hides);
});  

});
</script>