<!DOCTYPE html>

<html>
    <head>
        <title>PMSL</title>
        <?php include('head.php'); ?>
        <style type="text/css">
            .cld{
             color:green;
            }
            .rld{
                color: red;
            }
        </style>
    </head>
    <body>

        <?php include('header.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">

            <section class="home-body-sec">
                <div class="container">
                    <?php include('sidebar.php'); ?>
                    <div class="right-sec">
                        <div class="row">
                            <div class="col-xl-9 col-lg-9">
                                <h1 class="">All Tags</h1>
                               
                                <div class="add-txt-sec">
                                    
                                       <div class="clearfix"></div> 
                                
                                           <div class="row">
                                            <?php
                                            $cnt = 0;
                                            if(!empty($rowdk)){
                                                foreach ($rowdk as $ke) {
                                                   $tag_name = $ke['tag_name'];
                                                   $cnt = $cnt+1;
                                                   $tag_id = $ke['tag_id'];
                                                   $fff_tagid = base64_encode($tag_id);

                                                   $rec_tblpost = $this->Conference_model->noof_records("post_id","tbl_post_tags","tag_id='$tag_id'");
                                           
                                            
                                            ?>
                                    <?php if($rec_tblpost>0){ ?>
<div class="col-xl-3"><div class="tag-new-sec"> <a href="<?php echo base_url() . 'tags/tagrelated-ques/'.$tag_name.'/'.$fff_tagid; ?>" title="Browse other questions tagged">
                                  <?php echo $tag_name; ?></a> (<?php echo $rec_tblpost; ?>)</div></div>
                                  <?php }else{?>
                                  <?php } ?>
                                 <?php  if($cnt%4=='0') { echo '<div class="clearfix"></div>'.'<hr>'; } ?>


                                            <?php
                                              
                                              }

                                            }
                                            ?>  
                                            </div>
                                       
                                </div>

                                

                                
                                    <div class="clearfix"></div>

                                

                            </div>

                             

                             <?php include('rsidebar.php'); ?>
                        </div>
                    </div>
                </div>


       

            </section>
            <div class="clearfix"></div>

        </div>
        <?php include('footer.php'); ?>
        
 </body>
</html>

