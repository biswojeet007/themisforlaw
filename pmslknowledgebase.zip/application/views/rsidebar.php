                               <div class="col-xl-3 col-lg-3">
                                <div class="right-inr-sec">
                                    <div class="right-inr-heading">Most Searched </div>
                                    <div class="right-inr-list mbt30">
                                        <ul>
                                            <?php
                                            $stvar = 1;
                                            $rec_post = $this->Conference_model->get_records("*","tbl_posts","status='$stvar'","noof_views DESC","9");
                                            if(!empty($rec_post)){
                                            foreach($rec_post as $row){
                                                $post_title = $row['post_title'];
                                                $post_id = $row['post_id'];
                                                $f_poid = base64_encode($post_id);
                                            
                                            ?>
                                            <li><a href="<?php echo base_url() . 'home/post/'.$f_poid; ?>"><?php echo $post_title; ?> </a></li>
                                            <?php } ?>
                                         <?php } ?>


                                        </ul>
                                    </div>
                                    <div class="right-inr-adv">
                                        <img src="<?php echo base_url(); ?>assets/images/advertise-with-us.JPG" alt="" class="img-fluid"/>
                                    </div>
                                </div>
                            </div>