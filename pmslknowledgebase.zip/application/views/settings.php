<?php

/* Google App Client Id */
define('CLIENT_ID', '765483819703-kugs6ou0ktvsdui0nf3csp4mihajmlka.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'H0_p1yaMi9xdCKp7ASuvEuEd');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://demopmsl.com/pmslknowledgebase/gauth');

?>