<?php
$ret_pos = $this->Conference_model->get_records("*","tbl_comments");
if(!empty($ret_pos)){
foreach ($ret_pos as $keyuu) {
  $pos = $keyuu['post_id'];
  $use = $keyuu['user_id'];
  //echo $pos.'P--->U'.$use;

 }
 
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>PMSL</title>
         <?php include('head.php'); ?>
    </head>
    <body>

         <?php include('header1.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">

            <section class="home-body-sec">
                <div class="container">
                   <?php include('sidebar.php'); ?>
                    <div class="right-sec">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <h1 class="">Recent Activity </h1>
                                <?php echo $message;?>
                                <div class="add-txt-sec single-sec">


                        <?php 
                        $userid = $this->session->userdata('userid');
                        $noof_rec = $this->Conference_model->noof_records("post_id","tbl_posts","user_id='$userid'");
                        ?>
                                    <div class="activity-title">Recent Questions <?php //echo '('.$noof_rec.')';?></div>
                                    <?php
                                    if(!empty($row)){
                                    foreach ($row as $rows) {
                                             $post_title = $rows['post_title'];
                                             $post_id = $rows['post_id'];
                                             $f_poid = base64_encode($post_id);
                                             $posted_date = $rows['posted_date'];
                                             $f_date =  date('d.m.Y' , strtotime($posted_date));
                                             $ques_status = $rows['status'];
                                           $noof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","post_id='$post_id' and status='1'");
                                           $sess_userid = $this->session->userdata('userid');
                                           $deliuid = $this->Conference_model->showname_fromid("user_id","tbl_posts","post_id='$post_id'");
                                       
                                    ?>

                                    <div class="add-txt-sec">
                                        <h4> <a href="<?php echo base_url() . 'home/post/'.$f_poid; ?>">
                                   <?php if($post_title==''){ }else{echo $post_title;}?> </a></h4>
                                   <!---<div class="cmt_edit_del">
                                              <ul>
                                               
                                                 </ul> 
                                            </div>--->
                                        <div class="add-list">
                                        	<!--- VOTING START --->
                                        	<?php 
                                                $dynlkdislksave = $this->Conference_model->showname_fromid("voting","tbl_post_voting","vpost_id='$post_id' and vuserid='$userid' and voting in(1,2)");
													$likestyle=''; $dislikestyle=''; 
													if($dynlkdislksave==1) {
														$likestyle = "style='color:green;'";
													} else if($dynlkdislksave==2) {
														$dislikestyle = "style='color:red;'";
													}
											 $noof_vots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$post_id' and voting='1'");  

                                    $noof_unvots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$post_id' and voting='2'");		
													
                                        	?>
                                        	<!-- VOTING END --->

				
                                            <ul>
                                                <li>  <a href="javascript:void(0);"> <i class="fa fa-calendar-alt"></i> <?php echo $f_date;?> </a></li>
                                                <li>  <a href="javascript:void(0);"> <i class="fas fa-eye"></i> <?php echo ($rows['noof_views'] > 0) ? $rows['noof_views'] : '0' ;?>  views </a></li>
                                               <!-- <li><a href="javascript:void(0);"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>--->
                                               <li><a href="javascript:void(0)" onClick="likedislikesave('<?php echo $userid;?>','<?php echo $post_id;?>','1')"><i class="fas fa-thumbs-up" <?php echo $likestyle;?> id="likefrs_<?php echo $post_id;?>"></i> <?php echo $noof_vots.' Votes ';?> </a></li>
                                                <!--<li><a href="javascript:void(0);"><i class="fas fa-thumbs-down"></i> 01 Vote </a></li>--->
                                             <li> <a href="javascript:void(0)" onClick="likedislikesave('<?php echo $userid;?>','<?php echo $post_id;?>','2')"><i class="fas fa-thumbs-down" <?php echo $dislikestyle;?> id="dislikefrs_<?php echo $post_id;?>"></i> <?php echo $noof_unvots.' Downvotes ';?> </a></li>
                                             
                                            <input type="hidden" name="curractivity_<?php echo $post_id; ?>" id="curractivity_<?php echo $post_id; ?>" value="<?php echo $dynlkdislksave;?>">


                                                <li> <a href="javascript:void(0);"><i class="fas fa-reply"></i> <?php echo  $noof_rec.' Answer' ?></a></li>
                                                <?php if($ques_status==1){ ?>
                                                <li><a href="javascript:void(0);"><i class="fas fa-trophy"></i> Active </a></li>
                                                <?php }else{ ?>
                                                <li><a href="javascript:void(0);"><i class="fas fa-trophy"></i> Inactive </a></li>
                                                <?php } ?>

                                                <?php if($sess_userid === $deliuid){ ?> 

                                                    <li class="view-link-sec"><a href="javascript:void(0);" data-id="<?php echo $post_id; ?>" class="btn btn-primary btn-sm edit" 
                                                               title="Edit Question" data-toggle="modal" data-target="#myMod"><i class="fas fa-edit"></i></a></li>

                                                    <li class="view-link-sec"> <a onClick="return confirm('Are you sure to delete this Post?')" href="<?php echo base_url() . 'activity/posttdel/' . $post_id; ?>" class="btn btn-danger btn-sm tbl-icon-btm" title="Delete Question"><i class="far fa-trash-alt"></i></a></li> 

                                                    <?php }else{ ?> 

                                                  <?php } ?>

                                            </ul>
                                            
                                        </div>
                                    </div>
                                    <?php } ?>
                                <?php } ?>

                               
                                     <div class="user-pagination" style="float: right;">                                        
                                                <?php echo $pagination; ?>
                                  </div>

                                    <div class="clearfix"></div>



                                    
                                    
                                </div>





                            </div>


                        </div>
                    </div>
                </div>
                <!--- SECOND MODAL FOR EDIT START  -->
        <div class="modal" id="myMod">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">

                    <!-- Modal Header -->
                    
                </div>
            </div>
        </div>
        <!--- SECOND MODAL FOR EDIT END --->
            </section>
            <div class="clearfix"></div>

        </div>
        <?php include('footer.php'); ?>
        <script type="text/javascript">
        	//url: "<?php //echo base_url(); ?>activity/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity,
       
    function likedislikesave(employeeid,jobid,activity,currentactivity = "")
          {
    var base_url = "";      	
	var currentactivity = $("#curractivity_"+jobid).val();
         //var url= "<?php //echo base_url(); ?>activity/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity;
		$.ajax({
			url:"<?php echo base_url(); ?>activity/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity,
			success:function(result)
			{
				location.href = location.href;
				
				if(result=="new1") {
					$("#curractivity_"+jobid).val("1");
					$('#likefrs_'+jobid).css({'color':'green'});
					$('#dislikefrs_'+jobid).css({'color':''});
				}
				else if(result=="new2") {
					$("#curractivity_"+jobid).val("2");
					$('#likefrs_'+jobid).css({'color':''});
					$('#dislikefrs_'+jobid).css({'color':'red'});
				}
				else if(result=="updt1") {
					$("#curractivity_"+jobid).val("");
					$('#likefrs_'+jobid).css({'color':''});
				}
				else if(result=="updt2") {
					$("#curractivity_"+jobid).val("");
					$('#dislikefrs_'+jobid).css({'color':''});
				}
				
			}
		});
	
 }

       
</script>
        <script type="text/javascript">
$(document).on('click', '.edit', function(){
    jQuery('#myMod .modal-content').html('<div style="text-align:center;margin-top:150px;margin-bottom:100px;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-3x"></i> <span>Processing...</span></div>');
    var val = $(this).data("id");
    
    $.ajax({
        url: "<?php echo base_url(); ?>activity/post_pop/"+val,
        type: 'post',
        cache: false,
        
        processData: false,
        success: function (modal_content) {
            jQuery('#myMod .modal-content').html(modal_content);
            // LOADING THE AJAX MODAL
            $('#myMod').modal('show');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
            $('#errMessaged').html('<div class="errormsg"><i class="fa fa-times"></i> Your query could not executed. Please try again.</div>');
        }
    });
});

</script>
<!---	VOTING JS START ---->


<!--- VOTING JS END --->

    </body>
</html>
<script type="text/javascript">
$(document).ready(function(){ 
$("#rev").on('click',function(){
  var hides = $("#h_id").val();
  console.log(hides);
});  

});
</script>