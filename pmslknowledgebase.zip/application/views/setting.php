<?php
$sess_uid = $this->session->userdata('userid');
$row = $this->Conference_model->get_records("*", "tbl_user", "user_id='$sess_uid'");
if(!empty($row)){
foreach ($row as $rows) {
    $userid = $rows['user_id'];
    $name = $rows['username'];
    $email = $rows['user_email'];
    $password = $rows['password'];
    $title = $rows['user_title'];
    $desc = $rows['user_desc'];
    $pic = $rows['user_pic'];
 }
} 
?>
<!DOCTYPE html>
<html>
    <head>
        <title>PMSL</title>
        <?php include('head.php'); ?>
    </head>
    <body>

        <?php include('header1.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">

            <section class="home-body-sec">
                <div class="container">
                    <?php include('sidebar.php'); ?>
                    <div class="right-sec">
                        <div class="row">
                            <div class="col-xl-12 col-lg12">
                                <h1 class=""> Setting</h1>
                                <?php echo $message; ?>
                                <form class="setting-form" name="setting-form" id="setting-form" method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6">
                                            <div class="setting-fld-sec ">
                                                <label> Profile Name</label>
                                                <input type="text" class="setting-fld" name="name" value="<?php if(!empty($name)){ echo set_value('name', $name); } ?>" placeholder="">
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6">
                                            <div class="setting-fld-sec">
                                                <label> Title</label>
                                                <input type="text" class="setting-fld" name="title" value="<?php if(!empty($title)){ echo set_value('title', $title); } ?>" placeholder="">
                                            </div>
                                        </div>


                                        <div class="col-xl-6 col-lg-6">
                                            <div class="setting-fld-sec">
                                                <label> Email Id</label>
                                                <input type="text" class="setting-fld" name="email" value="<?php if(!empty($email)){ echo set_value('email', $email); } ?>" placeholder="">
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6">
                                            <div class="setting-fld-sec">
                                                <label> Password</label>
                                                <input type="password" class="setting-fld" name="password" placeholder="">
                                            </div>
                                        </div>

                                        <div class="col-xl-12 col-lg-12">
                                            <div class="setting-fld-sec">
                                                <label> Image Upload</label>
                                                <div class="row">
                                                    <div class="col-xl-8 col-lg-8">
                                                        <div class="setting-fld">
                                                            <input type="file" name="user_pic"  class="flie-upload">
                                                        </div>
                                                    </div>
                            <?php if(!empty($pic) && file_exists("./assets/images/".$pic) && ($pic!='')){ ?> 
                                        <div class="col-xl-4 col-lg-4" id="xyz">
                                                 
                                                       <div class="file-upload-img" >
                                                            <img  alt="photo" src="<?php echo base_url() . 'assets/images/' . $pic; ?>" class="img-fluid" />

                       <input title="Delete" type="button" name="imgdelete" id="imgdelete" class="buttondel" onClick="removethispic('<?php echo $userid; ?>','<?php echo $pic; ?>');">
                                                        </div>
                                                    
                                                      
                                                    </div>
                                         <?php } ?>
                                                </div>

                                                <div id="error_user_pic"></div>


                                            </div>
                                        </div>

                                        <div class="col-xl-12 col-lg-12">
                                            <div class="setting-fld-sec">
                                                <label> Short Description</label>
                                                <textarea class="setting-fld text-area-height" name="description" placeholder=""><?php if(!empty($desc)){ echo set_value('description', $desc); } ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-12">
                                            <button class="setting-submit" name="set_submit">Submit</button>
                                        </div>


                                    </div>
                                </form>


                            </div>


                        </div>
                    </div>
                </div>
            </section>
            <div class="clearfix"></div>

        </div>
        <?php include('footer.php'); ?>
        
<script type="text/javascript"> 

function removethispic(id, img)
{
var con = confirm("Are you Sure to delete this image ?");

if (con)
  {
$.ajax
     ({
    type: "POST",
    url: "<?php echo base_url() . 'setting/deletegalleyimages'; ?>",
    data: "delid=" + id + "&delimg=" + img,
    success: function (html)
     {
    alert(html);

     $('#xyz').remove();
     $('#xyz').css({"display":"none !important"});
    
   }

  });

  } //else
      //{
    //alert('Thanks');
    //return false;
    //}
   }        
</script>

    </body>
</html>


