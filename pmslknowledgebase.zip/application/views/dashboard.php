<!DOCTYPE html>

<html>
    <head>
        <title>PMSL</title>
        <?php include('head.php'); ?>
    </head>
    <body>

       <?php include('header1.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">

            <section class="home-body-sec">
                <div class="container">
                    <?php include('sidebar.php'); ?>
                    <div class="right-sec">
                        <div class="row">
                            <div class="col-xl-9 col-lg-9">
                                <h1 class=""> Main Heading</h1>
                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>


                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="add-txt-sec">
                                    <h4> <a href="#">How to edit entity and add pagination in Jhipster generated project </a></h4>
                                    <div class="add-list">
                                        <ul>
                                            <li>  <a href="#"> <i class="fas fa-eye"></i> 90 View </a></li>
                                            <li><a href="#"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                            <li> <a href="#"><i class="fas fa-reply"></i> 05 Answer </a></li>
                                        </ul>
                                    </div>
                                </div>















                            </div>

                            <?php include('rsidebar.php'); ?>
                        </div>
                    </div>
                </div>
            </section>
            <div class="clearfix"></div>

        </div>
        <?php include('footer.php'); ?>


    </body>
</html>
