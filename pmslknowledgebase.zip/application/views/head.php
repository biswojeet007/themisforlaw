<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel=icon href="<?php echo base_url();?>images/fav-icon.png" sizes="16x16" type="image/png">
<link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url();?>assets/fonts/fontawesome/css/fontawesome-all.css" rel="stylesheet" type="text/css"/>
<link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url();?>assets/css/bootstrap-datepicker3.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/droopmenu.css">
<link href="<?php echo base_url();?>assets/css/scssstyle.css?v=1.1" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url();?>assets/style.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo base_url();?>assets/chat.css" rel="stylesheet" type="text/css"/>