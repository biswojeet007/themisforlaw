                    <div class="left-sec">
                        <div class="left-menu-list">
                            <ul>
                                <li  > <a href="<?php echo base_url();?>" class="active"> Home</a></li>
                                <li> <a href="https://pmsltech.com/about-us"> About Us</a></li>
                                <li> <a href="#"> Service</a></li>
                                <li> <a href="https://pmsltech.com/contact-us"> Contact Us</a></li>
                            </ul>
                        </div>
                        <div class="left-adv mtp30">
                            <img src="<?php echo base_url();?>assets/images/advertise.jpg" alt="" class="img-fluid"/>
                        </div>
                    </div>