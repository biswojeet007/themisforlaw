<!DOCTYPE html>

<html>
    <head>
       <?php include("head.php"); ?>
    </head>
    <body>

       <?php include("header.php"); ?>

       <div class="min-height">

            <section class="home-body-sec" >

                <div class="container">
                    <div class="text-center pmsl-thnx">
                       <?php
                    if($message == "success")
                    {
                    ?>
                        <h1>Congratulation!</h1>
                        <h6 class="successmsg"><i class="fa fa-check"></i> Your email id is successfully verified.</h6>
                    <?php
                    }
                    else if($message == "error")
                    {
                    ?>
                        <h1>SORRY!</h1>
                        <h4 class="errormsg"><i class="fa fa-times"></i> Unable to process your request.</h4>
                    <?php
                    }
                    ?>
                    <div class="col-sm-12 controls"><a href="<?php echo base_url();?>login" class="sign-up-btm">Click here to login your account.</a></div>
                    </div>


                </div>

            </section>

          </div>

        
            <?php include("footer.php"); ?>
       


        
    </body>
</html>
