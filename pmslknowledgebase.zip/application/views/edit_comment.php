<?php
foreach ($tagnmm as $rows)
{
    
    $post_id = $rows['post_id'];
    $userd_id = $rows['user_id'];
    $post_title = $rows['post_title'];
    $post_desc = $rows['post_desc'];
    $status = $rows['status'];
    $rect_user = $this->Common_model->showname_fromid("username","tbl_user","user_id='$userd_id'");

    $rec_user = $this->Common_model->showname_fromid("user_email","tbl_user","user_id='$userd_id'");
    
}

?>


<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
         <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/jquery-ui.css">
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-sticky-note"></i>
                            <h1>Edit Posts </h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/posts" class="adduser"> Manage Posts</a>
                                <div class="add-line"></div>
                                <div class="row">
                                    <?php echo $message;  ?>
                                    <div id="existagmsg"></div>
                                    <div class="col-xl-12 col-lg-12"> 
                                        <form class="add-user" name="edited_post" id="edited_post"  method="post">
                                            <div class="row">
                                                

                                                <div class="col-xl-6 col-lg-6 "> 

                                                    <div class="form-group">
                                                        <label>Title</label>
                                                    <input type="text" class="form-control fld" placeholder="Enter Country" name="post_title" id="post_title" value="<?php echo set_value('post_title' ,$post_title); ?>">
                                                        
                                                    </div>

                                                </div>

                                                <!--- TAGGING START --->
                                              <div class="col-xl-6 col-lg-6 "> 

                                                    <div class="form-group">
                                                        <label>Tags</label>
                                                   <!-- <input type="text" class="form-control fld" placeholder="Enter Country" name="post_tags" id="post_tags" value="<?php //echo set_value('post_tags' ,$post_tags); ?>"> 
                                                    --->
                                            <!---MY AUTOCOM TAGGING START --->
                                                     <div id="custom-search-input" class="mb10">
                                                          <div id="custom-search-input">
                                                            <div class="input-group ">
                                                              <input id="skillstopics" name="skillstopics" type="text" class="search-query form-control fld" placeholder="Tags" />
                                                              <span class="glyphicon glyphicon-search popupsearch"></span>
                                                              <input type="hidden" name="selected_topics" id="selected_topics">
                                                              

                                                            </div>
                                                          </div>
                                                          <div id="er_rep"></div>
                                                        </div>
                                                       <div id="select_mul"></div>
                                                      <div class="jobadd" id="disptopics"></div>

                                                     <div id="rplc"></div>

                                            <!---MY AUTOCOM TAGGING END ---->
                                            <div class="row">
                                              <div class="col-md-7 mtp10">
                                                   <?php 
                                            $usermodules = $this->Common_model->get_records("c.*, b.tag_name", "tbl_post_tags c, tbl_tags b", "c.tag_id=b.tag_id and c.post_id='$post_id'", "tag_id ASC");
                                            $module = array();
                                         
                                          if(!empty($usermodules)){
                                           foreach ($usermodules as $modules) {
                                                 $module[] = $modules['tag_name'];
                                            }
                                            $var = implode(", ", $module);
                                            $new_var = implode("','", $module);
                                            

            $rec_query = $this->db->query("SELECT tag_id,tag_name FROM tbl_tags WHERE tag_name IN ('".$new_var."')");
            $rec_exicute = $rec_query->result();
            
            foreach($rec_exicute as $rec_a){
                $r_tagid = $rec_a->tag_id;
                $r_tagname = $rec_a->tag_name;

            ?>
            <div class="a-remove-tag1" id="remove_tgs-<?php echo $r_tagid;?>"><?php echo $r_tagname.' '; ?><input title="Delete" type="button" name="imgdelete" id="imgdelete" class="buttondel" onClick="removethispic('<?php echo $post_id; ?>','<?php echo $r_tagid; ?>');"></div>

            

           <?php } ?> 
    <?php } ?>
   

                                              </div>
                                              <div class="col-md-5">
                                                  <a href="#" data-toggle="modal" id="n_tag" data-target="#forget" class="add-new-pupop" title="If you dont find any Tag,add new Tag">Add New tag</a>
                                              </div>
                                            </div>

                                            <!--- ADD NEW TAG START --->
                                       
<div class="clearfix"></div>
                                            <!--- ADD NEW TAG END -->


                                     
     

   

                                                    </div>

                                                </div>
                                                <input type="hidden" name="unic_userid" id="unic_userid" value="<?php echo $userd_id;?>">
                                                <!--- TAGGING END --->

                                                 <div class="col-xl-12 col-lg-12 "> 

                                                    <div class="form-group">
                                                        <label>Description</label>
                                                   <!-- <input type="text" class="form-control fld" placeholder="Enter Country" name="post_desc" id="post_desc" value="<?php //echo set_value('post_desc' ,$post_desc); ?>">-->

                                                  <!--My ck --->
                                               <div class="">
                                                <textarea id="editor" name="post_desc"><?php echo set_value('post_desc',$post_desc); ?></textarea>
                                                <div id="chkediter"></div>
                                             </div>

                                                  <!---my ck --->
                                                        
                                                    </div>

                                                </div>

                                                

                                               <!--- <div class="col-xl-6 col-lg-6 "> 

                                                    <div class="form-group">
                                                        <label>Name</label>
                                                    <input type="text" class="form-control fld" placeholder="Enter Country" name="username" id="username" value="<?php //echo set_value('username' ,$rect_user); ?>">

                                                    
                                                        
                                                    </div>

                                                </div>--->

                                               <!-- <div class="col-xl-6 col-lg-6 "> 

                                                    <div class="form-group">
                                                        <label>Email</label>
                                                    <input type="text" class="form-control fld" placeholder="Enter Country" name="user_email" id="user_email" value="<?php //echo set_value('user_email' ,$rec_user); ?>" readonly>
                                                        
                                                    </div>

                                                </div>--->



                                            
                                                <div class="clearfix"></div>   


                                                <div class="col-xl-12 col-lg-12">
                                                    <div class="reset-button"> 
                                        <button type="submit" class="redbtn" name="btnSubmit" id="btnSubmit">Update</button>
                                        <button type="button" class="blackbtn" onClick="window.location='<?php echo base_url(); ?>admin/posts'">Back</button> 
                                                    </div>
                                                </div>

                                            </div></form>
                                    </div>

                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>

               <!--- ADD NEW TAG MODEL START --->
                   <div class="modal fade"  id="forget">
                    <div class="modal-dialog" >
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Add New Tag</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">
                            <div id="frmError"></div>  
                             <form  name="add_newtag" id="add_newtag" method="post">   
                                <div class="form-group">
                                    <input type="text" class="forgt-fld" name="newtag" id="newtag" placeholder="Add New Tag">
                                </div>
                                <button type="submit" name="addnew_tag" id="addnew_tag" class="forgt-submit">Submit</button>
                             </form>
                            </div>

                            <!-- Modal footer -->


                        </div>
                    </div>
                </div>
               <!--- ADD NEW TAG MODEL END --->
            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>
        <!-- MY AUTO COM SEARCH DIV START-->
        <?php
        $dyntopicsfrsh = array();
        $alltopics = $this->Common_model->get_records("*","tbl_tags","status=1","tag_name asc","");
        if(!empty($alltopics))
        {
          foreach ($alltopics as $rows)
          {
            $topicid = $rows['tag_id'];

            $topic = $rows['tag_name'];
            $dyntopics[] = '{id: '.$topicid.', label: "'.$topic.'"}';
          
          }

           $dyntopicsfrsh = implode($dyntopics,',');
         
        }

        ?>
        <!--- MY AUTO COM SEARCH DIV END --->

    </body>
    <?php $this->load->view('scripts');?>
</html>
<!-- MY AUTO COM SCRIPT START --->
<script type="text/javascript">
var data = [<?php echo $dyntopicsfrsh;?>]; 
//alert(data);
</script>
<script src="<?php echo base_url(); ?>assets/admin/js_validation/jobfeed.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js_validation/likefollow.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/ckeditor/ckeditor.js" type="text/javascript"></script>
        <script>var base_url = "<?php echo base_url(); ?>"; </script>

        <script type="text/javascript">
         CKEDITOR.replace( 'editor');
         </script>

<script type="text/javascript">
  $("#skillstopics").autocomplete({ 
     source: data,
     autoFocus: true,
     minLength:0,
     appendTo: "#rplc",
    select: function(event, ui) {

      var strfrdp = $("#selected_topics").val();
      var entrvl=ui.item.id;
      
      if( strfrdp.match(new RegExp("(?:^|,)"+entrvl+"(?:,|$)")))
      {
        //alert(validationmsg43);
        $("#skillstopics").val('');
        return false;
      }
      event.preventDefault();
      $("#rplc").append("<span id='"+ui.item.id+"' onclick='remove_topics(this.id)'>"+ui.item.label+"<a href='#' onclick='return false;' class='fa fa-times-circle'></a></span>");
      //$("#clval").append("<span id='"+ui.item.id+"' onclick='remove_topics(this.id)'>"+ui.item.label+"<a href='#' onclick='return false;' class='fa fa-times-circle'></a></span>");
      $("#clval").val(ui.item.id);
      var dynval=$("#selected_topics").val();

      if(dynval!='')
      {
        dynval+=','+ui.item.id;
      }
      else
      {
        dynval=ui.item.id;
      }
      $("#selected_topics").val(dynval);
      $("#skillstopics").val('');
    }
  });

</script>
<script type="text/javascript">
 function remove_topics(val)
{
  $('#'+val, '#rplc').empty().remove();
  var dynval=$("#selected_topics").val();
  var list=dynval;
  var value=val;
  var separator=",";
  var values = list.split(separator);
  for(var i = 0 ; i < values.length ; i++) {
    if(values[i] == value) {
      values.splice(i, 1);
      dynval=values.join(separator);
    }
  }
  $("#selected_topics").val(dynval);
} 
</script> 

<!--- MY AUTO COM SCRIPT END --->
<script type="text/javascript">
      jQuery(document).ready(function(){ 
      jQuery("#edited_post").validate({
        rules: {            
            
            post_title: {
                required: true
                
            },
            post_desc: {
                required: true
                
            },
            username: {
                required: true
                
            },
            user_email: {
            required: true,
            user_email: true
            }

        },
        messages:{
            
            post_title: {
                required: "Enter Post Title."
            },
            post_desc: {
                required: "Enter Post Description."
            },
            username: {
                required: "Enter Username."
            },
            user_email: {
            required:"Enter email id.",
            user_email: "Enter a valid email id."
          }
        }
    }); 

   });  
 </script>
 <!-- ADD NEW TAG SCRIPT START --->
<script type="text/javascript">
jQuery("#add_newtag").validate({
        rules: {
            newtag: {
                required: true
            }
        },
        messages:{
            newtag:{
                required: "Enter New Tag"
                
            }
            
        },
       submitHandler: function(form) {
          $('#frmError').html('<div style="text-align:center"><i style="color:#377b9e" class="fa fa-spinner fa-spin fa-3x"></i> <span style="color:#377b9e">Processing...</span></div>');
            $.ajax({
            url: "<?php echo base_url(); ?>admin/posts/addnewtag",
            type: 'post',
            cache: false,
            processData: false, 
            data: $('#add_newtag').serialize(),
            success: function(result) {
             if(result == 1){
              jQuery("#frmError").html('<div class="errormsg"><i class="fa fa-times"></i> Tag Already Exists</div>');

             }else{
               jQuery("#frmError").html('<div class="successmsg notification"><i class="fa fa-check"></i> New Tag Added Successfully.</div>');

                //var o = 'x';
               //setTimeout(refresh,2000); 
                setTimeout(function(){// wait for 2 secs(2)
                location.reload(); // then reload the page.(2)
                //$("#forget").remove();
               //$("#forget").fadeOut(2000);
              //$(".modal-backdrop").css({"opacity":"0"});
             //$(".show").css({"opacity":"0"});
            //$("#addpost").css({"cursor":"pointer"});
           //$(".chosen-results").append('<li>'+o+'</li>');
                 }, 2000); 

               //var page = $(this).attr('href');
              //alert(page);
             //$(this).load.page;
             }

            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
            //$('#frmError').html('<div class="errormsg"><i class="fa fa-times"></i> Invalid Username or Password.</div>');
            }
            });
            return false;
            }
    
    });
</script>
<!-- ADD NEW TAG SCRIPT END --->
<!--REMOVE ITEM START -->
<script type="text/javascript"> 

function removethispic(pid, tid)
{
var con = confirm("Are you Sure to delete this image ?");

if (con)
  {
$.ajax
     ({
    type: "POST",
    url: "<?php echo base_url() . 'admin/posts/delete_apptag'; ?>",
    data: "posid=" + pid + "&ta_id=" + tid,
    success: function (html)
     {
    alert(html);

     $('.remove_tgs').remove();
     $('#remove_tgs-'+tid).remove();
     //$('#xyz').css({"display":"none !important"});
    
   }

  });

  } else
      {
    alert('Thanks');
    return false;
    }
   }        
</script>
<!--- REMOVE ITEM END -->