<!DOCTYPE html>
<html>
    <head>
        <title>PMSL</title>
        <?php include('head.php'); ?>
    </head>
    <body>
        <?php include('header.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">
            <section class="home-body-sec">
                <div class="container">
                    <?php include('sidebar.php'); ?>
                    <div class="right-sec">
                        <div class="row">
                            <div class="col-xl-8 col-lg-8 offset-xl-2 offset-lg-2">
                                <form class="login-form text-center brdr-animation" name="form_signup" id="form_signup" method="post">
                                    <?php echo $message;?>
                                    <h1> Sign Up </h1>
                                    <div class="forgt-txt"> Welcome Back ! Register To access the 
                                        sweet marketplace .
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="logn-fld" name="username" placeholder="Username">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="logn-fld" name="user_email" placeholder="Email Id">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="logn-fld" name="password" placeholder="Password">
                                    </div>
                                    <button type="submit" class="form-submit" name="signup_btn" id="signup_btn">Register</button>
                                    <div class="or-txt">OR </div>
                                    <div class="social-login text-center">
                                        <a href="#" class="fb"><i class="fab fa-facebook-f "></i></a>
                                        <a href="#" class="tw"><i class="fab fa-twitter"></i></a>
                                        <a href="#" class="gp"><i class="fab fa-google-plus-g"></i></a>
                                    </div>
                                    <div class="login-txt1"> I Don't Have an Account <a class="#" href="<?php echo base_url();?>login">  Log in</a></div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="clearfix"></div>
        </div>
        <?php include('footer.php'); ?>
    </body>
</html>
