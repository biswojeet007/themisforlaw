<?php
//session_start();

include_once('settings.php');
include_once('google-login-api.php');

// Google passes a parameter 'code' in the Redirect Url
if(isset($_GET['code'])) {
	try {
		$gapi = new GoogleLoginApi();
		
		// Get the access token 
		$data = $gapi->GetAccessToken(CLIENT_ID, CLIENT_REDIRECT_URL, CLIENT_SECRET, $_GET['code']);
		
		// Get user information
		$user_info = $gapi->GetUserProfileInfo($data['access_token']);
             $userpic = $user_info['image']['url'];
             $username = $user_info['displayName'];
             $useremail = $user_info['emails'][0]['value'];


        //print_r($user_info);
        echo '<br>';
		echo "<img src='".$userpic."'>";

		echo '<br>';
         
        echo $username; 
		//echo '<pre>';print_r($username); echo '</pre>';

		echo '<br>';
		echo $useremail;

		

	   /* $rec_alluserinfo = $this->db->query("INSERT INTO `tbl_googleuser`(`gu_name`,`gu_email`,`gu_pic`) VALUES('".$username."','".$useremail."','".$userpic."')");
	    if(!empty($rec_alluserinfo)){
	    $exicute = $rec_alluserinfo->exicute();
	  }*/


               $noof_signeduinuser = $this->Conference_model->noof_records("gu_id","tbl_googleuser","gu_email='$useremail'");
               if($noof_signeduinuser > 0) { 


               }else{
               $insert_data = array(
                               'gu_name' => $username,
                               'gu_email' => $useremail,
                               'gu_pic' => $userpic

                                );
                 
             
               $insertdb = $this->Conference_model->insert_records("tbl_googleuser",$insert_data);
               }
		//echo '<pre>';print_r($useremail); echo '</pre>';


		// Now that the user is logged in you may want to start some session variables
		$_SESSION['logged_in'] = 1;

		// You may now want to redirect the user to the home page of your website
		// header('Location: home.php');
	}
	catch(Exception $e) {
		echo $e->getMessage();
		exit();
	}
}

?>


