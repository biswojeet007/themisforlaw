<!DOCTYPE html>
<html>
    <head>
        <title>PMSL</title>
        <?php include('head.php'); ?>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/jquery-ui.css">
        <link href="<?php echo base_url(); ?>assets/css/bootstrap-select.css" rel="stylesheet" type="text/css">
    </head>
    <body>
      <?php include('header.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">
            <section class="home-body-sec">
                <div class="container">
                    <?php include('sidebar.php'); ?>
                    <div class="right-sec">
                        <div class="row">
                            <div class="col-xl-12 col-lg12">
                                <h1 class=""> Add Post</h1>
                                <?php echo $message; ?>
                                <form class="setting-form attireCodeToggleBlock" name="addpost" id="addpost" method="post" style="border: 1px solid #e4e4e4;padding: 40px;">
                                    <div class="row">
                                        <div class="col-xl-12 col-lg-12">
                                            <div class="setting-fld-sec ">
                                                <label> Title</label>
                                                <input type="text" class="setting-fld" name="post_title" id="post_title" value="<?php echo set_value('post_title');?>" placeholder="">
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-12">
                                            <div class="setting-fld-sec">
                                                <label> Tags</label>
                                                <!---<input type="text" class="setting-fld" name="post_tag" id="post_tag"   placeholder="">--->
                                                <!--- MY AUTO COM DIV START --->
                                                       <div id="empty-message"></div>
                                                <!-- NEW AUTO COMPLETE START --->
                                                     
        
                                                        <div id="custom-search-input" class="mb10">
                                                          <div id="custom-search-input">
                                                            <div class="input-group">
                                                              <input id="skillstopics" name="skillstopics" type="text" class="search-query form-control setting-fld" placeholder="Tags" />
                                                              <span class="glyphicon glyphicon-search popupsearch"></span>
                                                              <input type="hidden" name="selected_topics" id="selected_topics">
                                                              

                                                            </div>
                                                          </div>
                                                          <div id="er_rep"></div>
                                                        </div>
                                                       <div id="select_mul"></div>
                                                      <div class="jobadd" id="disptopics"></div>

                                                     <div id="rplc"></div>
                                               

                                <!--- NEW AUTO COMPLETE END --->
                                 
                                        <a href="#" data-toggle="modal" id="n_tag" data-target="#forget" class="add-new-pupop1 mtp10" title="If you dont find any Tag,add new Tag">Add New tag</a>
                                                <!--- MY AUTO COM DIV END -->
                                            </div>
                                        </div>

                                        <div class="col-xl-12 col-lg-12">
                                            <div class="setting-fld-sec">
                                                <label> Description</label>
                                                <textarea class="setting-fld text-area-height" name="post_desc" id="post_desc"  placeholder=""><?php echo set_value('post_desc');?></textarea>
                                                <div id="chkediter"></div>
                                                <span id="msg_ck"></span>

                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-12">
                                            <button type="submit" class="setting-submit" name="post_submit">Submit</button>
                                        </div>

                                    </div>
                                </form>

                            </div>

                        </div>
                    </div>
                </div>
				
				<!-- MODEL SECTION FOR ADD NEW TAG --->
				   <div class="modal fade"  id="forget">
                    <div class="modal-dialog" >
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Add New Tag</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">
                            <div id="frmError"></div>  
                             <form  name="add_newtag" id="add_newtag" method="post">   
                                <div class="form-group">
                                    <input type="text" class="forgt-fld" name="newtag" id="newtag" placeholder="Add New Tag">
                                </div>
                                <button type="submit" name="addnew_tag" id="addnew_tag" class="forgt-submit">Submit</button>
                             </form>
                            </div>

                            <!-- Modal footer -->


                        </div>
                    </div>
                </div>
				<!--- MODEL SECTION FOR ADD NEW TAG END ---->
				
            </section>
            <div class="clearfix"></div>
        </div>
        <?php include('footer.php'); ?>
        <?php
$dyntopicsfrsh = array();
$alltopics = $this->Conference_model->get_records("*","tbl_tags","status=1","tag_name asc","");
if(!empty($alltopics))
{
  foreach ($alltopics as $rows)
  {
    $topicid = $rows['tag_id'];

    $topic = $rows['tag_name'];
    $dyntopics[] = '{id: '.$topicid.', label: "'.$topic.'"}';
  
  }

   $dyntopicsfrsh = implode($dyntopics,',');
 
}

?>

</body>
<?php $this->load->view('scripts');?>
</html>
 



<script type="text/javascript">
var data = [<?php echo $dyntopicsfrsh;?>]; 
//alert(data);
</script>
<script src="<?php echo base_url(); ?>assets/js_validation/jobfeed.js"></script>
<script src="<?php echo base_url(); ?>assets/js_validation/likefollow.js"></script>
<script src="<?php echo base_url(); ?>assets/js_validation/explore.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/ckeditor/ckeditor.js" type="text/javascript"></script>
        <script>var base_url = "<?php echo base_url(); ?>"; </script>

        <script type="text/javascript">
         CKEDITOR.replace( 'post_desc');
         </script>

<script type="text/javascript">
  $("#skillstopics").autocomplete({ 
     source: data,
     autoFocus: true,
     minLength:0,
     appendTo: "#rplc",
    select: function(event, ui) {

      var strfrdp = $("#selected_topics").val();
      var entrvl=ui.item.id;
      
      if( strfrdp.match(new RegExp("(?:^|,)"+entrvl+"(?:,|$)")))
      {
        //alert(validationmsg43);
        $("#skillstopics").val('');
        return false;
      }
      event.preventDefault();
      $("#rplc").append("<span id='"+ui.item.id+"' onclick='remove_topics(this.id)'>"+ui.item.label+"<a href='#' onclick='return false;' class='fa fa-times-circle'></a></span>");
      //$("#clval").append("<span id='"+ui.item.id+"' onclick='remove_topics(this.id)'>"+ui.item.label+"<a href='#' onclick='return false;' class='fa fa-times-circle'></a></span>");
      $("#clval").val(ui.item.id);
      var dynval=$("#selected_topics").val();

      if(dynval!='')
      {
        dynval+=','+ui.item.id;
      }
      else
      {
        dynval=ui.item.id;
      }
      $("#selected_topics").val(dynval);
      $("#skillstopics").val('');
    }
  });

</script>
<script type="text/javascript">
 function remove_topics(val)
{
  $('#'+val, '#rplc').empty().remove();
  var dynval=$("#selected_topics").val();
  var list=dynval;
  var value=val;
  var separator=",";
  var values = list.split(separator);
  for(var i = 0 ; i < values.length ; i++) {
    if(values[i] == value) {
      values.splice(i, 1);
      dynval=values.join(separator);
    }
  }
  $("#selected_topics").val(dynval);
} 
</script>
<script type="text/javascript">
  // TAG ADDITION //
jQuery("#add_newtag").validate({
        rules: {
            newtag: {
                required: true
            }
        },
        messages:{
            newtag:{
                required: "Enter New Tag"
                
            }
            
        },
       submitHandler: function(form) {
          $('#frmError').html('<div style="text-align:center"><i style="color:#377b9e" class="fa fa-spinner fa-spin fa-3x"></i> <span style="color:#377b9e">Processing...</span></div>');
            $.ajax({
            url: "<?php echo base_url(); ?>add_post/addnewtag",
            type: 'post',
            cache: false,
            processData: false, 
            data: $('#add_newtag').serialize(),
            success: function(result) {
             if(result == 1){
              jQuery("#frmError").html('<div class="errormsg"><i class="fa fa-times"></i> Tag Already Exists</div>');

             }else{
               jQuery("#frmError").html('<div class="successmsg notification"><i class="fa fa-check"></i> New Tag Added Successfully.</div>');

                //var o = 'x';
               //setTimeout(refresh,2000); 
                setTimeout(function(){// wait for 2 secs(2)
                location.reload(); // then reload the page.(2)
                //$("#forget").remove();
               //$("#forget").fadeOut(2000);
              //$(".modal-backdrop").css({"opacity":"0"});
             //$(".show").css({"opacity":"0"});
            //$("#addpost").css({"cursor":"pointer"});
           //$(".chosen-results").append('<li>'+o+'</li>');
                 }, 2000); 

               //var page = $(this).attr('href');
              //alert(page);
             //$(this).load.page;
             }

            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
            //$('#frmError').html('<div class="errormsg"><i class="fa fa-times"></i> Invalid Username or Password.</div>');
            }
            });
            return false;
            }
    
    });

// TAG ADDITION //
</script>






