<?php
if(!empty($row)){
  foreach ($row as $rows) {
  $post_title = $rows['post_title'];
  $post_desc = $rows['post_desc'];
  $post_id = $rows['post_id'];
  $us_id = $rows['user_id'];

  }
}
$vk=1;
$noof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","post_id='$post_id' and status='$vk'");
$sess_userid = $this->session->userdata('userid');
$sess_userid1 = $this->session->userdata('userid');
$decpost = base64_encode($post_id);

$delpoid = array();
if(!empty($delrow)){
foreach ($delrow as $del) {
   $delpoid[] = $del['post_id'];

  }

}
//$im = implode(",", $delpoid);


if(!empty($delr)){
  foreach ($delr as $value) {
    $deliuid = $value['user_id'];

  }

}


if(!empty($delrcm)){
  foreach ($delrcm as $va) {
    $cmdeliuid = $va['user_id'];


    

  }


}

if(!empty($cmdeliuid)){
 $f = $cmdeliuid;
 //echo $f ;

}


?>
<!DOCTYPE html>
<html>
    <head>
        <title>PMSL</title>
        <?php include('head.php'); ?>
        
    </head>
    <body>

        <?php include('header.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">

            <section class="home-body-sec">
                <div class="container">
                    <?php include('sidebar.php'); ?>
                    <div class="right-sec">
                        <div class="row">
                            <div class="col-xl-9 col-lg-9">
                               <!--- <h1 class=""> Main Heading</h1>-->
                                <div class="add-txt-sec single-sec">
                                    <h4> <?php if($post_title== ''){}else{echo $post_title;}?></h4>
                                    <div class="replay-sec">
                                      <!--- VOTING START --->
                                          <?php 
                                                $dynlkdislksave = $this->Conference_model->showname_fromid("voting","tbl_post_voting","vpost_id='$post_id' and vuserid='$sess_userid' and voting in(1,2)");
                                                $likestyle=''; $dislikestyle=''; 
                                                if($dynlkdislksave==1) {
                                                  $likestyle = "style='color:green;'";
                                                } else if($dynlkdislksave==2) {
                                                  $dislikestyle = "style='color:red;'";
                                                }
                                             $noof_vots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$post_id' and voting='1'");  

                                                          $noof_unvots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$post_id' and voting='2'"); 

                                                $totalvotes = $noof_vots -  $noof_unvots;        
                          
                                          ?>
                                          <!-- VOTING END --->

                                         


                                        <div class="no-of-replay">

                                           <?php if($sess_userid == ''){ ?>
                                             <a href="javascript:void(0);" data-toggle="modal"  data-target="#forget"><i class="fa fa-angle-up"></i>  </a>
                                              <span> <?php echo $totalvotes;?>  </span>
                                             <a href="javascript:void(0);" data-toggle="modal"  data-target="#forget"><i class=" fa fa-angle-down"></i>  </a>
                                             <?php }else{?>

                                            <a href="javascript:void(0)" onClick="likedislikesave('<?php echo $sess_userid;?>','<?php echo $post_id;?>','1')"><i class="fa fa-angle-up" <?php echo $likestyle;?> id="likefrs_<?php echo $post_id;?>"></i>  </a>
                                                <!--<li><a href="javascript:void(0);"><i class="fas fa-thumbs-down"></i> 01 Vote </a></li>--->
                                                <span> <?php echo $totalvotes;?>  </span>
                                              <a href="javascript:void(0)" onClick="likedislikesave('<?php echo $sess_userid;?>','<?php echo $post_id;?>','2')"><i class="fa fa-angle-down" <?php echo $dislikestyle;?> id="dislikefrs_<?php echo $post_id;?>"></i>  </a>
                                             
                                            <input type="hidden" name="curractivity_<?php echo $post_id; ?>" id="curractivity_<?php echo $post_id; ?>" value="<?php echo $dynlkdislksave;?>">

                                            <?php } ?> 
                                           <!--  <a href="#"> <i class="fa fa-angle-up"></i></a>
                                            <span> <?php //echo $noof_rec;?>  </span>
                                            <a href="#">  <i class="fa fa-angle-down"></i></a> -->
                                        </div>

                                        <div class="replay-txt">
                                            <p> <?php if($post_desc== ''){}else{echo $post_desc;}?></p>
              
                                        </div>

                                 <div class="clearfix"></div> 

                                          <div class="container">
                                          <div class="row">
                                            <div class="col-sm">
                                              

                                <div class="android-sec">
                                  <ul>
                                     <?php  
                                               $rec_tagname = $this->Conference_model->get_records("tag_id","tbl_post_tags","post_id='$post_id'");
                                                 $cnt = 0;
                                              if(!empty($rec_tagname)){
                                                foreach ($rec_tagname as $tagii) {
                                                 $tags_idf = $tagii['tag_id'];
                                                 $cnt = $cnt+1;
                                                 $fff_tagid = base64_encode($tags_idf);
                                                 $tagnaming = $this->Conference_model->showname_fromid("tag_name","tbl_tags","tag_id='$tags_idf'");
                                                

                                                 ?>
                                    <li><a href="<?php echo base_url() . 'tags/tagrelated-ques/'.$tagnaming.'/'.$fff_tagid; ?>"
                                      title="Browse other questions tagged"><?php echo $tagnaming;?></a></li>
                                     <?php 
                                   }

                                 }
                               ?>

                                  </ul>


                                </div>

                                


                             
                              </div>

                                            <div class="col-sm">
                                              <?php 
                                              $posterid = $this->Conference_model->showname_fromid("user_id","tbl_posts","post_id='$post_id'");

                                              $pdate = $this->Conference_model->showname_fromid("posted_date","tbl_posts","post_id='$post_id'");

                                              $postername = $this->Conference_model->showname_fromid("username","tbl_user","user_id='$posterid'");
                                              

                                               $posterpic = $this->Conference_model->showname_fromid("user_pic","tbl_user","user_id='$posterid'");

                                               $posview = $this->Conference_model->showname_fromid("noof_views","tbl_posts","post_id='$post_id'");

                                               $posvotes = $this->Conference_model->showname_fromid("voting","tbl_post_voting","vpost_id='$post_id'");
                                                   
                                                 ?>
                                                    
                                              

                                     <div class="comment-pic asked-sec">
                  <div class="c-sec"><span><?php  if(!empty($pdate)){
                                                    
                                                        $t1 = strtotime('now');
                                                        $t2 = strtotime($pdate);
                                                        $delta_T = ($t1 - $t2);
                                                        $day = round(($delta_T % 604800) / 86400); 
                                                        $hours = round((($delta_T % 604800) % 86400) / 3600); 
                                                        $minutes = round(((($delta_T % 604800) % 86400) % 3600) / 60); 
                                                        $sec = round((((($delta_T % 604800) % 86400) % 3600) % 60));

                                                        if($day){
                                                          echo 'asked '. $day.' days ' .' ago';
                                                        }else if($hours){
                                                          echo 'asked '. $hours.' hours ' .' ago';
                                                        }else if($minutes){
                                                         echo 'asked '. $minutes.' minutes ' .' ago';
                                                        }else{
                                                          echo 'asked '. $sec.' seconds ' .' ago';
                                                        }
                                                        
                                                        
                                                    }else{} ?><span></span></span></div>
                  
              <div> <?php if(file_exists("./assets/images/".$posterpic) && ($posterpic!='')){ ?> <span><img src="<?php echo base_url() . 'assets/images/' . $posterpic; ?>" alt="" class="img-fluid" style="width: 50px;height:50px;"></span> <?php } ?>
              
               <span style="display: inline-block;"> <i class="fas fa-user" style="color: #c1c0bf"></i> <?php echo $postername; ?><br> <div class="v-votes"><i class="fas fa-eye" style="color: #c1c0bf"></i> views <?php echo $posview; ?>  <span class="v-views">   <?php if($totalvotes>0){ ?><i class="fas fa-thumbs-up" style="color: green;" ></i> <?php }else{ ?><i class="fas fa-thumbs-down" style="color: red;"></i> <?php } ?> votes <?php echo $totalvotes; ?> </div>

                                                                 
              </div> 
            </div>
                                            </div>

                                            <div class="col-sm">
                                            <div class="cmt-share">
                                                <ul>
                                                    <li class="share-txt"> Share</li>
                                                    <li> <a href="http://www.facebook.com/sharer.php?u=<?php echo base_url().'home/post/'.$decpost; ?>" target="_blank"> <i class="fab fa-facebook-f"></i></a></li>
                                                    <li> <a href="https://twitter.com/share?url=<?php echo base_url().'home/post/'.$decpost; ?>" target="_blank"> <i class="fab fa-twitter"></i></a></li>
                                                    <li> <a href="https://plus.google.com/share?url=<?php  echo base_url().'home/post/'.$decpost; ?>" target="_blank"> <i class="fab fa-google-plus-g"></i></a></li>
                                                    <li> <a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo base_url().'home/post/'.$decpost; ?>" target="_blank"> <i class="fab fa-linkedin-in"></i></a></li>
                       
                                                </ul>
                                            </div>
                                            </div>
                                          </div>
                                        </div>
                                         <hr>
                                         <div class="clearfix"></div>

                                        <div class="clearfix"></div>
                                        <?php echo $message;?>
                                 
                                      <?php 
                                      $var = 1;
                                      $rec_comment = $this->Conference_model->get_records("*","tbl_comments","post_id='$post_id' and status='$var'");
                                      if(!empty($rec_comment)){
                                      foreach($rec_comment as $recd){
                                         $comments = $recd['user_cmt'];
                                         $cmtt_id = $recd['cmt_id'];
                                         $usop_id = $recd['user_id'];
                                         $commented_date = $recd['commented_date'];
                                        

                                     ?>

                                     <?php
                                     $se= $usop_id;
                                          $r = $this->Conference_model->get_records("*", "tbl_user", "user_id='$se'");
                                          foreach ($r as $rj) {
                                              $picjj = $rj['user_pic'];
                                          }

                                     ?>
                                              
                              
                                       
                                        <div class="comment-sec">
                                          <?php if(file_exists("./assets/images/".$picjj) && ($picjj!='')){ ?> 
                                            <div class="comment-pic">
                                                <img src="<?php echo base_url() . 'assets/images/' . $picjj; ?>" alt="" class="img-fluid">
                                            </div>
                                          <?php } ?>
                                            <div class="comment-name">
                                                <h2>
                                          <?php 
                                           if(!empty($usop_id)){
                                            $user_n = $this->Conference_model->showname_fromid("username","tbl_user","user_id='$usop_id'");
                                            echo $user_n;
                                         }else{

                                         }
                                                  ?></h2>
                                                <div class="comnt-day"><?php if(!empty($commented_date)){
                                                    
                                                        $t1 = strtotime('now');
                                                        $t2 = strtotime($commented_date);
                                                        $delta_T = ($t1 - $t2);
                                                        $day = round(($delta_T % 604800) / 86400); 
                                                        $hours = round((($delta_T % 604800) % 86400) / 3600); 
                                                        $minutes = round(((($delta_T % 604800) % 86400) % 3600) / 60); 
                                                        $sec = round((((($delta_T % 604800) % 86400) % 3600) % 60));

                                                        if($day){
                                                          echo 'Answered '. $day.' days ' .' ago';
                                                        }else if($hours){
                                                          echo 'Answered '. $hours.' hours ' .' ago';
                                                        }else if($minutes){
                                                         echo 'Answered '. $minutes.' minutes ' .' ago';
                                                        }else{
                                                          echo 'Answered '. $sec.' seconds ' .' ago';
                                                        }
                                                        
                                                        
                                                    }else{}?></div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <p> <?php echo $comments;?></p>
                                            <div class="cmt_edit_del">
                                              <ul>
                                              <?php if($sess_userid === $deliuid){ ?> 

                                                    <li class="view-link-sec"><a href="javascript:void(0);" data-id="<?php echo $cmtt_id; ?>" class="btn btn-primary btn-sm edit" 
                                                               title="Edit" data-toggle="modal" data-target="#myMod"><i class="fas fa-edit"></i> </a></li>

                                                    <li class="view-link-sec"> <a onClick="return confirm('Are you sure to delete this Comment?')" href="<?php echo base_url() . 'activity/commtdel/' . $cmtt_id.'/'.$decpost; ?>" class="btn btn-danger btn-sm tbl-icon-btm" title="Delete"><i class="far fa-trash-alt"></i> <input type="hidden" name="deposti" value="<?php if(!empty($decpost)){echo $decpost;} ?>"> </a></li> 

                                                    <?php }else if(!empty($f) && $usop_id == $f){ ?> 

                                                   <li class="view-link-sec"><a href="javascript:void(0);" data-id="<?php echo $cmtt_id; ?>" class="btn btn-primary btn-sm edit" 
                                                               title="Edit" data-toggle="modal" data-target="#myMod"><i class="fas fa-edit"></i> </a></li>
                                                                  
                                                   <li class="view-link-sec"> <a onClick="return confirm('Are you sure to delete this Comment?')" href="<?php echo base_url() . 'activity/commtdel/' . $cmtt_id.'/'.$decpost; ?>" class="btn btn-danger btn-sm tbl-icon-btm" title="Delete"><i class="far fa-trash-alt"></i> <input type="hidden" name="deposti" value="<?php if(!empty($decpost)){echo $decpost;} ?>"> </a></li>

                                                    <?php }else{ ?> 

                                                  <?php } ?> 
                                                 </ul> 
                                            </div>
                                            <hr>
                                            <!---<div class="cmt-share">
                                                <ul>
                                                    <li class="share-txt"> Share</li>
                                                    <li> <a href="http://www.facebook.com/sharer.php?u=<?php //echo base_url().'home/post/'.$decpost; ?>" target="_blank"> <i class="fab fa-facebook-f"></i></a></li>
                                                    <li> <a href="https://twitter.com/share?url=<?php //echo base_url().'home/post/'.$decpost; ?>" target="_blank"> <i class="fab fa-twitter"></i></a></li>
                                                    <li> <a href="https://plus.google.com/share?url=<?php // echo base_url().'home/post/'.$decpost; ?>" target="_blank"> <i class="fab fa-google-plus-g"></i></a></li>
                                                    <li> <a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php //echo base_url().'home/post/'.$decpost; ?>" target="_blank"> <i class="fab fa-linkedin-in"></i></a></li>
                       
                                                </ul>
                                            </div>--->
                                            
                                            </div>
                                            <?php
                                       }

                                    }
                                   ?>
                                            
                                            <div class="comment-sec frm">
                                              <?php if($sess_userid == ''){ ?>
                                             <a href="#" data-toggle="modal"  data-target="#forget" class="add-new-pupop1 mtp10">Comment</a>
                                             <?php }else{?>
                                            <form name="cmt_replyfrm" id="cmt_replyfrm" method="post">
                                            <div class="cmnt-replay brdr-animation bordtwo">

                                                <div class="cmt-fld-sec">
                                                    <div class="cmt-fld-img"> <img src="<?php echo base_url(); ?>assets/images/replay-cmt-img.png" alt="" class="img-fluid"/></div>
                                                    <textarea class="cmt-fld" name="user_cmt" id="user_cmt" placeholder="Message..."></textarea>

                                        <input type="hidden" name="pos_id" id="pos_id" value="<?php echo $post_id;?>">
                                        <input type="hidden" name="us_id" id="us_id" value="<?php echo $sess_userid;?>">

                                                </div>
                                                


                                             
                                             
                                 <button class="comment-btm" type="submit" name="submit">Comment</button>
                                                 


                                            </div>
                                            <div id="cmt_err"></div>
                                            <div id="frmError"></div>
                                        </form>
                                      <?php } ?>
                                      
                                        </div>
                                    

                                    </div>

                             


                                    <div class="related-topics">
                                       
                                        <h5> Related Topics</h5>
                    <?php
                    $tag_id = array();
                    $sql = $this->db->query("SELECT DISTINCT `tag_id` FROM `tbl_post_tags` WHERE `post_id`='".$post_id."'");
                    $exicu_sql = $sql->result();
                    if(!empty($exicu_sql)){
                    foreach ($exicu_sql as $tagide) {
                        $tag_id[] = $tagide->tag_id;
                        
                           }
                          }
                        $tagf_id = implode(",",$tag_id);
                   
                   $tag_posIds = array();
                   $asql = $this->db->query("SELECT DISTINCT `post_id` FROM `tbl_post_tags`  WHERE tag_id IN('".$tagf_id."') ORDER BY tag_id LIMIT 7");
                   $w = $asql->result();
                     if(!empty($w)){
                      foreach ($w as $postagid) {
                              $tag_posIds[] = $postagid->post_id;
                              $tag_posId = $postagid->post_id;
                              $f_poid = base64_encode($tag_posId);
                              
                           
     $noof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","post_id='$tag_posId'");
     $rec_postdet = $this->db->query("SELECT `post_title`,`noof_views`,`post_id` FROM `tbl_posts` WHERE post_id='".$tag_posId."'");
         $rec_ex = $rec_postdet->result();
          
                             if(!empty($rec_ex)){
                                         foreach($rec_ex as $recp) {
                                            $post_t = $recp->post_title;
                                            $post_v = $recp->noof_views;
                                            $post_vot = $recp->post_id;
                                      
                     
                        ?>
                                     
                                        <div class="add-txt-sec">
                                            <h4> <a href="<?php echo base_url() . 'home/post/'.$f_poid; ?>">
                                          <?php echo $post_t;?>
                                              </a></h4>
                                            <div class="add-list">
                                            	<!--- VOTING START --->
                                            <?php 
                                                $dynlkdislksave = $this->Conference_model->showname_fromid("voting","tbl_post_voting","vpost_id='$post_vot' and vuserid='$sess_userid' and voting in(1,2)");
                                                    $likestyle=''; $dislikestyle=''; 
                                                    if($dynlkdislksave==1) {
                                                        $likestyle = "style='color:green;'";
                                                    } else if($dynlkdislksave==2) {
                                                        $dislikestyle = "style='color:red;'";
                                                    }
                                                    
                                                 
                                    $noof_vots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$post_vot' and voting='1'");  

                                    $noof_unvots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$post_vot' and voting='2'");    
                                            ?>
                                            <!-- VOTING END ---> 
                                                <ul>

                                                    <li>  <a href="javascript:void(0);"> <i class="fas fa-eye"></i>  <?php echo ($post_v > 0) ? $post_v : '0' ;?>  views </a></li>

                                             <?php if($sess_userid == ''){ ?>
                                             <li><a href="javascript:void(0);" data-toggle="modal"  data-target="#forget"><i class="fas fa-thumbs-up"></i> <?php echo $noof_vots.' Votes ';?> </a></li>

                                             <li><a href="javascript:void(0);" data-toggle="modal"  data-target="#forget"><i class="fas fa-thumbs-down"></i> <?php echo $noof_unvots.' Downvotes ';?> </a></li>
                                             <?php }else{?>

                                            <li><a href="javascript:void(0)" onClick="likedislikesave('<?php echo $sess_userid;?>','<?php echo $post_vot;?>','1')"><i class="fas fa-thumbs-up" <?php echo $likestyle;?> id="likefrs_<?php echo $post_vot;?>"></i> <?php echo $noof_vots.' Votes ';?> </a></li>
                                                <!--<li><a href="javascript:void(0);"><i class="fas fa-thumbs-down"></i> 01 Vote </a></li>--->
                                             <li> <a href="javascript:void(0)" onClick="likedislikesave('<?php echo $sess_userid;?>','<?php echo $post_vot;?>','2')"><i class="fas fa-thumbs-down" <?php echo $dislikestyle;?> id="dislikefrs_<?php echo $post_vot;?>"></i> <?php echo $noof_unvots.' Downvotes ';?> </a></li>
                                             
                                            <input type="hidden" name="curractivity_<?php echo $post_vot; ?>" id="curractivity_<?php echo $post_vot; ?>" value="<?php echo $dynlkdislksave;?>">

                                            <?php } ?> 
                                                    <!---<li><a href="javascript:void(0);"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>
                                                    <li><a href="javascript:void(0);"><i class="fas fa-thumbs-down"></i> 01 Vote </a></li>--->
                                                    <li> <a href="javascript:void(0);"><i class="fas fa-reply"></i> <?php echo  $noof_rec.' Answer' ?> </a></li>
                                                </ul>
                                            </div>
                                        </div>

                                        <?php

                                          }
                                         }

                                        }
                                       }
                                      ?>
                        

                                    </div>

                                </div>




                            </div>

                            <?php include('rsidebar.php'); ?>
                        </div>
                    </div>
                </div>
            <!-- MODEL SECTION FOR COMMENT USER LOGIN --->
           <div class="modal fade"  id="forget">
                    <div class="modal-dialog" >
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Login Here</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">
                            <div id="frmErrorsd"></div>  
                             <form  name="login_ans" id="login_ans" method="post">   
                                <div class="form-group">
                                    <input type="text" class="forgt-fld" name="username" id="username" placeholder="Username">
                                </div>
                                <div id="email_error"></div>
                                <div class="form-group">
                                    <input type="password" class="forgt-fld" name="password" id="password" placeholder="Password">
                                </div>
                                <div id="password_error"></div>
                                <button type="submit" name="log_cmt" id="log_cmt" class="forgt-submit">Submit</button>
                             </form>
                            </div>

                            <!-- Modal footer -->


                        </div>
                    </div>
                </div>
        <!--- MODEL SECTION FOR USER LOGIN ---->

        <!--- SECOND MODAL FOR EDIT START  -->
        <div class="modal" id="myMod">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">

                    <!-- Modal Header -->
                    
                </div>
            </div>
        </div>
        <!--- SECOND MODAL FOR EDIT END --->

            </section>
            <div class="clearfix"></div>

        </div>
<?php include('footer.php');?>
<script type="text/javascript">
            //url: "<?php //echo base_url(); ?>activity/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity,
       
    function likedislikesave(employeeid,jobid,activity,currentactivity = "")
          {
    var base_url = "";          
    var currentactivity = $("#curractivity_"+jobid).val();
         //var url= "<?php //echo base_url(); ?>activity/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity;
        $.ajax({
            url:"<?php echo base_url(); ?>home/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity,
            success:function(result)
            {
                 location.href = location.href;

                if(result=="new1") {
                    alert("Confirm");
                    $("#curractivity_"+jobid).val("1");
                    $('#likefrs_'+jobid).css({'color':'green'});
                    $('#dislikefrs_'+jobid).css({'color':''});
                }
                else if(result=="new2") {
                    $("#curractivity_"+jobid).val("2");
                    $('#likefrs_'+jobid).css({'color':''});
                    $('#dislikefrs_'+jobid).css({'color':'red'});
                    
                }
                else if(result=="updt1") {
                    $("#curractivity_"+jobid).val("");
                    $('#likefrs_'+jobid).css({'color':''});
                    
                }
                else if(result=="updt2") {
                    $("#curractivity_"+jobid).val("");
                    $('#dislikefrs_'+jobid).css({'color':''});
                    
                }
                
            }
        });
    
 }

       
</script>
<script type="text/javascript"> 
jQuery("#login_ans").validate({
        rules: {
            username: {
                required: true,
                email: true
            },
            password: {
                required: true
            }
        },
        messages: {
            username: {
                required: "Enter Email ID",
                email: "Invalid Email"
            },
            password: {
                required: "Enter Password"
            }
        },

        errorPlacement: function (error, element)
    {
      if (element.attr("name") === "username" )
        error.appendTo("#email_error");
      else if (element.attr("name") === "password" )
        error.appendTo("#password_error");
      else
        error.insertAfter(element);
    },
  submitHandler: function(form) {
            $('#frmErrorsd').html('<div style="text-align:center"><i style="color:#377b9e" class="fa fa-spinner fa-spin fa-3x"></i> <span style="color:#377b9e">Processing...</span></div>');
            $.ajax({
                url: "<?php echo base_url(); ?>home/check_login",
                type: 'post',
                cache: false,
                processData: false,
                data: $('#login_ans').serialize(),
                success: function(result) {
                    if (result == 1) {
                      location.href = location.href;
                    } else {
                        jQuery("#frmErrorsd").html('<div class="errormsg"><i class="fa fa-times"></i> Invalid Username or Password.</div>');
                        //jQuery('#frm_LoginPop')[0].reset();
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
                    $('#frmErrorsd').html('<div class="errormsg"><i class="fa fa-times"></i> Invalid Username or Password.</div>');
                }
            });
            return false;
        }

   });

</script>
<script type="text/javascript">
     jQuery("#cmt_replyfrm").validate({
        rules: {            
            user_cmt: {
                required: true
               
                }

        },
        messages:{
            user_cmt: {
                required:"Enter Comment."
                
            }
        },
       submitHandler: function(form) {
            $.ajax({
            url: "<?php echo base_url(); ?>activity/comments",
            type: 'post',
            cache: false,
            processData: false, 
            data: $('#cmt_replyfrm').serialize(),
            success: function(result) {
             if(result == 1){
                jQuery("#frmError").html('<div class="successmsg notification"><i class="fa fa-check"></i> Thanks for your Reply. </div>');
                $('#cmt_replyfrm')[0].reset();
                setTimeout(function(){
                location.reload(); 
                
                 }, 2000); 
              

             }else{
               
              jQuery("#frmError").html('<div class="errormsg"><i class="fa fa-times"></i> Comment Failed!!</div>');
               
             }

            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
            
            }
            });
            return false;
            }
 // url: base_url + "home/check_login",
    });
</script>
<script type="text/javascript">
$(document).on('click', '.edit', function(){
    jQuery('#myMod .modal-content').html('<div style="text-align:center;margin-top:150px;margin-bottom:100px;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-3x"></i> <span>Processing...</span></div>');
    var val = $(this).data("id");
    
    $.ajax({
        url: "<?php echo base_url(); ?>activity/view_pop/"+val,
        type: 'post',
        cache: false,
        
        processData: false,
        success: function (modal_content) {
            jQuery('#myMod .modal-content').html(modal_content);
            // LOADING THE AJAX MODAL
            $('#myMod').modal('show');
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
            $('#errMessaged').html('<div class="errormsg"><i class="fa fa-times"></i> Your query could not executed. Please try again.</div>');
        }
    });
});

</script>


    </body>
</html>
  

