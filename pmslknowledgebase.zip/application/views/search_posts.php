<!DOCTYPE html>
<html>
    <head>
        <title>PMSL</title>
<style>
.pagination-dive li {
    list-style: none;
    display: inline-block;
}
.pagination-dive a:hover, .pagination-dive .active a {
    background: #040404;
}

.pagination-dive a {
    display: inline-block;
    height: initial;
    background: #939890;
    padding: 10px 15px;
    border: 1px solid #fff;
    color: #fff;
}
</style>
         <?php include('head.php'); ?>
    </head>
    <body>
        <?php include('header.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">

            <section class="home-body-sec">
                <div class="container">
                    <?php include('sidebar.php'); ?>    
                    <div class="right-sec">
                        <div class="row">
                            <div class="col-xl-9 col-lg-9">
                                <h1 class=""> SEARCH RESULTS</h1>
                                <?php
                                
                               // echo $text;
                                ?>
                                <?php
                                if(!empty($datas)){
                                    foreach ($datas as $postd) {
                                        $post_t = $postd['post_title'];
                                        $post_date = $postd['posted_date'];
                                        $f_date =  date('d.m.Y' , strtotime($post_date));
                                        $poid = $postd['post_id'];
                                        $userid = $this->session->userdata('userid');
                                        $f_poid = base64_encode($poid);
                                        $noof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","post_id='$poid' and status='1'");
                                ?>

                                <div class="add-txt-sec single-sec">
                                    <h4> <a href="<?php echo base_url() . 'home/post/'.$f_poid; ?>"><?php 

                                    $text = $this->pgn->highlightKeywords($post_t,$title);
                                      echo $text;
                                      

                                    ?> </a></h4>
                                    <div class="add-list">
                                        <!--- VOTING START --->
                                            <?php 
                                                $dynlkdislksave = $this->Conference_model->showname_fromid("voting","tbl_post_voting","vpost_id='$poid' and vuserid='$userid' and voting in(1,2)");
                                                    $likestyle=''; $dislikestyle=''; 
                                                    if($dynlkdislksave==1) {
                                                        $likestyle = "style='color:green;'";
                                                    } else if($dynlkdislksave==2) {
                                                        $dislikestyle = "style='color:red;'";
                                                    }
                                                    
                                                 
                                    $noof_vots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$poid' and voting='1'");  

                                    $noof_unvots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$poid' and voting='2'");    
                                            ?>
                                            <!-- VOTING END ---> 
                                        
                                            <ul>
                                                <li>  <a href="javascript:void(0);"> <i class="fas fa-eye"></i> <?php echo ($postd['noof_views'] > 0) ? $postd['noof_views'] : '0' ;?>  views </a></li>

                                            <?php if($userid == ''){ ?>
                                             <li><a href="javascript:void(0);" data-toggle="modal"  data-target="#forget"><i class="fas fa-thumbs-up"></i> <?php echo $noof_vots.' Votes ';?> </a></li>

                                             <li><a href="javascript:void(0);" data-toggle="modal"  data-target="#forget"><i class="fas fa-thumbs-down"></i> <?php echo $noof_unvots.' Downvotes ';?> </a></li>
                                             <?php }else{?>

                                            <li><a href="javascript:void(0)" onClick="likedislikesave('<?php echo $userid;?>','<?php echo $poid;?>','1')"><i class="fas fa-thumbs-up" <?php echo $likestyle;?> id="likefrs_<?php echo $poid;?>"></i> <?php echo $noof_vots.' Votes ';?> </a></li>
                                                <!--<li><a href="javascript:void(0);"><i class="fas fa-thumbs-down"></i> 01 Vote </a></li>--->
                                             <li> <a href="javascript:void(0)" onClick="likedislikesave('<?php echo $userid;?>','<?php echo $poid;?>','2')"><i class="fas fa-thumbs-down" <?php echo $dislikestyle;?> id="dislikefrs_<?php echo $poid;?>"></i> <?php echo $noof_unvots.' Downvotes ';?> </a></li>
                                             
                                            <input type="hidden" name="curractivity_<?php echo $poid; ?>" id="curractivity_<?php echo $poid; ?>" value="<?php echo $dynlkdislksave;?>">

                                            <?php } ?>  


                                                <li>  <a href="#"> <i class="fa fa-calendar-alt"></i> <?php echo $f_date;?> </a></li>
                                                <li> <a href="javascript:void(0);"><i class="fas fa-reply"></i><?php echo  $noof_rec.' Answer'; ?></a></li>
                                                <li> <a href="javascript:void(0);"><i class="fas fa-clock"></i>
                                              <?php if(!empty($post_date)){
                                                    
                                                        $t1 = strtotime('now');
                                                        $t2 = strtotime($post_date);
                                                        $delta_T = ($t1 - $t2);
                                                        $day = round(($delta_T % 604800) / 86400); 
                                                        $hours = round((($delta_T % 604800) % 86400) / 3600); 
                                                        $minutes = round(((($delta_T % 604800) % 86400) % 3600) / 60); 
                                                        $sec = round((((($delta_T % 604800) % 86400) % 3600) % 60));

                                                        if($day){
                                                          echo $day.' days ' .' ago';
                                                        }else if($hours){
                                                          echo $hours.' hours ' .' ago';
                                                        }else if($minutes){
                                                         echo $minutes.' minutes ' .' ago';
                                                        }else{
                                                          echo $sec.' seconds ' .' ago';
                                                        }
                                                        
                                                        
                                                    }else{}?>


                                            </a></li>
                                            </ul>
                                        </div>
                                    <div class="replay-sec">
                                            
                                            
                                    </div>


                                </div>
                                <?php
  
                                 } 
                                }else{


                                ?>

                                <div class="replay-sec">
                                      <h6>No Data Found on search</h6>      
                                            
                                    </div>

                            <?php }?>
                                <div class="clearfix"></div>

                                  <div class="pagination-dive">
                                  <?php echo $nav; ?>
                                  </div>


                            </div>

                           <?php include('rsidebar.php'); ?>
                        </div>
                    </div>
                </div>
                
                <!-- MODEL SECTION FOR COMMENT USER LOGIN --->
           <div class="modal fade"  id="forget">
                    <div class="modal-dialog" >
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Login Here</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">
                            <div id="frmErrorsd"></div>  
                             <form  name="login_ans" id="login_ans" method="post">   
                                <div class="form-group">
                                    <input type="text" class="forgt-fld" name="username" id="username" placeholder="Username">
                                </div>
                                <div id="email_error"></div>
                                <div class="form-group">
                                    <input type="password" class="forgt-fld" name="password" id="password" placeholder="Password">
                                </div>
                                <div id="password_error"></div>
                                <button type="submit" name="log_cmt" id="log_cmt" class="forgt-submit">Submit</button>
                             </form>
                            </div>

                            <!-- Modal footer -->


                        </div>
                    </div>
                </div>
        <!--- MODEL SECTION FOR USER LOGIN ---->

            </section>
            <div class="clearfix"></div>

        </div>
        <?php include('footer.php');?>
        
        <script type="text/javascript">
            //url: "<?php //echo base_url(); ?>activity/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity,
       
    function likedislikesave(employeeid,jobid,activity,currentactivity = "")
          {
    var base_url = "";          
    var currentactivity = $("#curractivity_"+jobid).val();
         //var url= "<?php //echo base_url(); ?>activity/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity;
        $.ajax({
            url:"<?php echo base_url(); ?>home/likedislikesave/?employeeid="+employeeid+"&jobid="+jobid+"&activity="+activity,
            success:function(result)
            {
                 location.href = location.href;

                if(result=="new1") {
                    alert("Confirm");
                    $("#curractivity_"+jobid).val("1");
                    $('#likefrs_'+jobid).css({'color':'green'});
                    $('#dislikefrs_'+jobid).css({'color':''});
                }
                else if(result=="new2") {
                    $("#curractivity_"+jobid).val("2");
                    $('#likefrs_'+jobid).css({'color':''});
                    $('#dislikefrs_'+jobid).css({'color':'red'});
                    
                }
                else if(result=="updt1") {
                    $("#curractivity_"+jobid).val("");
                    $('#likefrs_'+jobid).css({'color':''});
                    
                }
                else if(result=="updt2") {
                    $("#curractivity_"+jobid).val("");
                    $('#dislikefrs_'+jobid).css({'color':''});
                    
                }
                
            }
        });
    
 }

       
</script>
        <script type="text/javascript"> 
jQuery("#login_ans").validate({
        rules: {
            username: {
                required: true,
                email: true
            },
            password: {
                required: true
            }
        },
        messages: {
            username: {
                required: "Enter Email ID",
                email: "Invalid Email"
            },
            password: {
                required: "Enter Password"
            }
        },

        errorPlacement: function (error, element)
    {
      if (element.attr("name") === "username" )
        error.appendTo("#email_error");
      else if (element.attr("name") === "password" )
        error.appendTo("#password_error");
      else
        error.insertAfter(element);
    },
  submitHandler: function(form) {
            $('#frmErrorsd').html('<div style="text-align:center"><i style="color:#377b9e" class="fa fa-spinner fa-spin fa-3x"></i> <span style="color:#377b9e">Processing...</span></div>');
            $.ajax({
                url: "<?php echo base_url(); ?>home/check_login",
                type: 'post',
                cache: false,
                processData: false,
                data: $('#login_ans').serialize(),
                success: function(result) {
                    if (result == 1) {
                      location.href = location.href;
                    } else {
                        jQuery("#frmErrorsd").html('<div class="errormsg"><i class="fa fa-times"></i> Invalid Username or Password.</div>');
                        //jQuery('#frm_LoginPop')[0].reset();
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
                    $('#frmErrorsd').html('<div class="errormsg"><i class="fa fa-times"></i> Invalid Username or Password.</div>');
                }
            });
            return false;
        }

   });

</script>
    </body>
</html>
