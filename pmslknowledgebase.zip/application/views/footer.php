        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-xl-8 col-lg-8">
                <p> © Copyright  <?php echo date("Y"); ?> PMSLTECH Knowledge Base all rights reserved</p>
                    </div>
                    <div class="col-sm-4 col-xl-4 col-lg-4">
                        <p class="float-right"> <a href="https://pmsltech.com/" target="_blank">Developed by Pmsltech.com</a></p>
                    </div>
                </div>
            </div>
        </footer>

        <!-- <script>(function(d,t,u,s,e){e=d.getElementsByTagName(t)[0];s=d.createElement(t);s.src=u;s.async=1;e.parentNode.insertBefore(s,e);})(document,'script','//pmsltech.com/livechat/php/app.php?widget-init.js');</script> -->
        <script src="<?php echo base_url();?>assets/js/jquery-3.2.1.slim.min.js"  type="text/javascript" ></script>
        <script src="<?php echo base_url();?>assets/js/popper.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/js/bootstrap-select.js"></script>


        <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <!--<script src="<?php //echo base_url(); ?>assets/js/bootstrap.min.js"></script>
        <script src="<?php //echo base_url(); ?>assets/js/bootstrap-select.js"></script>--->
        <script src="<?php echo base_url(); ?>assets/js/waypoints.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.counterup.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/wow.js"></script>

        <script type="text/javascript" src="<?php echo base_url();?>assets/js/droopmenu.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js_validation/jquery.validate.js"></script>
        <script src="<?php echo base_url(); ?>assets/js_validation/additional-methods.min.js"></script>
       <script src="<?php echo base_url(); ?>assets/js_validation/validation.js"></script>
       <script type="text/javascript">
     $(document).ready(function(){
    
    

}); 
</script>   
        <script type="text/javascript">
            jQuery(function ($) {
                $('.droopmenu-navbar').droopmenu({
                    dmAnimationEffect: 'dmfade'
                });
            });

        </script>      

        <script>
            $("#myButton").click(function () {
                $('html, body').animate({
                    scrollTop: $("#myDiv").offset().top
                }, 2000);
            });</script>

<script src="<?php echo base_url();?>assets/js/chat.js"  type="text/javascript" ></script>
         <!--- CHAT BOT SECTION START --->
             <!-- Chat Message Section -->
            <section class="custom_chat_msg">
            <div class="menuitem">
            <div class="pr">
            <?php /*<div class="start_chat_cnt">Hi there, Can l help you with anything?</div> */ ?>
            </div>
            <i class="fa fa-commenting" aria-hidden="true"></i>

            </div>

            <article>
            <aside>
            <h2>PMSLTECH</h2>
            <figure>
            <img src="<?php echo base_url(); ?>assets/images/George.png">
            <!--span>Susane @ Pmsltech</span-->
            </figure>
            <div class="top_chat_info">
            <p>Welcome to ConferenceAlert.com</p>
            <h3>How can we help you today?</h3>
            </div>
            </aside>
            <summary id="chat_summary">

            <div class="pr">
            <div class="loader_chat one">
            <div class="loader_circle">
            <div class="circleG load1"></div>
            <div class="circleG load2"></div>
            <div class="circleG load3"></div>
            </div>
            </div>
            <div class="chart_cnt one display_none">
            <p>Hi, I'm Aston. It is my pleasure to guide you thourgh Conference Alert.</p>
            </div>
            </div>

            <div class="pr">
            <div class="loader_chat two display_none">
            <div class="loader_circle">
            <div class="circleG load1"></div>
            <div class="circleG load2"></div>
            <div class="circleG load3"></div>
            </div>
            </div>
            <div class="chart_cnt two display_none">
            <p>Please let me know how can I help you? Choose one of the options below:</p>
            </div>
            </div>

            <div class="choose_proj display_none">
            <div class="proj_mcbox app1">
            <a href="javascript:void(0)" class="btn-cmn-effect"><img src="<?php echo base_url(); ?>assets/images/eveicon.png" width="40" height="40"> <span>Add conference</span></a>
            </div>
            <div class="proj_mcboxs app2">
            <a href="javascript:void(0)" class="btn-cmn-effect"><img src="<?php echo base_url(); ?>assets/images/eveicon.png" width="40" height="40"> <span>Get conference alerts</span></a>
            </div>
            <div class="proj_mcboxq app3">
            <a href="javascript:void(0)" class="btn-cmn-effect"><img src="<?php echo base_url(); ?>assets/images/eveicon.png" width="40" height="40"> <span>Advertising with us</span></a>
            </div>

            <div class="proj_mcboxu app6">
            <a href="javascript:void(0)" class="btn-cmn-effect"><img src="<?php echo base_url(); ?>assets/images/eveicon.png" width="40" height="40"> <span>Others...</span></a>
            </div>
            <div class="cb"></div>
            </div>

            <div class="chart_ans_btn proj_ans_sec"><span>I'm interested for</span></div>

            <div class="chart_ans_btn proj_ans_secon" style="display: none;"><span>I'm always</span></div>

             <div class="chart_ans_btn proj_ans_secon1" style="display: none;"><span>gobinda</span></div>

              <div class="chart_ans_btn proj_ans_secon2" style="display: none;"><span>jaykala</span></div>
           

            <div class="pr">
            <div class="loader_chat three display_none">
            <div class="loader_circle">
            <div class="circleG load1"></div>
            <div class="circleG load2"></div>
            <div class="circleG load3"></div>
            </div>
            </div>
            <div class="chart_cnt email_chart display_none">
            <p>For more help, kindly provide your name & email id below. Our support team will reach you within 24 hours.</p>
            </div>
            </div>

            <div class="chart_ans_btn get_mail_txt"><span></span></div>

            <div class="pr">
            <div class="loader_chat four display_none">
            <div class="loader_circle">
            <div class="circleG load1"></div>
            <div class="circleG load2"></div>
            <div class="circleG load3"></div>
            </div>
            </div>
            <div class="chart_cnt thnax_msg display_none">
            <p>Alright, let's get you connected with one of our consultants and he/she will guide you further based on your requirements. Welcome to ConferenceAlert!</p>
            </div>
            </div>

            </summary>

            <div class="power_by">
            <div class="chat_btm_type display_none">
            <form name="" action="" method="post">
            <input name="writechat" id="writechat" placeholder="Please provied your email ID" type="email">
            <input id="app-name-chat" type="hidden">
            </form>
            <div class="click_echat" id="clickChat"></div>
            </div>
            <span><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Conference" width="70" height="11"></span>
            </div>

            </article>
            </section>
<!-- Chat Message Section -->
        <!--- CHAT BOT SECTION END --->            