       

            <div class="copyright">
                <div class="container">
                    <div>
                        <div class="row">
                            <div class="col-md-9 col-xl-9 col-lg-9">
                                <p> Copyright © 2018 Conference Hub All Rights Reserved. <a href="https://pmsltech.com/" target="_blank">Developed By Pmsltech.com</a></p>
                            </div>
                            <div class="col-md-3 col-xl-3 col-lg-3">
                                <div class="social-list">
                                    <ul>

                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li> <a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                        <li> <a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li> <a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

  


      