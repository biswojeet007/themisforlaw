<!DOCTYPE html>
<html>
  <head>
     <?php include('head.php'); ?>     
  </head>
  <body>
    <div class="user-page">
      <?php include('header.php'); ?>
      <div class="min-height">
           <section class="home-body-sec">
          <div class="container">
            <div class="row">
              <div class="col-xl-3 col-lg-3"></div>
              <div class="col-xl-6 col-lg-6">
              
                  <form class="login-form text-center brdr-animation" name="change_password" id="change_password" method="post" >
                  <?php echo $message; ?>
                   <?php
                      if($validmsg!='')
                      {
                      ?>
                    <div class="form-group">
                      <div class="col-xl-12 col-lg-12">
                        <span style="color:#990000;padding:50px 30px 50px 30px;"><b> <?php echo $validmsg; ?> </b></span>
                      </div>
                    </div>
                    <?php
                      }
                      else if(($diffrnc>=0) && ($numuserforgot>0))
                      {
                      ?>
                   
                    
                    <h1 class="inrforgot-txt">Forgot Password</h1>
                    <div id="login-1st">
                      


                       <div class="form-group">
                                         <input class="logn-fld" placeholder="New Password " type="password" id="new_pwd" name="new_pwd" maxlength="20"/>
                                    </div>


                      <div id="rplc_new_pwd"></div>
                           <div class="form-group">
                                          <input class="logn-fld" placeholder="Confirm New Password " type="password" id="cnf_pwd" name="cnf_pwd" maxlength="20"/>
                                    </div>

                    
                       <div id="rplc_cnf_pwd"></div>
                      <div class="text-center">
                        <div class="row">
                          <div class="col-xl-6 col-lg-6"> <button type="submit" class="form-submit" id="btnSubmit" name="btnSubmit"  >Submt</button></div>
                             <div class="col-xl-6 col-lg-6"> <button type="reset" class="form-submit">Reset</button> </div>
                        </div>
                       
                                              
                      </div>
                      
                    </div>

                      <?php
                      }
                      else
                      {
                      ?>
                      <div class="new-sign-up">
                        <div class="new-sign-up-title"> <a href="<?php echo base_url().'login'?>"><strong> Click Here to Log in</strong></a></div>
                      </div>
                       <?php
                      }
                      ?>                  
                    <input type="hidden" name="hiduserid" id="hiduserid" value="<?php echo $getuserid; ?>"/>
                  </form>
               
              </div>
            </div>
          </div>
        </section>
      </div>
      
       <?php include('footer.php'); ?>
     
    </div>  
    <script src="<?php echo base_url(); ?>assets/js/jquery-3.2.1.slim.min.js"  type="text/javascript" ></script>  
    <script src="<?php echo base_url(); ?>assets/js_validation/jquery.validate.js"></script>
    <script src="<?php echo base_url(); ?>assets/js_validation/validation.js"></script>
    <script>var base_url = "<?php echo base_url(); ?>";</script>
  </body>
</html>