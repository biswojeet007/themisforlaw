<?php $segment = $this->uri->segment(1); ?>   
<?php
$sess_uid = $this->session->userdata('userid');
$rowss = $this->Conference_model->get_records("*", "tbl_user", "user_id='$sess_uid'");
if(!empty($rowss)){
foreach ($rowss as $rowsa) {
    $pic = $rowsa['user_pic'];
 }
} 
?>       
          <header>
            <div class="topheader">
                <div class="container">
                    <div class="row">
                    <?php if($this->session->userdata('userid') != "") 
                    $classactive = 'class="col-xl-2 col-lg-2"'; else $classactive = 'class="col-xl-3 col-lg-3"';
                    ?>
                        <div <?php echo $classactive;?>>
                            <div class="logo">
                                <a href="<?php echo base_url();?>">  <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="" class="img-fluid"/></a>
                            </div>
                        </div>
                    

                        <div class="col-xl-4 col-lg-4">
                    <form name="search_frm" id="search_frm" method="get" action="<?php echo base_url(); ?>search-posts" >
                            <div class="search-sec">
                                
                                <input type="text" class="search-fld" name="search_qa" value="<?php if(!empty($search_title)){ echo $search_title; } ?>"  placeholder="Search " id="search_qa" required="">
                                <button type="submit" class="search-btm"  ><i class="fa fa-search"></i></button>
                            </div>
                            </form>
                        </div>

                    <?php if($this->session->userdata('userid') != "") 
                    $classactivef = 'class="col-xl-6 col-lg-6"'; else $classactivef = 'class="col-xl-5 col-lg-5"';
                    ?>
                        <div <?php echo $classactivef;?>>
                            <div class="top-menu-list float-right">
                                <ul>
                                    <!--                                    <li> <a href="#"> <i class="fas fa-question-circle"></i> </a></li>
                                                                        <li><a href="#"> <i class="fas fa-bell"></i></a></li>-->
                                    <!---<li><a href="#"> <i class="fas fa-bell"></i></a></li>--->
                                    <li><a href="<?php echo base_url();?>add-post"> Add Post</a></li>
                                    <?php if($this->session->userdata('userid') != "") { ?>
                                    <li><a href="<?php echo base_url();?>activity">
                                        <?php if(!empty($pic) && file_exists("./assets/images/".$pic) && ($pic!='')){ ?> 
                                            <span class="acount-img"><img src="<?php echo base_url() . 'assets/images/' . $pic; ?>" alt="" class="img-fluid"> </span>
                                        <?php } ?>

                                          <em><?php echo $this->session->userdata('username'); ?></em></a>
                                    </li>
                                    <li> <a href="<?php echo base_url();?>setting"> Setting</a></li>
                                    <li> <a href="<?php echo base_url().'logout'; ?>"> Logout</a></li>
                                <?php }else{ ?>
                                    <li> <a href="<?php echo base_url();?>login"> Login</a></li>
                               <?php  } ?>
                                </ul>
                            </div>
                        </div>



                    </div>

                    <div class="droopmenu-navbar">
                        <div class="droopmenu-inner">
                            <div class="droopmenu-header">                   
                                <a href="#" class="droopmenu-toggle"></a>                
                            </div><!-- droopmenu-header -->
                            <div class="droopmenu-nav">
                                <ul class="droopmenu">
                                    <li><a href="<?php echo base_url();?>add-post"> Add Post</a></li>
                                    <?php if($this->session->userdata('userid') != "") { ?>
                                    <li><a href="<?php echo base_url();?>activity">
                                        <?php if(!empty($pic) && file_exists("./assets/images/".$pic) && ($pic!='')){ ?> 
                                            <span class="acount-img"><img src="<?php echo base_url() . 'assets/images/' . $pic; ?>" alt="" class="img-fluid"> </span>
                                        <?php } ?>

                                          <em><?php echo $this->session->userdata('username'); ?></em></a>
                                    </li>
                                    <li> <a href="<?php echo base_url();?>setting"> Setting</a></li>
                                    <li> <a href="<?php echo base_url().'logout'; ?>"> Logout</a></li>
                                <?php }else{ ?>
                                    <li> <a href="<?php echo base_url();?>login"> Login</a></li>
                               <?php  } ?>  
                                </ul>
                            </div><!-- droopmenu-nav -->            
                        </div><!-- droopmenu-inner -->
                    </div><!-- droopmenu-navbar  -->
                </div>



            </div>



        </header>