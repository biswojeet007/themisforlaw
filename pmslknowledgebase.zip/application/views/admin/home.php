<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
    </head>
    <body class=" body-img" >

        <header>

            <div class="topheader">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="<?php echo base_url(); ?>admin"> <img src="<?php echo base_url(); ?>assets/admin/images/logo.png" class="img-fluid" alt=""/></a>
                            </div>
                        </div>



                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </header>
        <div class="min-height">
            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6"></div>
                        <div class="col-xl-6 col-lg-6">
                            <div class="logon-frm">
                                <form class="" name="loginform" id="loginform" method="post" >
                                    <?php echo $message; ?>
                                    <div class="login-title"> Log In</div>

                                    <div id="login-1st">
                                        <div class="login-fld-sec">
                                            <i class="fa fa-user"></i>
                                            <input class="login-fld" placeholder="Username or Email " type="text" id="email" name="email" value="<?php echo set_value('email'); ?>"  />

                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="log-in-btm" name="btnSignin1" id="btn-1" >Continue</button>
                                        </div>
                                    </div>

                                    <div id="" class="collapse login-2nd">
                                        <div class="login-fld-sec">
                                            <i class="fa fa-lock"></i>
                                            <input class="login-fld" placeholder="Password " type="password" id="password" name="password" value="<?php echo set_value('password'); ?>"> 
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="log-in-btm" id="btnSignin" name="btnSignin">Log In</button>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-md-6" id="back1">
                                                <a class="forgt-psd" href="javascript:void(0)"> Back</a>
                                            </div>
                                            <div class="col-md-6">
                                                <a class="forgt-psd float-right" href="#" data-toggle="collapse" data-target="#demo"> Forgot Password?</a>
                                            </div>
                                        </div>


                                    </div>

                                </form>

                                <div id="" class="collapse login-2nd">
                                    <div class="col-md-12">
                                        <form  role="form" name="forgot_password" id="forgot_password" method="post">

                                            <div id="demo" class="collapse forgt-sec">
                                                <div class="login-fld-sec">
                                                    <i class="fa fa-user"></i>
                                                    <input class="login-fld" placeholder="Email  Id" type="text" id="forgotemail" name="forgotemail"> 
                                                </div>
                                                <div class="text-center" >
                                                    <div id="msg-forgot"></div>
                                                    <button type="submit" class="log-in-btm" name="" >Submit</button>


                                                </div>

                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!--                        <div class="col-xl-3 col-lg-3"></div>-->
                    </div>
                </div>
            </section>

        </div>

        <?php include("footer.php"); ?>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/js_validation/jquery.validate.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js_validation/validation.js"></script>

        <script>var base_url = "<?php echo base_url(); ?>";</script>
        <script>
            $(document).ready(function () {





                jQuery("#forgot_password").validate({
                    rules: {
                        forgotemail: {
                            required: true,
                            email: true
                        }
                    },
                    messages: {
                        forgotemail: {
                            required: "Enter email id",
                            email: "Invalid email id"
                        }
                    },
                    submitHandler: function (form) {
                        var forgotemail = $("#forgotemail").val();
                        if (forgotemail != '')
                        {
                            jQuery('#msg-forgot').html('<div style="text-align:center"><i style="color:#377b9e" class="fa fa-spinner fa-spin fa-3x"></i> <span style="color:#377b9e">Processing...</span></div>');
                            jQuery.ajax({
                                type: "POST",
                                url: "<?php echo base_url(); ?>admin/home/forgot_email/?forgotemail=" + forgotemail,
                                success: function (res) {
                                    jQuery("#msg-forgot").html(res);
                                },
                                error: function (XMLHttpRequest, textStatus, errorThrown) {
                                    alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
                                }
                            });
                            return false;
                        }
                        return false;
                    }
                });
            });
        </script>

        <script>

            $(document).ready(function () {
                $("#btn-1").click(function () {
                    if ($("#email").valid()) {
                        $("#password").rules('add', {
                            required: true,
                            regex: "^[a-zA-Z0-9\-_#!`~\/\\*?@}{&$%^();,.+=|:\ \r\n]+$",
                            rangelength: [6, 12],
                            messages: {
                                required: "Enter password",
                                rangelength: "Password length must be between {0} to {1}"
                            }
                        });
                        $("#login-1st").hide();
                        $(".login-2nd").fadeIn(1000);
                    }
                    return false;
                });
            });

            $(document).ready(function () {
                $("#back1").click(function () {
                    $(".login-2nd").hide();
                    $("#login-1st").fadeIn(1000);
                });
            });

        </script>


    </body>
</html>
