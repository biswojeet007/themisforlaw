<!DOCTYPE html>
<html>
    <head>
        <?php include("head.php"); ?>
    </head>
    <body class="body-img inr-body-img">
        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">
                <div class="container-fluid ">
                    <?php include("sidemenu.php"); ?>
                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fas fa-tachometer-alt"></i>
                            <h1>Dash Board </h1>
                        </div>
                        <div class="row">
                            <!----<div class="col-xl-4 col-lg-4">
                               <div class="dashboard-box">
                                  <i class="far fa-flag"></i>
                                  <h1> <a href="<?php echo base_url(); ?>admin/country">Country</a></h1>
                               </div>
                            </div>
                            <div class="col-xl-4 col-lg-4">
                               <div class="dashboard-box bg-ornage ">
                                  <i class="far fa-list-alt"></i>
                                  <h1> <a href="<?php echo base_url(); ?>admin/category">Category</a></h1>
                               </div>
                            </div>
                            <div class="col-xl-4 col-lg-4">
                               <div class="dashboard-box bg-gray">
                                  <i class="fas fa-cogs"></i>
                                  <h1> featured events</h1>
                               </div>
                            </div>
                            <div class="col-xl-8 col-lg-8">
                               <div class=" manage-event">
                                  <h1> manage Events</h1>
                                  <ul>
                                     <li><a href="<?php echo base_url(); ?>admin/new_event"> New Events</a></li>
                                     <li><a href="<?php echo base_url(); ?>admin/pending_event"> Pending Event</a></li>
                                     <li><a href="<?php echo base_url(); ?>admin/accept_event"> Accepted Event</a></li>
                                     <li><a href="<?php echo base_url(); ?>admin/reject_event"> Rejected Event</a></li>
                                     <li><a href="<?php echo base_url(); ?>admin/search_event"> Search Event</a></li>
                                  </ul>
                               </div>
                            </div>
                            <div class="col-xl-4 col-lg-4">
                               <div class="dashboar-datepicker">
                                  <div class="datepicker"></div>
                               </div>
                            </div>------>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>
        <script id="script" type="text/javascript">
            // jQuery(document).ready(function () {
            //     jQuery("#menuzord").menuzord({
            //         align: "left",
            //         effect: "fade",
            //         animation: "drop-up"
            //     });  
            // });

            $(function () {
                $('.datepicker').datepicker({
                    format: 'mm/dd/yyyy',
                    todayHighlight: true,
                    autoclose: true
                }).on('changeDate', function (ev) {
                    var date = ev.date;
                    var newdate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear();
                    var finalDate = encodeURIComponent(window.btoa(newdate));
                    window.location = "<?php echo base_url() . 'admin/events/'; ?>" + finalDate;
                });
            });



        </script>
    </body>
</html>