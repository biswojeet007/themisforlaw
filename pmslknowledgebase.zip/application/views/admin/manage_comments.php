<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
        <link href="<?php echo base_url(); ?>assets/admin/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>



                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-comment"></i>
                            <h1>Manage Comments </h1>
                        </div>
                         <form class="panelsearch form-search col-md-4 " style="float: right;" name="form_search" method="post">
                            <div class="input-group">
                                <input type="text" class="form-control defl-fld" placeholder="Search Comments " name="search" value="<?php echo set_value('search', $search); ?>">
                                <span class="input-group-btn">
                                    <button class="defl-fld-btm" type="submit">Search</button>
                                </span>
                            </div><!-- /input-group -->
                        </form><div class="clearfix"></div>
                        <div class="row" style="margin-top: 10px;">

                            <div class="col-xl-12 col-lg-12">
                <!--<a href="<?php //echo base_url(); ?>admin/tags/add" class="adduser"> Add Tags</a>
                                <div class="add-line"></div>-->
                                <div class="row">
                                   <?php echo $message; ?>
                                    <div class="col-xl-12 col-lg-12"> 
                                        <div class="table-responsive">
                                            <div id="success_msg"></div>
                                            <table  class="table table-bordered table-striped table-hover mng-tbl-txt">
                                                <thead>
                                                    <tr class="info">
                                                        <th width="8%">Sl #</th>
                                                        <th width="10%">Title</th>
                                                        <th width="12%">Name</th>
                                                        <th width="10%">Comments</th>
														<th width="10%">Date</th>
                                                        <th width="8%">Status</th>
                                                        <th width="11%">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php
                                    $cnt = isset($startfrom) ? $startfrom : 0;
                                    if( !empty($rows) )
                                    {
                                        foreach ($rows as $rowsg)
                                        {
                                            $cnt++;
                                            $user_id = $rowsg['user_id'];
                                            $post_id = $rowsg['post_id'];
                                            $f_poid = base64_encode($post_id);
                                            $usercomm = $rowsg['user_cmt'];
                                            $cmted_id = $rowsg['cmt_id'];
                                            $commmentedd = $rowsg['commented_date'];
                                            $status = $rowsg['status'];
                                    $rect_user = $this->Conference_model->showname_fromid("post_title","tbl_posts","post_id='$post_id'");

                                    $rec_user = $this->Conference_model->showname_fromid("username","tbl_user","user_id='$user_id'");
                                           
                                    ?>
                                                    <tr id="removepost-<?php echo $post_id; ?>">
                                                        <td><?php echo $cnt; ?></td>
                                                        <td><a href="<?php echo base_url() . 'home/post/'.$f_poid; ?>" target="_blank"><?php echo $rect_user; ?></a></td>
                                                        <td>
                                                <a href="<?php echo base_url() . 'admin/website_user/view/' . $user_id; ?>"><?php echo $rec_user; ?></a>
                                        </td>
                                                        <td><?php echo mb_strimwidth($usercomm, 0, 140, "..."); ?></td>
                                                        <td><?php echo date(' dS  F  Y ' , strtotime($commmentedd)); ?></td>
                                                        <!---<a href="<?php //echo base_url() . 'home/post/'.$f_poid; ?>" target="_blank"></a> --->
                                                        <td>
                                                         <?php if($status==1) { ?>
                                                <span class="status" data-id="<?php echo "status-".$cmted_id; ?>"><a href="javascript:void(0)" title="Status is active. Click here to make it inactive."><span class="label-custom label label-success">Active</span></a></span>
                                           <?php } else { ?>
                                            <span class="status" data-id="<?php echo "status-".$cmted_id; ?>"><a href="javascript:void(0)" title="Status is inactive. Click here to make it active."><span class="label-custom label label-danger">Inactive</span></a></span>
                                             <?php } ?>   
                                                        </td>
                                                   
                                                
                                                        <td>

                                                            <a href="<?php echo base_url().'admin/comments/edit/'.$cmted_id; ?>" class="btn btn-success btn-sm view tbl-icon-btm" title="Edit"> <i class="far fa-edit"></i></a>

                                                            <a href="<?php echo base_url() . 'admin/comments/view/' . $cmted_id; ?>" class="btn btn-primary btn-sm view tbl-icon-btm" title="View"> <i class="far fa-eye"></i></a>
                                                            
         <a onClick="return confirm('Are you sure to delete this Comment?')" href="<?php echo base_url() . 'admin/comments/delete/' . $cmted_id; ?>" class="btn btn-danger btn-sm tbl-icon-btm" title="Delete"><i class="far fa-trash-alt"></i> </a>

                                                        </td>
                                                    </tr>
                                    <?php

                                        }
                                    }
                                    else
                                    {
                                    ?>
                                    <tr>
                                        <td class="text-center" colspan="8"> No data available in table </td>
                                    </tr>
                                    <?php
                                    }
                                    ?>

                                                </tbody>
                                            </table>
                                            <div class="user-pagination" style="float: right;">                                        
                                                <?php echo $pagination; ?>
                                            </div>
                                        </div>
                                    </div>





                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
       <?php include("footer.php"); ?>
       <script src="<?php echo base_url(); ?>assets/admin/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/dataTables.bootstrap4.min.js" type="text/javascript"></script>

    <script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
    });

    </script>

    <script type="text/javascript">

$(document).on('click', '.status', function(){
    if(confirm('Are you sure to change the status?'))
    {
        var val = $(this).data("id");
        var valsplit = val.split("-");
        var id = valsplit[1];
        jQuery('[data-id='+val+']').after('<div class="spinner" style="text-align:center;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-1x"></i></div>');
        $.ajax({
            url: "<?php echo base_url(); ?>admin/comments/changestatus/"+id,
            type: 'post',
            cache: false,
            processData: false,
            success: function (data) {
                jQuery('.spinner').remove();
                if(data == 1) //Inactive
                {
                    jQuery('[data-id='+val+']').html('<a href="javascript:void(0)" title="Status is inactive. Click here to make it active."><span class="label-custom label label-danger">Inactive</span></a>');
                }
                else if(data == 0) //Active
                {
                    jQuery('[data-id='+val+']').html('<a href="javascript:void(0)" title="Status is active. Click here to make it inactive."><span class="label-custom label label-success">Active</span></a>');
                }
                else
                {
                    alert("Sorry! Unable to change status.");
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
            }
        });
    }
});
</script>


 </body>
</html>
