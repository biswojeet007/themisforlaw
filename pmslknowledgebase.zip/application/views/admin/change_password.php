<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>



                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-users"></i>
                            <h1>Change Password</h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-6 col-lg-6">

                                <div  style="margin-bottom: 25px; box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16); background-color:#fff; padding:25px;border-radius: 4px;">
                                    <form class="add-user" method="post" name="change_password" id="change_password">

                                        <?php echo $message; ?>

                                        <div class="form-group">
                                            <label>Email ID</label>
                                            <input type="text" class="form-control" name="uname" id="uname" value="<?php echo $this->session->userdata('adminemail'); ?>" readonly="readonly">
                                        </div>

                                        <div class="form-group">
                                            <label>New Password</label>
                                            <input type="password" class="form-control" placeholder="Enter new password" name="new_pwd" id="new_pwd" maxlength="20">
                                        </div>

                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input type="password" class="form-control" placeholder="Enter confirm password" name="cnf_pwd" id="cnf_pwd" maxlength="20">
                                        </div>

                                        <div class="reset-button"> 
                                            <button type="submit" class="redbtn" name="btnSubmit" id="btnSubmit">Save</button>
                                            <button type="reset" class="blackbtn">Reset</button>  
                                        </div>

                                    </form>

                                </div>
                            </div>

                            <div class="clearfix"></div>

                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/js_validation/jquery.validate.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js_validation/validation.js"></script>

    </body>
</html>
