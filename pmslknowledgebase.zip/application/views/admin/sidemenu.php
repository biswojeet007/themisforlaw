<?php
    $segment = $this->uri->segment(2);
    $allusermodules = $this->session->userdata('allpermittedmodules');
    ?>
<div class="Left-sec ">
                        <div class="nav-side-menu">

                            <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

                            <div class="menu-list">

                                <ul id="menu-content" class="menu-content">
                                    <?php if($segment == 'dashboard') $classactive = 'class="menuactive"'; else $classactive = ""; ?>
                                    <li <?php echo $classactive; ?>>
                                        <a href="<?php echo base_url(); ?>admin/dashboard">
                                            <i class="fas fa-tachometer-alt"></i> Dashboard
                                        </a>
                                    </li>
                                        <?php
                                        if(in_array(1, $allusermodules))
                                        {
                                             if($segment == 'user') $classactive = 'class="menuactive"'; else $classactive = ""; 
                                        ?>
                                    <li   <?php echo $classactive; ?> >
                                        <a href="<?php echo base_url(); ?>admin/user">
                                            <i class="fas fa-users"></i> Users
                                        </a>
                                    </li>
                                    <?php
                                     }
                                     ?>

                                      <?php
                                       /**if(in_array(2, $allusermodules))
                                        {
                                            if($segment == 'continents' || $segment == 'country' || $segment == 'category' || $segment == 'subcategory' || $segment == 'designation' || $segment == 'event_type') { $collapse = "collapsed"; $show = "show"; } else { $collapse = ""; $show = ""; }
                                            
                                        ?>
                                         <li data-toggle="collapse" data-target="#master" class="collapsed">
                                        <a href="javascript:void(0)"><i class="fas fa-calendar"></i> Master Module <span class="arrow"></span></a>
                                    </li>
                                     <ul class="sub-menu collapse treeview-menu" id="master" >  

                                    <li><a href="<?php echo base_url(); ?>admin/continents"><i class="fas fa-globe-americas"></i> Continents  </a>  </li>
                                   
                                    <li ><a href="<?php echo base_url(); ?>admin/country"><i class="far fa-flag "></i> Country  </a>  </li>
                                    <li ><a href="#"><i class="fas fa-city"></i> City  </a>  </li>
                                    <li ><a href="<?php echo base_url(); ?>admin/category"><i class="far fa-list-alt "></i>Event Category  </a>  </li>
                                    <li ><a href="<?php echo base_url(); ?>admin/subcategory"><i class="far fa-list-alt "></i> Event Topic  </a>  </li>
                                    <li ><a href="<?php echo base_url(); ?>admin/designation"><i class="fa fa-user-tie "></i> Designation  </a>  </li>
                                  <li ><a href="<?php echo base_url(); ?>admin/event_type"><i class="fa fa-user-tie "></i> Event Type  </a>  </li>
                                   </ul>**/
                                    //<?php
                                     //}
                                     ?>
                        
									<?php
                                     if(in_array(2, $allusermodules))
                                        {
                                           if($segment == 'tags') $classactive = 'class="menuactive"'; else $classactive = "";
                                        ?>

                                 <li <?php echo $classactive; ?>><a href="<?php echo base_url(); ?>admin/tags"><i class="fas fa-tag"></i> Tags  </a>  </li>


                                     <?php
                                     }
                                     ?>
									
									
									
									
                               
                                     <?php
                                     if(in_array(3, $allusermodules))
                                        {
                                           if($segment == 'common_settings') $classactive = 'class="menuactive"'; else $classactive = "";
                                        ?>

                                 <li <?php echo $classactive; ?>><a href="<?php echo base_url(); ?>admin/common_settings"><i class="fas fa-cog"></i> Common Settings  </a>  </li>


                                     <?php
                                     }
                                     ?>
									
									<?php 
									if(in_array(4,$allusermodules))
									{
									 if($segment == 'website_user') $classactive = 'class="menuactive"'; else $classactive = "";
                                        ?>

                                 <li <?php echo $classactive; ?>><a href="<?php echo base_url(); ?>admin/website_user"><i class="fas fa-user-tie"></i> Website Users  </a>  </li>	
									<?php	
									}
									 ?>

                                     <?php
                                        if(in_array(5, $allusermodules))
                                        {
                                             if($segment == 'posts') $classactive = 'class="menuactive"'; else $classactive = ""; 
                                        ?>
                                    <li   <?php echo $classactive; ?> >
                                        <a href="<?php echo base_url(); ?>admin/posts">
                                            <i class="fa fa-sticky-note"></i> Manage Posts
                                        </a>
                                    </li>
                                    <?php
                                     }
                                     ?>

                                     <?php
                                        if(in_array(6, $allusermodules))
                                        {
                                             if($segment == 'comments') $classactive = 'class="menuactive"'; else $classactive = ""; 
                                        ?>
                                    <li   <?php echo $classactive; ?> >
                                        <a href="<?php echo base_url(); ?>admin/comments">
                                            <i class="fas fa-comment"></i> Manage Comments
                                        </a>
                                    </li>
                                    <?php
                                     }
                                     ?>
									


                                      <?php if($segment == 'change_password') $classactive = 'class="menuactive"'; else $classactive = ""; ?>

                                    <li <?php echo $classactive; ?>>
                                        <a href="<?php echo base_url(); ?>admin/change_password">
                                            <i class="fa fa-lock "></i> Change Password
                                        </a>
                                    </li>

                                    <li>
                                        <a href="<?php echo base_url(); ?>admin/logout">
                                            <i class="fas fa-sign-out-alt"></i> Logout
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
