<header>

            <div class="topheader">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <a href="<?php echo base_url(); ?>admin/dashboard"> <img src="<?php echo base_url(); ?>assets/admin/images/logo.png" class="img-fluid" alt=""/></a>
                            </div>
                        </div>


                        <div class="col-xl-10 col-lg-10">

                            <div class="my-account-list">
                                <ul>

                                    <li> 
                                        <div class="message-sec">
                                            <i class="fa fa-bell"></i> <span>1</span> 
                                        </div>
                                        <div class="left-menu">
                                            <p> PMSLTECH KNOWLEDGEBASE  </p>
                                        </div>

                                    </li>

                                    <li> 
                                        <div class="message-sec">
                                            <i class="fa fa-envelope"></i> <span>2</span> 
                                        </div>
                                        <div class="left-menu">
                                            <p> PMSLTECH KNOWLEDGEBASE  </p>
                                        </div>

                                    </li>

               
                                    <li> <?php if($this->session->userdata('adminid') != "") { ?> <a href="#"> <span class="acount-img"><img src="<?php echo base_url(); ?>assets/admin/images/account-img.jpg" alt="" class="img-fluid"/> </span> <?php echo $this->session->userdata('adminname'); ?> <span class="fa fa-chevron-down"></span> </a>
                                        <div class="left-menu">
                                            <ul>
                                                
                                                <li><a href="<?php echo base_url(); ?>admin/change_password">Change Password</a></li>
                                            <li><a href="<?php echo base_url(); ?>admin/logout">Sign Out</a>

                                              <?php } ?>
                                            </li>
                                            </ul>
                                        </div>

                                    </li>

                                </ul>
                            </div>





                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </header>