<?php $this->output->set_status_header('404'); ?>
<!DOCTYPE html>
<html>
    <head>
        <title>PMSL</title>
        <?php include('head.php'); ?>
    </head>
    <body>

        <?php include('header.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">

          <div class="four-msg">
                <img src="<?php echo base_url().'assets/images/Page-not-found.png'; ?>" class="pagenot-found">
                <!--<p class="pagenot-found-content">The page you requested was not found.</p>-->
            </div>  
            

        </div>
        <?php include('footer.php'); ?>


    </body>
</html>
