<?php
foreach ($row as $rows)
{
    
    $user_id = $rows['user_id']; 
    $username = $rows['username'];
	$usertitle = $rows['user_title'];
    $useremail = $rows['user_email'];
	$userpic = $rows['user_pic'];  
	$userdesc = $rows['user_desc']; 
    $status = $rows['status']; 
    $date = $rows['created_date'];                             
    
}

?>
<!DOCTYPE html>

<html>
    <head>
       <?php include("head.php"); ?>
       <link href="<?php echo base_url();?>assets/admin/qacss.css?v=1.1" rel="stylesheet" type="text/css"/>
    </head>
    <body class="body-img inr-body-img">

       <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-user-tie"></i>
                            <h1>Website Users </h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/website_user" class="adduser"> Manage Website Users</a>
                                <div class="add-line"></div>
                                <div class="row">

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt3"> Website User : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">  <?php echo $username; ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt3"> Title:</div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">  <?php echo $usertitle; ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									
                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt3"> Email Id :</div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">  <?php echo $useremail; ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									
									<div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt3"> Image :</div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">  
					<?php if(file_exists("./assets/images/".$userpic) && ($userpic!=''))
								{
									echo '<a href="'.base_url().'assets/images/'.$userpic.'" target="_blank"><img src="'.base_url().'assets/images/'.$userpic.'" style="width:70px;height:70px" alt="image" class="img_fluid " /></a>';
								}?>
													</div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									
								<div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt3"> Date :</div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1"><?php echo date(' dS  F  Y ' , strtotime($date)); ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt3"> Status :</div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1"><?php if($status==1){echo 'Active';}else{echo 'Inactive';} ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                     <div class="clearfix"></div>

                                    <div class="col-xl-12 col-lg-12"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-2 col-lg-2">
                                                    <div class="name-txt3"> Description :</div>
                                                </div>
                                                <div class="col-xl-10 col-lg-10">
                                                    <div class="name-txt2">  <?php echo $userdesc; ?></div> 
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                   
                                        <hr>
                                <div class="clearfix"></div>
                                

                                      <div class="col-xl-12 col-lg-12"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-12 col-lg-2">
                                                    <div class="name-newtxt"> User Posts:</div>
                                                </div>
                                                <div class="col-xl-12 col-lg-10">
                                                    <?php 
                                                    $userid = $user_id;
                                                    $noof_rec = $this->Conference_model->noof_records("post_id","tbl_posts","user_id='$userid'");
                                                    ?>
                                    <!--<div class="activity-title" style="font-size:13px;">My Posts <?php //echo '('.$noof_rec.')';?></div>-->
                                                    <div class="clearfix"></div>
                                                    <?php

                                                    $noof_recss = $this->Conference_model->noof_records("post_id", "tbl_posts", "user_id='$userid'");

                                          $config['base_url'] = base_url().'admin/website_user/view/'.$user_id.'/page/';
                                                    $config['first_url'] = base_url().'admin/website_user/view/'.$user_id;
                                                    $config["uri_segment"] = 6;
                                                    $config['total_rows'] = $noof_recss;
                                                    $config['per_page'] = $this->Conference_model->per_page;
                                                    $config["num_links"] = $this->Conference_model->num_links;
                                                    $config["use_page_numbers"] = TRUE;
                                                    //config for bootstrap pagination class integration
                                                    $config['full_tag_open'] = '<ul class="pagination">';
                                                    $config['full_tag_close'] = '</ul>';
                                                    $config['first_link'] = "&laquo First";
                                                    $config['last_link'] = "Last &raquo";
                                                    $config['first_tag_open'] = '<li  class="page-item ">';
                                                    $config['first_tag_close'] = '</li>';
                                                    $config['prev_link'] = 'Prev';
                                                    $config['prev_tag_open'] = '<li class="page-item">';
                                                    $config['prev_tag_close'] = '</li>';
                                                    $config['next_link'] = 'Next';
                                                    $config['next_tag_open'] = '<li  class="page-item">';
                                                    $config['next_tag_close'] = '</li>';
                                                    $config['last_tag_open'] = '<li  class="page-item">';
                                                    $config['last_tag_close'] = '</li>';
                                                    $config['cur_tag_open'] = '<li class="page-item active"><a href="#">';
                                                    $config['cur_tag_close'] = '</a></li>';
                                                    $config['num_tag_open'] = '<li  class="page-item">';
                                                    $config['num_tag_close'] = '</li>';
                                                    $this->pagination->initialize($config);

                                                    $page = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
                                                    $per_page = $config["per_page"];
                                                    $startm = $page;
                                                    if($page>1)
                                                    $startm = $page-1;
                                                    $startfrom = $per_page*$startm;
                                                    $data['startfrom'] = $startfrom;


                                                    $data['pagination'] = $this->pagination->create_links();

                                                    $user_q_rec = $this->Conference_model->get_records("*","tbl_posts","user_id='$userid'","post_id ASC","$per_page","$startfrom");

                                                    //$user_q_rec = $this->Conference_model->get_records("*","tbl_posts","user_id='$userid'","post_id DESC","4","");
                                                    if(!empty($user_q_rec)){
                                                       foreach ($user_q_rec as $ket) {
                                                           $uspost_title = $ket['post_title'];
                                                           $uspost_id = $ket['post_id'];
                                                           $usf_poid = base64_encode($uspost_id);
                                                           $usposted_date = $ket['posted_date'];
                                                           $usf_date =  date('d.m.Y' , strtotime($usposted_date));
                                                           $usques_status = $ket['status'];
                                                           $usnoof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","post_id='$uspost_id' and status='1'");
                                                           $usdeliuid = $this->Conference_model->showname_fromid("user_id","tbl_posts","post_id='$uspost_id'");  
                                                 
                                                    ?>
                                                    <!--- DETAILS POSTS START --->

                                                      <div class="add-txt-sec">

                                        <h4> <a href="javascript:void(0);" style="font-size: 15px !important;">
                                   <?php if($uspost_title==''){ }else{echo $uspost_title;}?> </a></h4>
                                   
                                        <div class="add-list">
                                            <!--- VOTING START --->
                                            <?php 
                                                $dynlkdislksave = $this->Conference_model->showname_fromid("voting","tbl_post_voting","vpost_id='$uspost_id' and vuserid='$userid' and voting in(1,2)");
                                                    $likestyle=''; $dislikestyle=''; 
                                                    if($dynlkdislksave==1) {
                                                        $likestyle = "style='color:green;'";
                                                    } else if($dynlkdislksave==2) {
                                                        $dislikestyle = "style='color:red;'";
                                                    }
                                             $noof_vots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$uspost_id' and voting='1'");  

                                    $noof_unvots = $this->Conference_model->noof_records("voting","tbl_post_voting","vpost_id='$uspost_id' and voting='2'");      
                                                    
                                            ?>
                                            <!-- VOTING END --->

                
                                            <ul>
                                                <li>  <a href="javascript:void(0);"> <i class="fa fa-calendar-alt"></i> <?php echo $usf_date;?> </a></li>
                                                <li>  <a href="javascript:void(0);"> <i class="fas fa-eye"></i> <?php echo ($ket['noof_views'] > 0) ? $ket['noof_views'] : '0' ;?>  views </a></li>
                                               <!-- <li><a href="javascript:void(0);"><i class="fas fa-thumbs-up"></i> 03 Vote </a></li>--->
                                               <li><a href="javascript:void(0)"><i class="fas fa-thumbs-up"></i> <?php echo $noof_vots.' Votes ';?> </a></li>
                                                <!--<li><a href="javascript:void(0);"><i class="fas fa-thumbs-down"></i> 01 Vote </a></li>--->
                                             <li> <a href="javascript:void(0)"><i class="fas fa-thumbs-down"></i> <?php echo $noof_unvots.' Downvotes ';?> </a></li>
                                             
                                            


                                                <li> <a href="javascript:void(0);"><i class="fas fa-reply"></i> <?php echo  $noof_rec.' Answer' ?></a></li>
                                                <?php if($usques_status==1){ ?>
                                                <li><a href="javascript:void(0);"><i class="fas fa-trophy"></i> Active </a></li>
                                                <?php }else{ ?>
                                                <li><a href="javascript:void(0);"><i class="fas fa-trophy"></i> Inactive </a></li>
                                                <?php } ?>


                                            </ul>
                                            
                                        </div>
                                    </div>
                                    <?php } ?>
                                <?php } ?>

                                        <div class="user-pagination" style="float: right;">                                        
                                             <?php print_r($data['pagination']); ?>  
                                  </div>
                                                    <!---- DETAILS POSTS END --->
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                   

                                      <div class="clearfix"></div>

                                     <div class="col-xl-12 col-lg-12"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-12 col-lg-2">
                                                    <div class="name-newtxt">User Answers :</div>
                                                </div>
                                                <div class="col-xl-12 col-lg-10">
                                                   
                           
                                                     <!--- ANSWER BLOG START --->
                                                                                             <div class="activity-question-answer-list ">
                        <?php
                          $noof_r = $this->Conference_model->noof_records("cmt_id","tbl_comments","user_id='$userid'");
                        ?>
                        <!---<div class="activity-title" style="font-size: 14px;">Answer (<?php //echo $noof_r; ?>)</div>-->
                                        <ul>
                                          <!--- ALL QUESTION AND ANSWER SECTION DETAILS START -->   
                            <?php
                            $rec_dcmt = $this->db->query("SELECT DISTINCT `post_id` FROM `tbl_comments` WHERE `user_id`='".$userid."' ORDER BY `post_id` DESC LIMIT 2");
                            $rec_exicute = $rec_dcmt->result();
                            if(!empty($rec_exicute)){
                            foreach ($rec_exicute as $podeta) {
                                $post_id = $podeta->post_id;
                              $fff_poid = base64_encode($post_id);
                                
                                $rec_ques = $this->Conference_model->get_records("*","tbl_posts","post_id='$post_id'");
                                if(!empty($rec_ques)){
                                   foreach ($rec_ques as $postdetails) {
                                    $post_titles = $postdetails['post_title'];
                                    $posted_dates = $postdetails['posted_date'];
                                    $final_posteddate = date('d.m.Y' , strtotime($posted_dates));

                            $rec_commde = $this->Conference_model->get_records("*","tbl_comments","user_id='$userid' and post_id='$post_id'","cmt_id DESC");    
        
                          ?>
                                            <li>
                                              
                                                <a href="javascript:void(0);"><?php echo $post_titles;?> </a>
                                            
                                            <div class="activity-date"> <i class="fa fa-calendar-alt"></i> <?php echo $final_posteddate;?></div>
                                            <?php
                                            if(!empty($rec_commde)){
                                            foreach ($rec_commde as $commentdetails) {
                                                    $cmt_user = $commentdetails['user_cmt'];
                                                    $cmt_date = $commentdetails['commented_date'];
                                                    $final_commenteddate = date('d.m.Y' , strtotime($cmt_date));
                                                    

                                            ?>




                                                <div class="activity-question-answer"> 
                                                   <?php echo $cmt_user; ?>
                                                    <div class="activity-date mtp10"> <i class="fa fa-calendar-alt"></i>  <?php echo $final_commenteddate;?></div>
                                                </div>
                                             <?php
                                               }
                                              }
                                             ?>

                                            </li>
                                            <?php
         
                                             }

                                            }
                                           }
                                          } 

                                           ?>
                                             <!--- ALL QUESTION AND ANSWER SECTION DETAILS END -->

                                        </ul>

                                   

                                    </div>
                                        
                                        <?php if($noof_r>0){ ?>
                                        <div class="user-pagination" style="float: right;">                                        
                                                <h4> <a href="<?php echo base_url() . 'admin/website-user/comment-details/'.$userid; ?>" class="des-sec-an" title="view more to see all Answers">
                                  View All </a></h4>
                                  </div>
                              <?php }else{ ?>

                              <?php } ?>  

                                                     <!--- ANSWER BLOG END --->
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    



                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>

    </body>
</html>
