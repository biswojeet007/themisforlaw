<footer>


            <div class="copyright">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-9 col-lg-9">
                            <p>© Copyright <?php echo date("Y"); ?> PMSLTECH Knowledge Base all rights reserved. <a href="https://pmsltech.com/" target="_blank">Developed by Pmsltech.com</a></p>
                        </div>
                        <div class="col-xl-3 col-lg-3"> 
                            <div class="social-list">

                                <ul>
                                    <li><a href="https://www.facebook.com/Pmsltech" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                    <li> <a href="https://plus.google.com/+Pmsltech" target="_blank"><i class="fab fa-google-plus-g"></i></a></li>
                                    <li> <a href="https://twitter.com/pmsltech" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                    <li> <a href="https://www.linkedin.com/company/pmsltech/" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </footer>

        <script src="<?php echo base_url(); ?>assets/admin/js/jquery-3.2.1.slim.min.js"  type="text/javascript" ></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/popper.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <!-- MY CUSTOM JS CDN FOR AUTOCOM SEARCH START  --->
        <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap-select.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/waypoints.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/jquery.counterup.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/wow.js"></script>
        <!---- MY CUSTOM JS CDN FOR AUTOCOM SEARCH END --->
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/js_validation/jquery.validate.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js_validation/additional-methods.min.js"></script>
       <script src="<?php echo base_url(); ?>assets/admin/js_validation/validation.js"></script>

   
<!--         

        <script>
                                            $(function () {
                                                $('.datepicker').datepicker({
                                                    format: 'mm/dd/yyyy',
                                                    todayHighlight: true,
                                                    autoclose: true,

                                                });
                                            });
                                            
        </script> -->
