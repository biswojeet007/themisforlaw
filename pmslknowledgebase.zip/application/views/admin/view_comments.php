<?php
foreach ($row as $rows)
{
    
    $user_id = $rows['user_id'];
    $post_id = $rows['post_id'];
    $cmtt_id = $rows['cmt_id']; 
    $user_comment = $rows['user_cmt'];
    $cmtt_date = $rows['commented_date'];
                                
    
}
?>


<!DOCTYPE html>

<html>
    <head>
       <?php include("head.php"); ?>
    </head>
    <body class="body-img inr-body-img">

       <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-comment"></i>
                            <h1>User Posts</h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/comments" class="adduser"> Manage Comments</a>
                                <div class="add-line"></div>
                                <div class="row">

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> Title : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">
                                                    <?php 
                                                    $rect_user = $this->Conference_model->showname_fromid("post_title","tbl_posts","post_id='$post_id'");
                                                    echo $rect_user;
                                                    
                                                    ?>
                                                        
                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									
                                    <div class="clearfix"></div>

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> User Name : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">
                                                        <?php
                                                        $rec_user = $this->Conference_model->showname_fromid("username","tbl_user","user_id='$user_id'");
                                                        echo $rec_user;
                                                        ?>
                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                             
                                    <div class="clearfix"></div>

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> Date : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1"><?php echo date(' dS  F  Y ' , strtotime($cmtt_date)); ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> Status : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">
                                                        <?php
                                                        $rec_status = $this->Conference_model->showname_fromid("status","tbl_comments","cmt_id=$cmtt_id");
                                                        if($rec_status==1){
                                                          echo 'Active';
                                                        }else{
                                                          echo 'Inactive';
                                                        }
                                                        ?>
                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                 <div class="clearfix"></div>
                                    
                                 <div class="col-xl-12 col-lg-12"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-2 col-lg-2">
                                                    <div class="name-txt"> Comments:</div>
                                                </div>
                                                <div class="col-xl-10 col-lg-10">
                                                    <div class="name-txt2">  <?php echo $user_comment; ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>

    </body>
</html>
