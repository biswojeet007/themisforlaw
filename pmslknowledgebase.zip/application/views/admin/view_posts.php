<?php
foreach ($row as $rows)
{
    
    $user_id = $rows['user_id'];
    $post_id = $rows['post_id']; 
    $post_title = $rows['post_title'];
	$post_desc = $rows['post_desc'];
    $posted_date = $rows['posted_date'];
                                
    
}
?>


<!DOCTYPE html>

<html>
    <head>
       <?php include("head.php"); ?>
    </head>
    <body class="body-img inr-body-img">

       <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-sticky-note"></i>
                            <h1>User Posts</h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/posts" class="adduser"> Manage Posts</a>
                                <div class="add-line"></div>
                                <div class="row">

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> Title : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1"><?php echo $post_title; ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> Tags:</div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1"> 
                                <?php 
                                    $usermodules = $this->Common_model->get_records("c.*, b.tag_name", "tbl_post_tags c, tbl_tags b", "c.tag_id=b.tag_id and c.post_id='$post_id'", "tag_id ASC");
                                   
                                    
                                   $module = array();
                                   
                                    if(!empty($usermodules)){
                                    foreach ($usermodules as $modules) {
                                        $module[] = $modules['tag_name'];
                                    }

                                   echo $var = implode(", ", $module);

                                 }else{

                                 }
                     
                                ?>



                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                  
									
									
                                    <div class="clearfix"></div>

                                     


                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> User Name : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">
                                                        <?php
                                                        $rect_user = $this->Common_model->showname_fromid("username","tbl_user","user_id='$user_id'");
                                                        echo $rect_user;
                                                        ?>
                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> User Email : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">
                                                        <?php
                                                        $rec_user = $this->Common_model->showname_fromid("user_email","tbl_user","user_id='$user_id'");
                                                        echo $rec_user;
                                                        ?>
                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="clearfix"></div>

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> Date : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1"><?php echo date(' dS  F  Y ' , strtotime($posted_date)); ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> Status : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">
                                                        <?php
                                                        $rec_status = $this->Common_model->showname_fromid("status","tbl_posts","post_id=$post_id");
                                                        if($rec_status==1){
                                                          echo 'Active';
                                                        }else{
                                                          echo 'Inactive';
                                                        }
                                                        ?>
                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="clearfix"></div>

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> Views: </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1"><?php echo ($rows['noof_views'] > 0) ? $rows['noof_views'] : '0' ;?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-xl-6 col-lg-6"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-4 col-lg-4">
                                                    <div class="name-txt"> Votes : </div>
                                                </div>
                                                <div class="col-xl-8 col-lg-8">
                                                    <div class="name-txt1">
                                                      <!--- VOTING START --->
                                          <?php 
                                                $sess_userid = $this->session->userdata('adminid');
                                                $dynlkdislksave = $this->Common_model->showname_fromid("voting","tbl_post_voting","vpost_id='$post_id' and vuserid='$sess_userid' and voting in(1,2)");
                                                $likestyle=''; $dislikestyle=''; 
                                                if($dynlkdislksave==1) {
                                                  $likestyle = "style='color:green;'";
                                                } else if($dynlkdislksave==2) {
                                                  $dislikestyle = "style='color:red;'";
                                                }
                                             $noof_vots = $this->Common_model->noof_records("voting","tbl_post_voting","vpost_id='$post_id' and voting='1'");  

                                                          $noof_unvots = $this->Common_model->noof_records("voting","tbl_post_voting","vpost_id='$post_id' and voting='2'"); 

                                                $totalvotes = $noof_vots -  $noof_unvots;    

                                                echo $totalvotes;    
                          
                                          ?>
                                          <!-- VOTING END --->
                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                 <div class="clearfix"></div>
                                    
                                 <div class="col-xl-12 col-lg-12"> 
                                        <div class="form-group">
                                            <div class="row">

                                                <div class="col-xl-2 col-lg-2">
                                                    <div class="name-txt"> Description:</div>
                                                </div>
                                                <div class="col-xl-10 col-lg-10">
                                                    <div class="name-txt2">  <?php echo $post_desc; ?></div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>

    </body>
</html>
