<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Pmslknowledgebase</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

	 <link href="<?php echo base_url(); ?>assets/admin/css/bootstrap.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo base_url(); ?>assets/admin/fonts/fontawesome/css/fontawesome-all.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo base_url(); ?>assets/admin/style.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url(); ?>assets/admin/css/scssstyle.css?v=1.1" rel="stylesheet" type="text/css"/>
	<style>
		.loginform {padding: 33px 25px 0px;}
		.loginform .form-control{
			border-radius: 0px;
			box-shadow:none;
			border:#ddd 1px solid;
			}
		.loginform .control-label {
			padding-top: 7px;
			margin-bottom: 0;
			text-align: right;
			text-transform: uppercase;
			font-size: 12px;
		}
		.loginform-content .panel-heading{
			padding:15px 0;
			}
		.loginform-content .panel-footer {
			background:#676565;
			color: #fff;
			font-size:13px;
			letter-spacing:0.5px;
			padding: 12px 15px;
			border-radius:0;
		}
		.loginform-content .panel-footer a{ color:#fff}
		.loginform-content .panel{ 
			border:none;
			border-radius:0;
			background: rgba(255, 255, 255, 0.78);
			padding: 20px;
			}
		.loginform-content .checkbox {
			min-height: 27px;
			margin-top: -10px;
		}
		.loginform a{ color:#000}
		.redbtn {
			background-color: rgb(228, 82, 38);
			color: rgb(255, 255, 255);
			display: inline-block;
			text-transform: uppercase;
			font-size: 14px;
			font-family: "Open Sans";
			font-weight: 600;
			margin-right:5px;
			border-width: 2px;
			border-style: solid;
			border-color: rgb(228, 82, 38);
			border-image: initial;
			padding: 6px 16px;
			transition: all 0.5s linear;
		}
		.blackbtn {
			background-color: #333;
			border: #333 2px solid;
			color: #fff;
			padding: 6px 16px;
			display: inline-block;
			text-transform: uppercase;
			transition: all linear 0.5s;
			font-size: 14px;
			font-family: 'Open Sans';
			font-weight: 600;
		}
		.redbtn:hover, .blackbtn:hover{ color:#EAEAEA} 
		.control-label {
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 0.5px;
    padding: 5px 23px;
}
.form-group.last {
    margin-bottom: 0;
}
	</style>
</head>


<body style="background:url(<?php echo base_url(); ?>assets/admin/images/body-bg.jpg) no-repeat; background-size:cover">

<div class="container">
<div class="row">
<div class="col-md-6 col-md-offset-3 loginform-content">
<div style="margin-top:150px;box-shadow:0px 0px 34px #d5d3d1;">
<div class="panel panel-default">
                <div class="panel-heading"> <h3 class="text-center">Create New Password</h3> </div>
                <div class="panel-body">
				
				<?php echo $message; ?>
				<div class="panel-body">
					<form class="form-horizontal mt10" name="change_password" id="change_password" method="post">
						<?php
							if($validmsg!='')
							{
						?>
							<div class="form-group">
								<div class="col-xl-12 col-lg-12">
									<span style="color:#990000;padding:50px 30px 50px 30px;"><b> <?php echo $validmsg; ?> </b></span>
								</div>
							</div>
						<?php
							}
							else if(($diffrnc>=0) && ($numuserforgot>0))
							{
						?>
							<div class="form-group">
							<div class="row">
								<label for="new_pwd" class="col-xl-5 col-lg-5 control-label">New Password</label>
								<div class="col-xl-7 col-lg-7 ">
									<input type="password" class="form-control" placeholder="Enter new password" id="new_pwd" name="new_pwd" maxlength="20">
								</div>
								</div>
							</div>
						
							<div class="form-group">
							<div class="row">
								<label for="cnf_pwd" class="col-xl-5 col-lg-5 control-label">Confirm Password</label>
								<div class="col-xl-7 col-lg-7">
									<input type="password" class="form-control" placeholder="Enter confirm password" id="cnf_pwd" name="cnf_pwd" maxlength="20">
								</div>
								</div>
							</div>

							 <div class="form-group last">
							 <div class="row">
							 <div class="col-xl-5 col-lg-5"></div>
								<div class="col-xl-7 col-lg-7">
									<button type="submit" class="admin-submit " id="btnSubmit" name="btnSubmit">Submit</button>	
									<button type="reset" class="admin-reset ">Reset</button>
								</div>
								</div>
							</div>
						
						<?php
							}
							else
							{
						?>
							<div class="form-group">
								<div class="col-xs-12">
									<span style="padding:50px 30px 50px 30px;">
										<b>Please <a href="<?php echo base_url(); ?>admin">Log-in</a> to your account with the new password.</b> 		
									</span>
								</div>
							</div>
						<?php
							}
						?>
						<input type="hidden" name="hiduserid" id="hiduserid" value="<?php echo $getuserid; ?>"/>
					</form>
				</div>
		
                </div>
        </div>
</div>
</div>
</div>
</div>
</body>
	
<script src="<?php echo base_url(); ?>assets/admin/js/jquery-3.2.1.slim.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js_validation/jquery.validate.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js_validation/validation.js"></script>
</html>