<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>



                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-users"></i>
                            <h1>Add User</h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <?php echo $message; ?>
                                <form class="add-user" name="userform" id="userform" method="post">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 "> 
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control fld" placeholder="Enter name" name="uname" id="uname" value="<?php echo set_value('uname'); ?>" >
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6 "> 
                                            <div class="form-group">
                                                <label>User Type</label>
                                                <div class="row">
                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="custom-control custom-radio">
                                                            <input type="radio" class="custom-control-input" name="utype" id="utype1" value="2" <?php echo set_radio('utype', 2); ?>>
                                                            <label class="custom-control-label" for="utype1">Admin</label>
                                                        </div>  
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6">
                                                        <div class="custom-control custom-radio">
                                                            <input type="radio" class="custom-control-input" name="utype" id="utype2" value="3" <?php echo set_radio('utype', 3); ?>>
                                                            <label class="custom-control-label" for="utype2">User</label>
                                                        </div>  
                                                    </div>
                                                    <div style="margin-left: 15px;" id="utype_errorloc"></div>
                                                </div>

                                            </div>
                                        </div>


                                        <div class="clearfix"></div>  

                                        <div class="col-xl-6 col-lg-6 "> 
                                            <div class="form-group">
                                                <label>Email Id</label>
                                                <input type="text" class="form-control fld" placeholder="Enter Emai Id" name="email" id="email" value="<?php echo set_value('email'); ?>">
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6 "> 
                                            <div class="form-group">
                                                <label>Contact No.</label>
                                                <input type="text" class="form-control fld" placeholder="Enter Contact no" name="contact" id="contact" value="<?php echo set_value('contact'); ?>">
                                            </div>
                                        </div>

                                        <div class="clearfix"></div>  

                                        <div class="col-xl-6 col-lg-6 "> 
                                            <div class="form-group">
                                                <label>Password</label>
                                                <input type="password" class="form-control fld" placeholder="Enter Password" name="password" id="password" value="<?php echo set_value('password'); ?>">
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6 "> 
                                            <div class="form-group">
                                                <label>Confirm Password</label>
                                                <input type="password" class="form-control fld" placeholder="Enter Confirm Password" name="cpassword" id="cpassword" value="<?php echo set_value('cpassword'); ?>">
                                            </div>
                                        </div>


                                        <div class="clearfix"></div>  

                                        <div class="col-xl-6 col-lg-6 "> 
                                            <div class="form-group">
                                                <label>Modules</label>
                                                <div class="row">
                                                    <?php
                                                    $cnt = 0;
                                                    foreach ($row as $rows) {
                                                        $cnt++;
                                                        $moduleid = $rows['moduleid'];
                                                        $module = $rows['module'];
                                                        $checked = '';
                                                        $disabled = '';
                                                        if (set_radio('utype', 2) == true) {
                                                            $checked = 'checked="checked"';
                                                            $disabled = 'disabled="disabled"';
                                                        }
                                                        ?>
                                                        <div class="col-xl-6 col-lg-6">
                                                            <div class="custom-control custom-checkbox mbt10">
                                                                <input type="checkbox" class="custom-control-input" name="modules[]" id="modules_<?php echo $cnt; ?>" value="<?php echo $moduleid; ?>"  <?php echo set_checkbox('modules[]', $moduleid); ?> <?php echo $checked . ' ' . $disabled; ?>>

                                                                <label class="custom-control-label" for="modules_<?php echo $cnt; ?>"><?php echo $module; ?></label>
                                                            </div>
                                                        </div>
                                                        <?php
                                                        if ($cnt % 2 == '0') {
                                                            echo '<div class="clearfix"></div>';
                                                        }
                                                    }
                                                    ?>
                                                    <div style="margin-left: 15px;" id="modules_errorloc"></div>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="clearfix"></div>  
                                        <div class="col-xl-12 col-lg-12">
                                            <div class="reset-button"> 
                                                <button type="submit" class="redbtn" name="btnSubmit" id="btnSubmit">Save</button>
                                                <button type="reset" class="blackbtn">Reset</button>  
                                            </div>
                                        </div>
                                    </div>
                                </form>


                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
<?php include("footer.php"); ?>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/js_validation/jquery.validate.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js_validation/validation.js"></script>

    </body>
</html>
