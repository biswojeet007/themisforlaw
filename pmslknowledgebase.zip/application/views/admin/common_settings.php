<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
        <link href="<?php echo base_url(); ?>assets/admin/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>



                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fas fa-cog"></i>
                            <h1>Common Settings </h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">

                                <div class="row">
                                    <?php echo $message; ?>
                                    <div class="col-xl-12 col-lg-12"> 
                                        <div class="table-responsive">
                                            <table id="example" class="table table-bordered table-striped table-hover mng-tbl-txt">
                                                <thead>
                                                    <tr class="info">
                                                        <th>Sl#</th>
                                                        <th>Parameter</th>
                                                        <th width="60%">Parameter Value</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php
                                                    $cnt = 0;
                                                    if (!empty($row)) {
                                                        foreach ($row as $rows) {
                                                            $cnt++;
                                                            $parid = $rows['parid'];
                                                            $parameter = $rows['parameter'];
                                                            $par_value = $rows['par_value'];
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $cnt; ?></td>
                                                                <td><?php echo $parameter; ?></td>
                                                                <td><?php if ($par_value != '') echo $par_value;
                                                    else echo "<span class='error'>-NA-</span>"; ?></td>

                                                                <td>

                                                                    <a href="<?php echo base_url() . 'admin/common_settings/edit/' . $parid; ?>" class="btn btn-success btn-sm view tbl-icon-btm" title="View"> <i class="far fa-edit"></i></a>


                                                                </td>
                                                            </tr>
        <?php
    }
}
else {
    ?>
                                                        <tr>
                                                            <td class="text-center" colspan="3"> No data available in table </td>
                                                        </tr>
                                                        <?php
                                                    }
                                                    ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>





                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
<?php include("footer.php"); ?>
        <script src="<?php echo base_url(); ?>assets/admin/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/dataTables.bootstrap4.min.js" type="text/javascript"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('#example').DataTable();
            });

        </script>




    </body>
</html>
