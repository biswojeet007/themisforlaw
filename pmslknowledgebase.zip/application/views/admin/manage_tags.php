<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
        <link href="<?php echo base_url(); ?>assets/admin/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>



                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-tag"></i>
                            <h1>Manage Tags </h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/tags/add" class="adduser"> Add Tags</a>
                                <div class="add-line"></div>
                                <div class="row">
                                   <?php echo $message; ?>
                                    <div class="col-xl-12 col-lg-12"> 
                                        <div class="table-responsive">
                                            <table id="example" class="table table-bordered table-striped table-hover mng-tbl-txt">
                                                <thead>
                                                    <tr class="info">
                                                        <th width="8%">Sl #</th>
                                                        <th width="10%">Tags</th>
                                                         <th width="10%">Questions</th>
														<th width="10%">Date</th>
                                                        <th width="10%">Status</th>
                                                        <th width="11%">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php
                                    $cnt = isset($startfrom) ? $startfrom : 0;
                                    if( !empty($row) )
                                    {
                                        foreach ($row as $rows)
                                        {
                                            $cnt++;
                                            $tag_id = $rows['tag_id'];
                                            $tag_name = $rows['tag_name'];
											$date = $rows['tag_date'];
                                            $status = $rows['status'];

                                            $rec_ques = $this->Common_model->noof_records("post_id","tbl_post_tags","tag_id='$tag_id'");
                                    ?>
                                                    <tr>
                                                        <td><?php echo $cnt; ?></td>
                                                    
                                                        <td><?php echo $tag_name; ?></td>
                                                        <td><?php echo $rec_ques;?></td>
														<td><?php echo date(' dS  F  Y ' , strtotime($date)); ?></td>
                                                        

                                                        <td>
                                        
                                            <?php if($status==1) { ?>
                                                <span class="status" data-id="<?php echo "status-".$tag_id; ?>"><a href="javascript:void(0)" title="Status is active. Click here to make it inactive."><span class="label-custom label label-success">Active</span></a></span>
                                           <?php } else { ?>
                                            <span class="status" data-id="<?php echo "status-".$tag_id; ?>"><a href="javascript:void(0)" title="Status is inactive. Click here to make it active."><span class="label-custom label label-danger">Inactive</span></a></span>
                                             <?php } ?>
                                        </td>

                                                        <td>

                                                            <a href="<?php echo base_url().'admin/tags/edit/'.$tag_id; ?>" class="btn btn-success btn-sm view tbl-icon-btm" title="View"> <i class="far fa-edit"></i></a>

                                                            
                                                            <a onClick="return confirm('Are you sure to delete this  Tags?')" href="<?php echo base_url().'admin/tags/delete/'.$tag_id; ?>" class="btn btn-danger btn-sm tbl-icon-btm" title=""><i class="far fa-trash-alt"></i> </a>

                                                        </td>
                                                    </tr>
                                                     <?php
                                        }
                                    }
                                    else
                                    {
                                    ?>
                                    <tr>
                                        <td class="text-center" colspan="5"> No data available in table </td>
                                    </tr>
                                    <?php
                                    }
                                    ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>





                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
       <?php include("footer.php"); ?>
       <script src="<?php echo base_url(); ?>assets/admin/js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/dataTables.bootstrap4.min.js" type="text/javascript"></script>

    <script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
    });

    </script>

    <script type="text/javascript">

$(document).on('click', '.status', function(){
    if(confirm('Are you sure to change the status?'))
    {
        var val = $(this).data("id");
        var valsplit = val.split("-");
        var id = valsplit[1];
        jQuery('[data-id='+val+']').after('<div class="spinner" style="text-align:center;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-1x"></i></div>');
        $.ajax({
            url: "<?php echo base_url(); ?>admin/tags/changestatus/"+id,
            type: 'post',
            cache: false,
            processData: false,
            success: function (data) {
                jQuery('.spinner').remove();
                if(data == 1) //Inactive
                {
                    jQuery('[data-id='+val+']').html('<a href="javascript:void(0)" title="Status is inactive. Click here to make it active."><span class="label-custom label label-danger">Inactive</span></a>');
                }
                else if(data == 0) //Active
                {
                    jQuery('[data-id='+val+']').html('<a href="javascript:void(0)" title="Status is active. Click here to make it inactive."><span class="label-custom label label-success">Active</span></a>');
                }
                else
                {
                    alert("Sorry! Unable to change status.");
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
            }
        });
    }
});
</script>


    </body>
</html>
