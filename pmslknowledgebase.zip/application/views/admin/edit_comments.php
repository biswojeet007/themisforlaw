<?php
foreach ($comm as $rows)
{

    $comments = $rows['user_cmt'];  
}

?>

<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
         <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/jquery-ui.css">
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-comment"></i>
                            <h1>Edit Comments </h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/comments" class="adduser"> Manage Comments</a>
                                <div class="add-line"></div>
                                <div class="row">
                                    <?php echo $message;  ?>
                                    <div id="existagmsg"></div>
                                    <div class="col-xl-12 col-lg-12"> 
                                        <form class="add-user" name="edited_comment" id="edited_comment"  method="post">
                                            <div class="row">

                                                 <div class="col-xl-12 col-lg-12 "> 

                                            <div class="col-xl-12 col-lg-12">
                                            <div class="b-edit-comment">
                                               <div class="row">
                                               	<div class="col-md-2">
                                               		 <label> Description</label>
                                               	</div>
                                               		<div class="col-md-5">
                                               		<textarea class="form-control fld text-area-height exp valid" style="margin-bottom: 12px;" name="edit_c" id="edit_c" ><?php echo set_value('edit_c',$comments);?></textarea>
                                                <span id="msg_ck"></span>
                                               	</div>
                                               	<div class="clearfix"></div>
                                               </div>

                                               
                                                

                                            </div>
                                        </div>

                                                </div>

                                            
                                                <div class="clearfix"></div>   


                                                <div class="col-xl-12 col-lg-12">
                                                    <div class="reset-button"> 
                                        <button type="submit" class="redbtn" name="btnSubmit" id="btnSubmit">Update</button>
                                        <button type="button" class="blackbtn" onClick="window.location='<?php echo base_url(); ?>admin/comments'">Back</button> 
                                                    </div>
                                                </div>

                                            </div>
                                          </form>
                                    </div>

                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>

            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>
        <script type="text/javascript">
      jQuery("#edited_comment").validate({
        rules: {            
                  
            edit_c: {
                required: true
                
            }
        },
        messages:{
            
            edit_c: {
                required: "Enter Comment."
        }
      },
    errorPlacement:function(error,element){
      if(element.attr("name") === "edit_c")
        error.appendTo("#msg_ck");
      //else if(element.attr("name") === "post_desc")
         // error.appendTo("#msg_ck");
      else
        error.insertAfter(element);
    } 

  });     
 </script>
    </body>
</html>

 