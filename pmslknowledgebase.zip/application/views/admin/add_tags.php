<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-tag"></i>
                            <h1>Tags</h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/tags" class="adduser"> Manage Tags</a>
                                <div class="add-line"></div>
                                <div class="row">
                                    <?php echo $message;  ?>
                                    <div class="col-xl-12 col-lg-12"> 
                                        <form class="add-user" name="form_tag" id="form_tag"  method="post">
                                            <div class="row">
                                                <div class="col-xl-6 col-lg-6 "> 
                                                    <div class="form-group">
                                                        <label>Tags</label>

                                                <input type="text" class="form-control fld" placeholder="Enter Tags" name="tag_name" id="tag_name" value="<?php echo set_value('tag_name'); ?>">

                                                       
                                                    </div>
                                                    <div id="addition_tag"></div>
                                                </div>
                                                 

                                                <div class="clearfix"></div>   


                                                <div class="col-xl-12 col-lg-12">
                                                    <div class="reset-button"> 
                                        <button type="submit" class="redbtn" name="btnSubmit" id="btnSubmit">Save</button>
                                        <button type="reset" class="blackbtn">Reset</button> 
                                                    </div>
                                                </div>

                                            </div></form>
                                    </div>

                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>

        <script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/js_validation/jquery.validate.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js_validation/validation.js"></script>
    <script type="text/javascript">
     jQuery("#form_tag").validate({
        rules: {
            tag_name: {
                required: true
               
            }
        },
        messages: {
            tag_name: {
                required: "Enter New Tag"
               
            }
        },
    errorPlacement: function (error, element)
    {
      if (element.attr("name") === "tag_name" )
        error.appendTo("#addition_tag");
      //else if (element.attr("name") === "password" )
        //error.appendTo("#password_error");
      else
        error.insertAfter(element);
    }

   }); 
    </script>


    </body>
</html>
