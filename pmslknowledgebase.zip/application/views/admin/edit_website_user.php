<?php
foreach ($orgnmm as $rows)
{
    $user_id = $rows['user_id']; 
    $username = $rows['username'];
	$usertitle = $rows['user_title'];
    $useremail = $rows['user_email'];
	$userpic = $rows['user_pic'];
	$userdesc = $rows['user_desc'];
    
    
}
?>


<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec">
                                      <div class="text-center">
                                        </div>
                                        <div class="titile-main-hding"><i class="fa fa-user-tie"></i><h1> Edit Website Users</h1></div>
						
						
					
<?php echo $message ?>
                                       <form class="add-user" method="post" name="form_editprofile" id="form_editprofile" enctype="multipart/form-data">
                                       
                                            <div class="row">
                                                <div class="col-xl-6 col-lg-6 "> 
                                                    <div class="form-group">
                                                        <label>Website User Name</label>
                                                        <input type="text" class="form-control fld" placeholder="eConference" name="username" id="username"  value="<?php echo set_value('user_name', $username); ?>">
                                                    </div>
                                                </div>
												
												<div class="col-xl-6 col-lg-6">
                                            <div class="form-group">
                                                <label> Title</label>
                                                <input type="text" class="form-control fld" name="user_title" value="<?php echo set_value('user_title',$usertitle);?>" placeholder="">
                                            </div>
                                        </div>

                                                <div class="col-xl-6 col-lg-6 "> 
                                                    <div class="form-group">
                                                        <label>Email Address</label>
                                                        <input type="text" class="form-control fld" placeholder="Email Id"  name="user_email" id="user_email" value="<?php echo set_value('user_email', $useremail); ?>" readonly>
                                                    </div>
                                                </div>
												
												 <div class="col-xl-6 col-lg-6">
                                            <div class="form-group">
                                                <label> Image Upload</label>
                                                <div class="setting-fld">
                                                    <input type="file" name="user_pic"  class="flie-upload">
													<?php if (file_exists("./assets/images/" . $userpic) && ($userpic != '')) { ?>
													<img class="img-fluid file-img-upload" alt="photo" src="<?php echo base_url().'assets/images/'.$userpic; ?>" />
													<?php } ?>	   
                                                </div>

                                            </div>
                                            <div id="error_user_pic"></div>
                                        </div>
												
												<div class="col-xl-6 col-lg-6">
                                            <div class="form-group">
                                                <label> Short Description</label>
                                                <textarea class="form-control fld text-area-height exp"  name="user_desc" placeholder=""><?php echo set_value('user_desc',$userdesc);?></textarea>
                                            </div>
                                        </div>


                                                <div class="clearfix"></div>  
                                                <div class="col-xl-12 col-lg-12">
                                                    <div class="reset-button"> 
                                                        <button type="submit" class="log-in-btm redbtn" name="btnEditProfile" id="btnEditProfile">Update</button>

                                                        <button type="button" class="blackbtn" onClick="window.location='<?php echo base_url(); ?>admin/website_user'">Back</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>





                                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>

        <script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        
        <script src="<?php echo base_url(); ?>assets/admin/js_validation/jquery.validate.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js_validation/additional-methods.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js_validation/validation.js"></script>
        <script>var base_url = "<?php echo base_url(); ?>"; </script>

       
         


    </body>
</html>
