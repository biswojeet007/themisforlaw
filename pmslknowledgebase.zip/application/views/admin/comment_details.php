<?php
if(!empty($rowssd)){
  
}


?>
<!DOCTYPE html>
<html>
    <head>
       <?php include("head.php"); ?>
       <link href="<?php echo base_url();?>assets/admin/qacss.css?v=1.1" rel="stylesheet" type="text/css"/>
    </head>
    <body class="body-img inr-body-img">

       <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-user-tie"></i>
                            <h1>Website Users </h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/website_user" class="adduser"> Manage Website Users</a>
                                <div class="add-line"></div>
                                <div class="row">

                                      <div class="clearfix"></div>

                                     <div class="col-xl-12 col-lg-12"> 
                                        <div class="form-group">
                                            <div class="row">

                                               
                                                <div class="col-xl-10 col-lg-10">
                                                   
                                                         <div>
                                                    <div class="name-newtxt"> All Answers :</div>
                                                </div>
                                                     <!--- ANSWER BLOG START --->
                                                              <div class="activity-question-answer-list ">
                        <?php
                         $userid = $rowssd;
                          $noof_r = $this->Conference_model->noof_records("cmt_id","tbl_comments","user_id='$userid'");
                          $usern = $this->Conference_model->showname_fromid("username","tbl_user","user_id='$userid'");

                        ?>
                        <div class="activity-title">Answered <?php //(echo $noof_r;) ?> by <i class="fas fa-user"></i> <?php echo $usern; ?></div>
                                        <ul>
                                          <!--- ALL QUESTION AND ANSWER SECTION DETAILS START -->   
                                         <?php
                                          
                                        //$data['row'] = $this->Conference_model->get_records("*","tbl_posts","user_id='$userid'","post_id ASC","$per_page","$startfrom");
                                          $rec_noffy = $this->db->query("SELECT COUNT( DISTINCT post_id) AS U FROM `tbl_comments` WHERE user_id='".$userid."' ORDER BY post_id DESC"); 
                            $rec_qgh = $rec_noffy->result(); 
                            if(!empty($rec_qgh)){
                              foreach ($rec_qgh as $gen) {
                                $selpoi = $gen->U;

                              }

                            }
                               

                          $config['base_url'] = base_url().'admin/website-user/comment-details/'.$userid.'/page/';
                          $config['first_url'] = base_url().'admin/website-user/comment-details/'.$userid;
                          $config["uri_segment"] = 6;
                          $config['total_rows'] = $selpoi;
                          $config['per_page'] = $this->Conference_model->per_page;
                          $config["num_links"] = $this->Conference_model->num_links;
                          $config["use_page_numbers"] = TRUE;
                          //config for bootstrap pagination class integration
                          $config['full_tag_open'] = '<ul class="pagination">';
                          $config['full_tag_close'] = '</ul>';
                          $config['first_link'] = "&laquo First";
                          $config['last_link'] = "Last &raquo";
                          $config['first_tag_open'] = '<li  class="page-item ">';
                          $config['first_tag_close'] = '</li>';
                          $config['prev_link'] = 'Prev';
                          $config['prev_tag_open'] = '<li class="page-item">';
                          $config['prev_tag_close'] = '</li>';
                          $config['next_link'] = 'Next';
                          $config['next_tag_open'] = '<li  class="page-item">';
                          $config['next_tag_close'] = '</li>';
                          $config['last_tag_open'] = '<li  class="page-item">';
                          $config['last_tag_close'] = '</li>';
                          $config['cur_tag_open'] = '<li class="page-item active"><a href="#">';
                          $config['cur_tag_close'] = '</a></li>';
                          $config['num_tag_open'] = '<li  class="page-item">';
                          $config['num_tag_close'] = '</li>';
                          $this->pagination->initialize($config);

                          $page = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
                          $per_page = $config["per_page"];
                          $startm = $page;
                          if($page>1)
                          $startm = $page-1;
                          $startfrom = $per_page*$startm;
                          $data['startfrom'] = $startfrom;
                          $data['pagination'] = $this->pagination->create_links(); 
                          


//$data['row'] = $this->Conference_model->get_records("*","tbl_comments","user_id='$userid'","post_id DESC","$per_page","$startfrom");
                         //PAGINATION BLOCK END                
                          $rec_dcmt = $this->db->query("SELECT DISTINCT `post_id` FROM `tbl_comments` WHERE `user_id`='".$userid."' ORDER BY `post_id` DESC LIMIT $per_page OFFSET $startfrom ");
                            $rec_exicute = $rec_dcmt->result();
                            if(!empty($rec_exicute)){
                            foreach ($rec_exicute as $podeta) {
                                $post_id = $podeta->post_id;
                              $fff_poid = base64_encode($post_id);


$rec_qu = $this->db->query("SELECT DISTINCT `post_title`,`posted_date` FROM `tbl_posts` WHERE  post_id='".$post_id."' ORDER BY `post_id` DESC "); 
                            $rec_ques = $rec_qu->result();
                                
                            //  $rec_ques = $this->Conference_model->get_records("*","tbl_posts","post_id='$post_id'");
                                if(!empty($rec_ques)){
                                   foreach ($rec_ques as $postdetails) {
                                    $post_titles = $postdetails->post_title;
                                    $posted_dates = $postdetails->posted_date;
                                    $final_posteddate = date('d.m.Y' , strtotime($posted_dates));

                            //$rec_commde = $this->Conference_model->get_records("*","tbl_comments","user_id='$userid' and post_id='$post_id'","cmt_id DESC");  

                            $rec_com = $this->db->query("SELECT DISTINCT `user_cmt`,`commented_date` FROM `tbl_comments` WHERE `user_id`='".$userid."' AND post_id='".$post_id."' ORDER BY `cmt_id` DESC   "); 
                            $rec_commde = $rec_com->result();

        
                          ?>
                                            <li>
                                                
                                                <a href="javascript:void(0);" style="font-size:13px !important;"><?php echo $post_titles;?> </a>
                                            
                                            <div class="activity-date"> <i class="fa fa-calendar-alt"></i> <?php echo $final_posteddate;?></div>
                                            <?php
                                            if(!empty($rec_commde)){
                                            foreach ($rec_commde as $commentdetails) {
                                                    $cmt_user = $commentdetails->user_cmt;
                                                    $cmt_date = $commentdetails->commented_date;
                                                    $final_commenteddate = date('d.m.Y' , strtotime($cmt_date));
                                                    

                                            ?>




                                                <div class="activity-question-answer"> 
                                                   <?php echo $cmt_user; ?>
                                                    <div class="activity-date mtp10"> <i class="fa fa-calendar-alt"></i>  <?php echo $final_commenteddate;?></div>
                                                </div>
                                             <?php
                                               }
                                              }
                                             ?>

                                            </li>
                                            <?php
         
                                             }

                                            }
                                           }
                                          } 

                                           ?>
                                             <!--- ALL QUESTION AND ANSWER SECTION DETAILS END -->

                                        </ul>

                                   

                                    </div>
                           
                                   <div class="user-pagination" style="float: right;">                                        
                                                <?php print_r($data['pagination']); ?>
                                  </div>                  

                                                     <!--- ANSWER BLOG END --->
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    



                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>

    </body>
</html>
