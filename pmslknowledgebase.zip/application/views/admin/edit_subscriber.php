<?php
foreach ($subscriber_details as $rows)
{
    $userid = $rows['subscriber_id'];
    $email_id = $rows['subscriber_email'];                  
    $status = $rows['subscriber_status'];
}
?>


<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
    </head>
    <body class="body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fas fa-users"></i>
                             <h1>Edit Subscriber </h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/subscriber" class="adduser"> Manage Subscriber</a>
                                <div class="add-line"></div>
                                <div class="row">
                                    <?php echo $message;  ?>
                                    <div class="col-xl-12 col-lg-12"> 
                                        <form class="add-user" name="form_sub" id="form_sub"  method="post">
                                            <div class="row">
                                                

                                                <div class="col-xl-6 col-lg-6 "> 

                                                    <div class="form-group">
                                                        <label>Email Id</label>
                                                    <input type="text" class="form-control fld" placeholder="Enter email" name="email" id="email" value="<?php echo set_value('email',$email_id); ?>">
                                                        
                                                    </div>

                                                </div>


                                                <div class="clearfix"></div> 

                                                <div class="col-xl-12 col-lg-12">
                                                    <div class="reset-button"> 
                                        <button type="submit" class="redbtn" name="btnSubmit" id="btnSubmit">Update</button>
                                        <button type="button" class="blackbtn" onClick="window.location='<?php echo base_url(); ?>admin/subscriber'">Back</button> 
                                                    </div>
                                                </div>

                                            </div></form>
                                    </div>

                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>

        <script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/js_validation/jquery.validate.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js_validation/validation.js"></script>


    </body>
</html>
