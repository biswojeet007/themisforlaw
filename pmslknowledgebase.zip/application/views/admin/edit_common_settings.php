<?php
foreach ($row as $rows) {
    $parid = $rows['parid'];
    $parameter = $rows['parameter'];
    $par_value = $rows['par_value'];
}
?>


<!DOCTYPE html>

<html>
    <head>
        <?php include("head.php"); ?>
    </head>
    <body class="body-img inr-body-img">

        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">

                <div class="container-fluid ">


                    <?php include("sidemenu.php"); ?>


                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fas fa-cog"></i>
                            <h1>Edit Common Settings </h1>
                        </div>
                        <div class="row">

                            <div class="col-xl-12 col-lg-12">
                                <a href="<?php echo base_url(); ?>admin/common_settings" class="adduser">Common Settings</a>
                                <div class="add-line"></div>
                                <div class="row">
                                    <?php echo $message; ?>

                                    <?php
                                    $vclass = "col-md-6";
                                    $vtype = "text";
                                    //Conditions to show Fields -> Input or Textarea or Contents Editor
                                    ?>
                                    <div class="col-xl-12 col-lg-12"> 
                                        <form class="add-user" name="form_country" id="form_country"  method="post">
                                            <div class="row">
                                                <div class="col-xl-6 col-lg-6 "> 
                                                    <div class="form-group">
                                                        <label><?php echo $parameter; ?></label>

                                                        <input type="<?php echo $vtype; ?>" class="form-control" placeholder="Enter <?php echo $parameter; ?>" name="par_value" id="par_value" value="<?php echo set_value('par_value', $par_value); ?>" />


                                                    </div>
                                                </div>


                                                <div class="clearfix"></div> 



                                                <div class="col-xl-12 col-lg-12">
                                                    <div class="reset-button"> 
                                                        <button type="submit" class="redbtn" name="btnSubmit" id="btnSubmit">Update</button>
                                                        <button type="button" class="blackbtn" onClick="window.location = '<?php echo base_url(); ?>admin/common_settings'">Back</button> 
                                                    </div>
                                                </div>

                                            </div></form>
                                    </div>

                                </div>
                                <div class="clearfix"></div>


                            </div>


                        </div>

                    </div>



                </div>


            </section>

        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>

        <script type="text/javascript" src="<?php echo base_url(); ?>assets/admin/js_validation/jquery.validate.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js_validation/validation.js"></script>


    </body>
</html>
