<!DOCTYPE html>
<html>
    <head>
        <?php include("head.php"); ?>
        <link href="<?php echo base_url(); ?>assets/admin/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
    </head>
    <body class="body-img inr-body-img">
        <?php include("header.php"); ?>
        <div class="min-height">
            <section class="content-body-sec">
                <div class="container-fluid ">
                    <?php include("sidemenu.php"); ?>
                    <div class="right-sec ">
                        <div class="titile-main-hding">
                            <i class="fa fa-user-tie"></i>
                            <h1>Manage Website Users </h1>
                        </div>
                        <form class="panelsearch form-search col-md-4 " style="float: right;" name="form_search" method="post">
                            <div class="input-group">
                                <input type="text" class="form-control defl-fld" placeholder="Search Name or Email " name="search" value="<?php echo set_value('search', $search); ?>">
                                <span class="input-group-btn">
                                    <button class="defl-fld-btm" type="submit">Search</button>
                                </span>
                            </div><!-- /input-group -->
                        </form><div class="clearfix"></div>
                        <div class="row" style="margin-top: 10px;">

                            <div class="col-xl-12 col-lg-12">
                                <div class="row">
                                    <?php echo $message; ?>
                                    <div class="col-xl-12 col-lg-12"> 
                                        <div class="table-responsive">
                                            <table id="example1" class="table table-bordered table-striped table-hover mng-tbl-txt">
                                                <thead>
                                                    <tr class="info">
                                                        <th width="8%">Sl #</th>
                                                        <th width="15%"> Name</th>
                                                        <th width="15%">Title</th>

                                                        <th width="8%">Email Id</th>
                                                        <th width="8%">Image</th>
                                                        <th width="8%">Description</th>

                                                        <th width="12%">Date</th>
                                                        <th width="10%">Status</th>
                                                        <th width="15%">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php
                                                    $cnt = isset($startfrom) ? $startfrom : 0;
                                                    if (!empty($row)) {
                                                        foreach ($row as $rows) {
                                                            $cnt++;
                                                            $user_id = $rows['user_id'];
                                                            $username = $rows['username'];
                                                            $user_title = $rows['user_title'];
                                                            $user_email = $rows['user_email'];
                                                            $user_pic = $rows['user_pic'];
                                                            $user_desc = $rows['user_desc'];
                                                            $date = $rows['created_date'];
                                                            $status = $rows['status'];
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $cnt; ?></td>
                                                                <td><?php echo $username; ?></td>
                                                                <td><?php echo $user_title; ?></td>
                                                                <td><?php echo $user_email; ?></td>
                                                                <td><?php
                                                                    if (file_exists("./assets/images/" . $user_pic) && ($user_pic != '')) {
                                                                        echo '<a href="' . base_url() . 'assets/images/' . $user_pic . '" target="_blank"><img src="' . base_url() . 'assets/images/' . $user_pic . '" style="width:70px;height:70px" alt="image" class="img_fluid " /></a>';
                                                                    }
                                                                    ?></td>

                                                   <td><?php echo mb_strimwidth($user_desc, 0, 60, "...");?></td>
                                                                <td>  <?php echo date(' dS  F  Y ', strtotime($date)); ?></td>

                                                                <td>

                                                                    <?php if ($status == '1') { ?>
                                                                        <span class="status" data-id="<?php echo "status-" . $user_id; ?>"><a href="javascript:void(0)" title="Status is active. Click here to make it inactive."><span class="label-custom label label-success">Active</span></a></span>
                                                                    <?php } else { ?>
                                                                        <span class="status" data-id="<?php echo "status-" . $user_id; ?>"><a href="javascript:void(0)" title="Status is inactive. Click here to make it active."><span class="label-custom label label-danger">Inactive</span></a></span>
                                                                    <?php } ?>
                                                                </td>

                                                                <td>

                                                                    <a href="<?php echo base_url() . 'admin/website_user/edit/' . $user_id; ?>" class="btn btn-success btn-sm view tbl-icon-btm" title="View"> <i class="far fa-edit"></i></a>

                                                                    <a href="<?php echo base_url() . 'admin/website_user/view/' . $user_id; ?>" class="btn btn-primary btn-sm view tbl-icon-btm" title="View"> <i class="far fa-eye"></i></a>


                                                                    <a onClick="return confirm('Are you sure to delete this website user?')" href="<?php echo base_url() . 'admin/website_user/delete/' . $user_id; ?>" class="btn btn-danger btn-sm tbl-icon-btm" title=""><i class="far fa-trash-alt"></i> </a>

                                                                </td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    } else {
                                                        ?>
                                                        <tr>
                                                            <td class="text-center" colspan="10"> No data available in table </td>
                                                        </tr>
                                                        <?php
                                                    }
                                                    ?>

                                                </tbody>
                                            </table>
                                            <div class="user-pagination" style="float: right;">                                        
                                                <?php echo $pagination; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <div class="clearfix"></div>
        <?php include("footer.php"); ?>
        <script src="<?php echo base_url(); ?>assets/admin/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/dataTables.bootstrap4.min.js" type="text/javascript"></script>

        <script type="text/javascript">
                                                                $(document).ready(function () {
                                                                    $('#example').DataTable();
                                                                });

        </script>

        <script type="text/javascript">
            $(document).on('click', '.status', function () {
                if (confirm('Are you sure to change the status?'))
                {
                    var val = $(this).data("id");
                    var valsplit = val.split("-");
                    var id = valsplit[1];
                    jQuery('[data-id=' + val + ']').after('<div class="spinner" style="text-align:center;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-1x"></i></div>');
                    $.ajax({
                        url: "<?php echo base_url(); ?>admin/website_user/changestatus/" + id,
                        type: 'post',
                        cache: false,
                        processData: false,
                        success: function (data) {
                            jQuery('.spinner').remove();
                            if (data == 1) //Inactive
                            {
                                jQuery('[data-id=' + val + ']').html('<a href="javascript:void(0)" title="Status is inactive. Click here to make it active."><span class="label-custom label label-danger">Inactive</span></a>');
                            } else if (data == 0) //Active
                            {
                                jQuery('[data-id=' + val + ']').html('<a href="javascript:void(0)" title="Status is active. Click here to make it inactive."><span class="label-custom label label-success">Active</span></a>');
                            } else
                            {
                                alert("Sorry! Unable to change status.");
                            }
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
                        }
                    });
                }
            });
        </script>


    </body>
</html>
