<!DOCTYPE html>
<html>
    <head>
        <title>PMSL</title>
        <?php include('head.php'); ?>
    </head>
    <body>
        <?php include('header.php'); ?>
        <div class="clearfix"></div>
        <div class="min-height">

            <section class="home-body-sec">
                <div class="container">
                    <?php include('sidebar.php'); ?>
                    <div class="right-sec">

                        <div class="row">

                            <div class="col-xl-8 col-lg-8 offset-xl-2 offset-lg-2">
                                <form class="login-form text-center brdr-animation" name="loginform" id="loginform" method="post">
                                    <?php echo $message; ?>
                                    <h1 > Log in</h1>
                                    <div class="forgt-txt"> Welcome Back ! Login To access the 
                                        sweet marketplace .<br>
                                        Did You <a href="#" data-toggle="modal" data-target="#forget">Forgot your Password</a> </div>
                                    <div class="form-group">
                                        <input type="text" class="logn-fld" name="email" value="<?php echo set_value('email');?>" placeholder="Username">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="logn-fld" name="password" value="<?php echo set_value('password');?>" placeholder="Password">
                                    </div>
                                    <button type="submit" class="form-submit" name="btnSignin" id="btnSignin">Log in</button>
                                    <div class="or-txt">OR </div>
                                    <div class="social-login text-center">
                                        <a href="#" class="fb"><i class="fab fa-facebook-f "></i></a>
                                        <a href="#" class="tw"><i class="fab fa-twitter"></i></a>
                                        <a href="#" class="gp"><i class="fab fa-google-plus-g"></i></a>
                                    </div>
                                    <div class="login-txt1"> I Don't Have an Account <a href="<?php echo base_url(); ?>signup" class="#">  Sign up</a></div>
                                </form>

                            </div>


                        </div>
                    </div>
                </div>

                <!-- The Modal -->
                <div class="modal fade"  id="forget">
                    <div class="modal-dialog" >
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Forgot Password</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">
                            <div id="frmError"></div>    
                             <form  name="forgot_password" id="forgot_password" method="post">   
                                <div class="form-group">
                                    <input type="text" class="forgt-fld" name="forgotemail" id="forgotemail" placeholder="Email Id">
                                </div>
                                <button type="submit" id="forgot-e" class="forgt-submit">Submit</button>
                             </form>
                            </div>

                            <!-- Modal footer -->


                        </div>
                    </div>
                </div>

        </div>
    </section>

    <div class="clearfix"></div>
</div>
<?php include('footer.php'); ?>
<script type="text/javascript">
$(document).ready(function(){
 jQuery("#forgot_password").validate({
        rules: {            
            forgotemail: {
                required: true,
                email: true
            }
        },
        messages:{
            forgotemail:{
                required:"Enter email id",
                email:"Invalid email id"
            }
        },
      submitHandler: function(form) {
            $('#frmError').html('<div style="text-align:center"><i style="color:#377b9e" class="fa fa-spinner fa-spin fa-1x"></i> <span style="color:#377b9e">Processing...</span></div>');
            $.ajax({
            url: "<?php echo base_url(); ?>login/forgot_email",
            type: 'post',
            cache: false,
            processData: false,
            data: $('#forgot_password').serialize(),
            success: function(result) {
                //alert(result);
            if (result == '1') {
            jQuery("#frmError").html('<div class="successmsg"><i class="fa fa-check"></i> A link has been sent to your Email ID to change your password.</div>');
            } else if(result == '2') {
            jQuery("#frmError").html('<div class="errormsg"><i class="fa fa-times"></i> Unable to process your request.</div>');
            //jQuery('#frm_LoginPop')[0].reset();
            }else if(result == '3') {
            jQuery("#frmError").html('<div class="errormsg"><i class="fa fa-times"></i> This email id is inactive.</div>');
            //jQuery('#frm_LoginPop')[0].reset();
            }else{
                jQuery("#frmError").html('<div class="errormsg"><i class="fa fa-times"></i>Invalid email id.</div>');
            }

            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
            $('#frmError').html('<div class="errormsg"><i class="fa fa-times"></i> Invalid Username or Password.</div>');
            }
            });
            return false;
            }

     });
    
  });    
 /* $("#forgot-e").on('click',function(){ 
    var forgotemail = $("#forgotemail").val();
    if(forgotemail!=''){
        $('#msg-forgot').html('<div style="text-align:center"><i style="color:#377b9e" class="fa fa-spinner fa-spin fa-3x"></i> <span style="color:#377b9e">Processing...</span></div>');
        
        $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>login/forgot_email/?forgotemail="+forgotemail, 
                dataType: "text",  
                cache:false,
                success: 
                    function(data){
                        alert(data);  //as a debugging message.

                     //$("#msg-forgot").html(data);

                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                              alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
                         }

            });

     }

 });*/
   
</script>
</body>
</html>
