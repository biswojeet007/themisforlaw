
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Website_user extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');	
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');	
		$this->load->database();
		$this->load->model('Conference_model');
		$this->load->library('pagination');
		if($this->session->userdata('adminid') == "")
		{
			redirect(base_url().'admin/logout','refresh');
		}

		$allusermodules = $this->session->userdata('allpermittedmodules');
		if(!(in_array(4, $allusermodules))) 
		{
			redirect(base_url().'admin/dashboard','refresh');
		}
 	}
		
 

	public function index()
	{
		$data['message'] = $this->session->flashdata('message');
           $wheresearch = ""; $search = "";
		if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
			$search = $_REQUEST['search'];
			$wheresearch = "username LIKE '%$search%' OR user_email LIKE '%$search%' OR user_title LIKE '%$search%'";
	
		}
		$pagesrch = "";
		if($search!='') {
			$pagesrch = "?search=".$search;
		}
		$data['search']=$search;
		$noof_rec = $this->Conference_model->noof_records("user_id", "tbl_user", "$wheresearch");

		$config['base_url'] = base_url().'admin/website_user/page/';
			$config['first_url'] = base_url().'admin/website_user'.$pagesrch;
			$config["uri_segment"] = 4;
			$config['total_rows'] = $noof_rec;
			$config['per_page'] = $this->Conference_model->per_page;
			$config["num_links"] = $this->Conference_model->num_links;
			$config["use_page_numbers"] = TRUE;
			//config for bootstrap pagination class integration
			$config['full_tag_open'] = '<ul class="pagination">';
			$config['full_tag_close'] = '</ul>';
			$config['first_link'] = "&laquo First";
			$config['last_link'] = "Last &raquo";
			$config['first_tag_open'] = '<li  class="page-item ">';
			$config['first_tag_close'] = '</li>';
			$config['prev_link'] = 'Prev';
			$config['prev_tag_open'] = '<li class="page-item">';
			$config['prev_tag_close'] = '</li>';
			$config['next_link'] = 'Next';
			$config['next_tag_open'] = '<li  class="page-item">';
			$config['next_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li  class="page-item">';
			$config['last_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="page-item active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li  class="page-item">';
			$config['num_tag_close'] = '</li>';
			$this->pagination->initialize($config);

			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
			$per_page = $config["per_page"];
			$startm = $page;
			if($page>1)
				$startm = $page-1;
			$startfrom = $per_page*$startm;
			$data['startfrom'] = $startfrom;
// print_r($config);exit;

			$data['pagination'] = $this->pagination->create_links();
		$data['row'] = $this->Conference_model->get_records("*","tbl_user","$wheresearch","user_id DESC","$per_page","$startfrom");
		$this->load->view('admin/website_user',$data);
	}

	

	public function delete()
	
	{
		$delid = $this->uri->segment(4);
		$rimage = $this->Conference_model->showname_fromid("user_pic", "tbl_user", "user_id=$delid");
		$noof_rec = $this->Conference_model->noof_records("user_id","tbl_user","user_id='$delid'");
		if($noof_rec>0)
		{
			
            $del = $this->Conference_model->delete_records("tbl_user", "user_id=$delid");


            if ($del)
            {

            	$delimgs = getcwd() . '/assets/images/' . $rimage;
                if ((file_exists($delimgs)) && (!is_dir($delimgs))) {
                  unlink($delimgs);
                }
               
                $this->session->set_flashdata('message', '<div class="successmsg notification"><i class="fa fa-check"></i> Website User has been deleted successfully.</div>');
            }
            else
                $this->session->set_flashdata('message', '<div class="errormsg notification"><i class="fa fa-times"></i> Website User could not deleted. Please try again.</div>');
          }
		
		redirect(base_url().'admin/website_user','refresh');
	}

public function view()
	{
		$viewid = $this->uri->segment(4);
		$noof_rec = $this->Conference_model->noof_records("user_id","tbl_user","User_id='$viewid'");
		if($noof_rec>0)
		{
			$data['row'] = $this->Conference_model->get_records("*","tbl_user","user_id='$viewid'","");
			$this->load->view('admin/view_website_user', $data);
		}
		else
			redirect(base_url().'admin/website_user','refresh');
	}



	public function comment_details()
	{
		$data['message'] = $this->session->flashdata('message');
		$vuserid = $this->uri->segment(4);
		$noof_rec = $this->Conference_model->noof_records("user_id","tbl_user","user_id='$vuserid'");
		if($noof_rec>0)
		{
			$data['rowssd'] = $vuserid;
			$this->load->view('admin/comment_details', $data);
		}
		else
			redirect(base_url().'admin/website_user','refresh');
	}


	public function changestatus()
	{
		$stsid = $this->uri->segment(4);
		$noof_rec = $this->Conference_model->noof_records("user_id","tbl_user","user_id='$stsid'");
		if($noof_rec>0)
		{
			
				$status = $this->Conference_model->showname_fromid("status","tbl_user","user_id=$stsid");
				if($status==1)
					$updatedata = array('status' => 0);
				else
					$updatedata = array('status' => 1);
				$updatestatus = $this->Conference_model->update_records("tbl_user",$updatedata,"user_id=$stsid");
				if($updatestatus)
					echo $status;
				else
					echo "error";
			
		}
		exit();
	}


public function edit()
	{
		$editid = $this->uri->segment(4);
		$noof_rec = $this->Conference_model->noof_records("user_id","tbl_user","user_id='$editid'");
		if($noof_rec>0)
		{
			$data['message'] = $this->session->flashdata('message');
			
			$data['orgnmm'] = $this->Conference_model->get_records("*","tbl_user","user_id=$editid","");
			
			if (isset($_POST['btnEditProfile']) && !empty($_POST))
			{
	       $this->form_validation->set_rules('username','Username','trim|required|xss_clean');
		   $this->form_validation->set_rules('user_title','Title','trim|required|xss_clean');
           $this->form_validation->set_rules('user_email','Email','trim|required|xss_clean|valid_email');
           //$this->form_validation->set_rules('user_pic','Image','trim|required|xss_clean');
           $this->form_validation->set_rules('user_desc','Description','trim|required|xss_clean');
				
				$sess_userid = $this->session->userdata('adminid');
				$date = date("Y-m-d H:i:s");
				if ($this->form_validation->run() == true)
				{
			$username = $this->input->post('username');
			$usertitle	= $this->input->post('user_title');	
			$user_email = $this->input->post('user_email');
			$userpic   = $this->input->post('user_pic');
           	$userdesc   = $this->input->post('user_desc');
            
					$rimage = $this->Conference_model->showname_fromid("user_pic","tbl_user","user_id=$editid");
					if (isset($_FILES) && !empty($_FILES))
					{
						$config['upload_path'] = './assets/images/';
						$config['allowed_types'] = 'gif|jpg|jpeg|png|bmp';
						$config['max_size'] = '0';
						$config['overwrite'] = FALSE;
						$config['encrypt_name'] = TRUE;

						$this->load->library('upload', $config);
						if($this->upload->do_upload('user_pic'))
						{
							$unlinkimage = getcwd().'/assets/images/'.$rimage;
							if (file_exists($unlinkimage) && !is_dir($unlinkimage))
							{
								unlink($unlinkimage);
							}
							$this->load->library('image_lib');
							$photo_path = $this->upload->data();
							$filename = $photo_path['file_name'];
							//resize:
							$config['source_image'] = $this->upload->upload_path.$this->upload->file_name;
							$config['maintain_ratio'] = FALSE;
							$config['width'] = 1920;
							$config['height'] = 702;
							$this->image_lib->initialize($config);
							$this->image_lib->resize();
						}
						else
						{
							$filename = $rimage;	
						}
					}
					else
					{
						$filename = $rimage;
					}

           

             //$noof_signedupuser = $this->Conference_model->noof_records("user_id", "tbl_user", "user_email='$user_email' and user_id ='$editid'");
                          
						 
                 // if ($noof_signedupuser > 0) {
					        $update_data = array(               
							'username' => $username,
							'user_title' => $usertitle,
                            'user_email' => $user_email,
							'user_pic' => $filename,
							'user_desc' =>$userdesc,
                            'update_date' => $date
												
					
				);
					
					
						
				$updatedb = $this->Conference_model->update_records('tbl_user',$update_data,"user_id=$editid");
						if($updatedb)
						{
							
							$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Website User edited successfully.</div>');
						}
						else
						{	
							$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Website User could not edited. Please try again.</div>');
						}
					
					redirect(base_url().'admin/website_user/edit/'.$editid,'refresh');
				//}
			}
				else
				{
					//set the flash data error message if there is one
					$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
				}
			}
			$this->load->view('admin/edit_website_user', $data);
		}
		else
			redirect(base_url().'admin/website_user','refresh');
	}
}



	
	

