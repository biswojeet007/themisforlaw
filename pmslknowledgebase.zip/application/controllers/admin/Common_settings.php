<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_settings extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Common_model');
		if($this->session->userdata('adminid') == "")
		{
			redirect(base_url().'admin/logout','refresh');
		}
		$allusermodules = $this->session->userdata('allpermittedmodules');
		if(!(in_array(3, $allusermodules))) {
			redirect(base_url().'admin/dashboard','refresh');
		}
 	}

	public function index()
	{
		$data['message'] = $this->session->flashdata('message');
		$data['row'] = $this->Common_model->get_records("*","tbl_parameters","param_type='CS' and status=1","parid ASC","","");
		$this->load->view('admin/common_settings',$data);
	}

	public function edit()
	{
		$editid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("parid","tbl_parameters","parid='$editid'");
		if($noof_rec>0)
		{
			$data['message'] = $this->session->flashdata('message');
			$data['row'] = $this->Common_model->get_records("*","tbl_parameters","parid='$editid'","parid ASC");
			if (isset($_POST['btnSubmit']) && !empty($_POST))
			{
				$this->form_validation->set_rules('par_value', 'Value', 'trim|required');

				$sess_userid = $this->session->userdata('adminid');
				$date = date("Y-m-d H:i:s");
				if ($this->form_validation->run() == true)
				{
					$par_value = $this->input->post('par_value');

					$update_data = array(
						'par_value'		=> $par_value,
						'updated_date'	=> $date,
						'updated_by'	=> $sess_userid
					);

					$updatedb = $this->Common_model->update_records('tbl_parameters',$update_data,"parid=$editid");
					if($updatedb) {
						$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Parameter value saved successfully.</div>');
					}
					else {
						$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Parameter value could not saved. Please try again.</div>');
					}
					redirect(base_url().'admin/common_settings/edit/'.$editid,'refresh');
				}
				else
				{
					//set the flash data error message if there is one
					$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
				}
			}
			$this->load->view('admin/edit_common_settings',$data);
		}
		else
			redirect(base_url().'admin/common_settings','refresh');
	}
}
