<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');	
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');	
		$this->load->database();
		$this->load->model('Common_model');
		$this->load->library('pagination');
		if($this->session->userdata('adminid') == "")
		{
			redirect(base_url().'admin/logout','refresh');
		}

		$allusermodules = $this->session->userdata('allpermittedmodules');
		if(!(in_array(5, $allusermodules))) {
			redirect(base_url().'admin/dashboard','refresh');
		}
		
 	}

	public function index()
	{
		$data['message'] = $this->session->flashdata('message');

		  $wheresearch = ""; $search = "";
		if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
			$search = trim($_REQUEST['search']);
			$wheresearch = "post_title LIKE '%$search%' OR post_desc LIKE '%$search%'";
	
		}
		$pagesrch = "";
		if($search!='') {
			$pagesrch = "?search=".$search;
		}
		$data['search']=$search;
		$noof_rec = $this->Common_model->noof_records("post_id", "tbl_posts", "$wheresearch");

		$config['base_url'] = base_url().'admin/posts/page/';
			$config['first_url'] = base_url().'admin/posts'.$pagesrch;
			$config["uri_segment"] = 4;
			$config['total_rows'] = $noof_rec;
			$config['per_page'] = $this->Common_model->per_page;
			$config["num_links"] = $this->Common_model->num_links;
			$config["use_page_numbers"] = TRUE;
			//config for bootstrap pagination class integration
			$config['full_tag_open'] = '<ul class="pagination">';
			$config['full_tag_close'] = '</ul>';
			$config['first_link'] = "&laquo First";
			$config['last_link'] = "Last &raquo";
			$config['first_tag_open'] = '<li  class="page-item ">';
			$config['first_tag_close'] = '</li>';
			$config['prev_link'] = 'Prev';
			$config['prev_tag_open'] = '<li class="page-item">';
			$config['prev_tag_close'] = '</li>';
			$config['next_link'] = 'Next';
			$config['next_tag_open'] = '<li  class="page-item">';
			$config['next_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li  class="page-item">';
			$config['last_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="page-item active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li  class="page-item">';
			$config['num_tag_close'] = '</li>';
			$this->pagination->initialize($config);

			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
			$per_page = $config["per_page"];
			$startm = $page;
			if($page>1)
				$startm = $page-1;
			$startfrom = $per_page*$startm;
			$data['startfrom'] = $startfrom;
            // print_r($config);exit;

			$data['pagination'] = $this->pagination->create_links();
		$data['row'] = $this->Common_model->get_records("*","tbl_posts","$wheresearch","post_id DESC","$per_page","$startfrom");
		
		$this->load->view('admin/manage_posts',$data);
	}


	public function delete()
	
	{
		
		$delid = $this->uri->segment(4);

	   $noof_rec = $this->Common_model->noof_records("post_id","tbl_posts","post_id='$delid'");
		if($noof_rec>0)
		{
		
            $del = $this->Common_model->delete_records("tbl_posts", "post_id=$delid");
            if ($del)
            {

            	$noof_rec1 = $this->Common_model->noof_records("post_id","tbl_post_tags","post_id='$delid'");
            	if($noof_rec1>0){
            		$del1 = $this->Common_model->delete_records("tbl_post_tags", "post_id='$delid'");

            	}
		
               

               //echo 1;
                $this->session->set_flashdata('message', '<div class="successmsg notification"><i class="fa fa-check"></i> Posts has been deleted successfully.</div>');
            }
            else{
            	//echo 0;
                $this->session->set_flashdata('message', '<div class="errormsg notification"><i class="fa fa-times"></i> Posts could not deleted. Please try again.</div>');
          }
		}
		redirect(base_url().'admin/posts','refresh');
	}

	

	public function changestatus()
	{
		$stsid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("post_id","tbl_posts","post_id='$stsid'");
		if($noof_rec>0)
		{
			$status = $this->Common_model->showname_fromid("status","tbl_posts","post_id=$stsid");
			if($status==1)
				$updatedata = array('status' => 0);
			else
				$updatedata = array('status' => 1);
			$updatestatus = $this->Common_model->update_records("tbl_posts",$updatedata,"post_id=$stsid");
			if($updatestatus)
				echo $status;
			else
				echo "error";
		}
		exit();
	}

	//EDIT SECTION FOR POSTS STSRT
    public function edit()
	{
		$editid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("post_id","tbl_posts","post_id='$editid'");
		if($noof_rec>0)
		{
			$data['message'] = $this->session->flashdata('message');
			
			
			$data['tagnmm'] = $this->Common_model->get_records("*","tbl_posts","post_id=$editid","");
			//MY DYNAMIC TAG SECTION START

			//MY DYNAMIC TAG SECTION END
			
			if (isset($_POST['btnSubmit']) && !empty($_POST))
			{
	
	        $post_title = $this->form_validation->set_rules('post_title', 'Post Title', 'trim|required|xss_clean');
		    $post_desc = $this->form_validation->set_rules('post_desc', 'Post Description', 'trim|required|xss_clean');	
				
				$sess_userid = $this->session->userdata('userid');
				$date = date("Y-m-d H:i:s");
				if ($this->form_validation->run() == true)
				{
				$post_title = $this->input->post('post_title');
				$post_desc = $this->input->post('post_desc');
                $update_data = array(
					
					'post_title'	=> $post_title,
					'post_desc'		=> $post_desc,

				);
					
					
						
						$updatedb = $this->Common_model->update_records('tbl_posts',$update_data,"post_id=$editid");
						if($updatedb)
						{
							$unic_userid = $this->input->post('unic_userid');
                            $post_tags = $this->input->post('selected_topics');
                            if (($post_tags != '')) {
			
									$selected_topicsArr = explode(',', $post_tags);
									$counttopics = count($selected_topicsArr);
									$insert_rec = NULL;
									$postdate = date("Y-m-d H:i:s");
									for($i=0; $i<$counttopics; $i++)
									{
										$valtopic = $selected_topicsArr[$i];
										$valtopicid = $valtopic;
										$query_datachild = array(
											'post_id'	=> $editid,
											'tag_id'		=> $valtopicid,
											'updated_date'	=> $postdate
											
										);
	$noof_durc = $this->Common_model->noof_records("post_id, tag_id", "tbl_post_tags", "post_id='$editid' and tag_id='$valtopicid'");
							if($noof_durc>0){
                                
							   }else{
								$insert_rec = $this->Common_model->insert_records("tbl_post_tags", $query_datachild);
							   	}

									}

						 }	

                            //MULTI TAG EDIT END




							
							$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Posts edited successfully.</div>');
						}
						else
						{	
							$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Posts could not edited. Please try again.</div>');
						}
					//}
					//else
					//{
					//	$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> The Email field must contain a unique value.</div>');
				//	}
					
					redirect(base_url().'admin/posts/edit/'.$editid,'refresh');
				}
				else
				{
					//set the flash data error message if there is one
					$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
				}
			}
			$this->load->view('admin/edit_posts', $data);
		}
		else
			redirect(base_url().'admin/posts','refresh');
	}

	//EDIT SECTION FOR POSTS END

	
	// ADD NEW TAG IN EDIT SECTION START


	//VIEW SECTION FOR POSTS START
    public function view()
	{
		$viewid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("post_id","tbl_posts","post_id='$viewid'");
		if($noof_rec>0)
		{
			$data['row'] = $this->Common_model->get_records("*","tbl_posts","post_id=$viewid","");
			$this->load->view('admin/view_posts', $data);
		}
		else
			redirect(base_url().'admin/posts','refresh');
	}

	//VIEW SECTION FOR POSTS END

       public function addnewtag()
       {

       $ntag = $this->input->post('newtag');
	   $rec_check = $this->Common_model->noof_records("tag_id","tbl_tags","tag_name='$ntag'");
		
	  if($rec_check>0){
             echo 1;
		    }else{
  
		       $tag_date = date("Y-m-d H:i:s");
		       $insert_tdata = array(
			                      'tag_name' => $ntag,
				                  'status' => 1,
				                  'tag_date' => $tag_date
			                       );
	           $insert_ntag = $this->Common_model->insert_records("tbl_tags",$insert_tdata);
		      echo 2;
	
	          }
		   	   
	   

    } 
	// ADD NEW TAG IN EDIT SECTION END

	//DELETE APPEND TAGS START
    public function delete_apptag(){
    	$delid = $this->uri->segment(4);
    	$posid = $this->input->post('posid');
    	$ta_id = $this->input->post('ta_id');
    
$noof_rec = $this->Common_model->noof_records("tag_id","tbl_post_tags","post_id='$posid' and tag_id='$ta_id' ");

		if($noof_rec>0){
			$del_rec = $this->Common_model->delete_records("tbl_post_tags","post_id='$posid' and tag_id='$ta_id' ");
			echo 'Tag Removed Successfully ';

		}
		    	
    }
	//DELETE APPEND TAGS END
	
}





   