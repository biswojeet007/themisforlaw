<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tags extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');	
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');	
		$this->load->database();
		$this->load->model('Common_model');
		$this->load->library('pagination');
		if($this->session->userdata('adminid') == "")
		{
			redirect(base_url().'admin/logout','refresh');
		}

		$allusermodules = $this->session->userdata('allpermittedmodules');
		if(!(in_array(2, $allusermodules))) {
			redirect(base_url().'admin/dashboard','refresh');
		}
		
 	}

	public function index()
	{
		$data['message'] = $this->session->flashdata('message');
		$data['row'] = $this->Common_model->get_records("*","tbl_tags","","tag_name ASC","","");
		$this->load->view('admin/manage_tags',$data);
	}

	public function add()
	{

		$data['message'] = $this->session->flashdata('message');
		//print_r($_POST);
		if (isset($_POST['btnSubmit']) && !empty($_POST))
		{

	$this->form_validation->set_rules('tag_name', 'Tags', 'trim|required|xss_clean|is_unique[tbl_tags.tag_name]');
	
			
			$sess_userid = $this->session->userdata('adminid');
			//echo "$sess_userid";
			$date = date("Y-m-d H:i:s");
			if ($this->form_validation->run() == true)
			{
				$tag_name = $this->input->post('tag_name');
				
				
				$insert_data = array(
					'tag_name'	=> $tag_name,
					'status'		=> 1,
					'tag_date' => $date
					
				);
				//print_r($insert_data);
				$insertdb = $this->Common_model->insert_records('tbl_tags', $insert_data);
				if($insertdb)
					$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Tags added successfully.</div>');
				else
					$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Tags could not added. Please try again.</div>');
				redirect(base_url().'admin/tags/add','refresh');
			}
			else
			{
				//set the flash data error message if there is one
				$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
			}
		}

		$this->load->view('admin/add_tags',$data);
		
		
	}

	

	public function delete()
	
	{
		$delid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("tag_id","tbl_tags","tag_id='$delid'");
		if($noof_rec>0)
		{
		
            $del = $this->Common_model->delete_records("tbl_tags", "tag_id=$delid");
            if ($del)
            {
               
                $this->session->set_flashdata('message', '<div class="successmsg notification"><i class="fa fa-check"></i> Tags has been deleted successfully.</div>');
            }
            else{
                $this->session->set_flashdata('message', '<div class="errormsg notification"><i class="fa fa-times"></i> Tags could not deleted. Please try again.</div>');
          }
		}
		redirect(base_url().'admin/tags','refresh');
	}

	public function changestatus()
	{
		$stsid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("tag_id","tbl_tags","tag_id='$stsid'");
		if($noof_rec>0)
		{
			$status = $this->Common_model->showname_fromid("status","tbl_tags","tag_id=$stsid");
			if($status==1)
				$updatedata = array('status' => 0);
			else
				$updatedata = array('status' => 1);
			$updatestatus = $this->Common_model->update_records("tbl_tags",$updatedata,"tag_id=$stsid");
			if($updatestatus)
				echo $status;
			else
				echo "error";
		}
		exit();
	}

	public function edit()
	{
		$editid = $this->uri->segment(4);
		$noof_rec = $this->Common_model->noof_records("tag_id","tbl_tags","tag_id='$editid'");
		if($noof_rec>0)
		{
			$data['message'] = $this->session->flashdata('message');
			
			$data['tagnmm'] = $this->Common_model->get_records("*","tbl_tags","tag_id=$editid","");
			
			if (isset($_POST['btnSubmit']) && !empty($_POST))
			{
	
	$this->form_validation->set_rules('tag_name', 'Tags', 'trim|required|xss_clean');
				
				
				$sess_userid = $this->session->userdata('adminid');
				$date = date("Y-m-d H:i:s");
				if ($this->form_validation->run() == true)
				{
				$tag_name = $this->input->post('tag_name');
				

				$noof_duprec = $this->Common_model->noof_records("tag_id","tbl_tags","tag_name='$tag_name'  and tag_id!='$editid'");

				if($noof_duprec < 1)
					{

					$update_data = array(
					
					'tag_name'	=> $tag_name,
					'status'		=> 1
					
					
				);
					
					
						
						$updatedb = $this->Common_model->update_records('tbl_tags',$update_data,"tag_id=$editid");
						if($updatedb)
						{
							
							$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Tags edited successfully.</div>');
						}
						else
						{	
							$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Tags could not edited. Please try again.</div>');
						}
					}
					else
					{
						$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> The Tags field must contain a unique value.</div>');
					}
					
					redirect(base_url().'admin/tags/edit/'.$editid,'refresh');
				}
				else
				{
					//set the flash data error message if there is one
					$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
				}
			}
			$this->load->view('admin/edit_tags', $data);
		}
		else
			redirect(base_url().'admin/tags','refresh');
	}

	
	
}





   