<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Comments extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');	
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');	
		$this->load->database();
		$this->load->model('Conference_model');
		$this->load->library('pagination');
		if($this->session->userdata('adminid') == "")
		{
			redirect(base_url().'admin/logout','refresh');
		}

		$allusermodules = $this->session->userdata('allpermittedmodules');
		if(!(in_array(6, $allusermodules))) {
			redirect(base_url().'admin/dashboard','refresh');
		}
		
 	}

  public function index(){
      $data['message'] = $this->session->flashdata('message');

		  $wheresearch = ""; $search = "";
		if (isset($_REQUEST['search']) && !empty($_REQUEST['search'])) {
			$search = $_REQUEST['search'];
			$wheresearch = "user_cmt LIKE '%$search%'";
	
		}
		$pagesrch = "";
		if($search!='') {
			$pagesrch = "?search=".$search;
		}
		$data['search']=$search;
		$noof_rec = $this->Conference_model->noof_records("cmt_id", "tbl_comments", "$wheresearch");

		$config['base_url'] = base_url().'admin/comments/page/';
			$config['first_url'] = base_url().'admin/comments'.$pagesrch;
			$config["uri_segment"] = 4;
			$config['total_rows'] = $noof_rec;
			$config['per_page'] = $this->Conference_model->per_page;
			$config["num_links"] = $this->Conference_model->num_links;
			$config["use_page_numbers"] = TRUE;
			//config for bootstrap pagination class integration
			$config['full_tag_open'] = '<ul class="pagination">';
			$config['full_tag_close'] = '</ul>';
			$config['first_link'] = "&laquo First";
			$config['last_link'] = "Last &raquo";
			$config['first_tag_open'] = '<li  class="page-item ">';
			$config['first_tag_close'] = '</li>';
			$config['prev_link'] = 'Prev';
			$config['prev_tag_open'] = '<li class="page-item">';
			$config['prev_tag_close'] = '</li>';
			$config['next_link'] = 'Next';
			$config['next_tag_open'] = '<li  class="page-item">';
			$config['next_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li  class="page-item">';
			$config['last_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="page-item active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li  class="page-item">';
			$config['num_tag_close'] = '</li>';
			$this->pagination->initialize($config);

			$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
			$per_page = $config["per_page"];
			$startm = $page;
			if($page>1)
				$startm = $page-1;
			$startfrom = $per_page*$startm;
			$data['startfrom'] = $startfrom;
// print_r($config);exit;

			$data['pagination'] = $this->pagination->create_links();
		$data['rows'] = $this->Conference_model->get_records("*","tbl_comments","$wheresearch","cmt_id DESC","$per_page","$startfrom");
		
		$this->load->view('admin/manage_comments',$data);

   }

   public function changestatus()
	{
		$stsid = $this->uri->segment(4);
		$noof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","cmt_id='$stsid'");
		if($noof_rec>0)
		{
			$status = $this->Conference_model->showname_fromid("status","tbl_comments","cmt_id=$stsid");
			if($status==1)
				$updatedata = array('status' => 0);
			else
				$updatedata = array('status' => 1);
			$updatestatus = $this->Conference_model->update_records("tbl_comments",$updatedata,"cmt_id=$stsid");
			if($updatestatus)
				echo $status;
			else
				echo "error";
		}
		exit();
	}

	public function view()
	{
		$viewid = $this->uri->segment(4);
		$noof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","cmt_id='$viewid'");
		if($noof_rec>0)
		{
			$data['row'] = $this->Conference_model->get_records("*","tbl_comments","cmt_id=$viewid","");
			$this->load->view('admin/view_comments', $data);
		}
		else
			redirect(base_url().'admin/comments','refresh');
	}



	public function edit()
	{
		$editid = $this->uri->segment(4);
		$noof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","cmt_id='$editid'");
		if($noof_rec>0)
		{
			$data['message'] = $this->session->flashdata('message');
			$data['comm'] = $this->Conference_model->get_records("*","tbl_comments","cmt_id=$editid","");

			if (isset($_POST['btnSubmit']) && !empty($_POST))
			{
	
		   $commentde = $this->form_validation->set_rules('edit_c', 'Comments', 'trim|required|xss_clean');	
				
				$sess_userid = $this->session->userdata('adminid');
				$date = date("Y-m-d H:i:s");
				if ($this->form_validation->run() == true)
				{
			
			   $commentde = $this->input->post('edit_c');
                $update_data = array(
					
					'user_cmt'		=> $commentde

				);
					
					
						
						$updatedb = $this->Conference_model->update_records('tbl_comments',$update_data,"cmt_id=$editid");
						if($updatedb)
						{
							

							
							$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Comments edited successfully.</div>');
						}
						else
						{	
							$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> Comments could not edited. Please try again.</div>');
						}
					//}
					//else
					//{
					//	$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> The Email field must contain a unique value.</div>');
				//	}
					
					redirect(base_url().'admin/comments/edit/'.$editid,'refresh');
				}
				else
				{
					//set the flash data error message if there is one
					$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
				}
			}
			$this->load->view('admin/edit_comments', $data);
		}
		else
			redirect(base_url().'admin/comments','refresh');
	}

     public function delete()
	
	{
		
		$delid = $this->uri->segment(4);

	   $noof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","cmt_id='$delid'");
		if($noof_rec>0)
		{
		
            $del = $this->Conference_model->delete_records("tbl_comments", "cmt_id=$delid");
            if ($del)
            {

                $this->session->set_flashdata('message', '<div class="successmsg notification"><i class="fa fa-check"></i> Comment has been deleted successfully.</div>');
            }
            else{
            	//echo 0;
                $this->session->set_flashdata('message', '<div class="errormsg notification"><i class="fa fa-times"></i> Comment could not deleted. Please try again.</div>');
          }
		}
		redirect(base_url().'admin/comments','refresh');
	}




}





