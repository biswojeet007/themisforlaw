<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Activity_details extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Conference_model');
		$this->load->library('pagination');
		if($this->session->userdata('userid') == ''){
			redirect(base_url().'logout','refresh');

		}

	}

	
	public function index()
	{
      
        $data['message'] = $this->session->flashdata('message');
        $userid = $this->session->userdata('userid');
		$noof_rec = $this->Conference_model->noof_records("post_id", "tbl_posts", "user_id='$userid'");

		    $config['base_url'] = base_url().'activity-details/page/';
			$config['first_url'] = base_url().'activity_details';
			$config["uri_segment"] = 3;
			$config['total_rows'] = $noof_rec;
			$config['per_page'] = $this->Conference_model->per_page;
			$config["num_links"] = $this->Conference_model->num_links;
			$config["use_page_numbers"] = TRUE;
			//config for bootstrap pagination class integration
			$config['full_tag_open'] = '<ul class="pagination">';
			$config['full_tag_close'] = '</ul>';
			$config['first_link'] = "&laquo First";
			$config['last_link'] = "Last &raquo";
			$config['first_tag_open'] = '<li  class="page-item ">';
			$config['first_tag_close'] = '</li>';
			$config['prev_link'] = 'Prev';
			$config['prev_tag_open'] = '<li class="page-item">';
			$config['prev_tag_close'] = '</li>';
			$config['next_link'] = 'Next';
			$config['next_tag_open'] = '<li  class="page-item">';
			$config['next_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li  class="page-item">';
			$config['last_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="page-item active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li  class="page-item">';
			$config['num_tag_close'] = '</li>';
			$this->pagination->initialize($config);

			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$per_page = $config["per_page"];
			$startm = $page;
			if($page>1)
			$startm = $page-1;
			$startfrom = $per_page*$startm;
			$data['startfrom'] = $startfrom;


			$data['pagination'] = $this->pagination->create_links();
		$data['row'] = $this->Conference_model->get_records("*","tbl_posts","user_id='$userid'","post_id ASC","$per_page","$startfrom");
		$this->load->view('activity_details',$data);
		
	}


			


}

?>	