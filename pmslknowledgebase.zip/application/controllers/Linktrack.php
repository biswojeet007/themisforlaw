<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Linktrack extends CI_Controller {
	
	public function __construct()
 	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->database();
		$this->load->model('Conference_model');
		$this->load->library('cart');
 	}
	
	public function index()
	{
		$data['message'] = ""; $valid = "";

			if(isset($_REQUEST['pmslknowledgebaseSignupTrackEmail']))
			{
					$request = $_REQUEST['pmslknowledgebaseSignupTrackEmail'];

					if($request) {

						if (preg_match('/__/', $request)) {

								list($ide,$user_email) = explode("__",$request);

								$id = base64_decode($ide);									
								$user_email = base64_decode($user_email);


									$noof_rec = $this->Conference_model->noof_records("user_id","tbl_user","user_email='$user_email' and user_id='$id' and status='0'");
								
										if($noof_rec > 0)
										{
											$valid = 1;
											$updatedata = array('status' => '1');
											$updaterecord = $this->Conference_model->update_records("tbl_user",$updatedata,"user_email='$user_email' and user_id='$id'");
											if($updaterecord) {
												$data['message'] = "success";
											}
											else {
												$data['message'] = "error";
											}
										} 
						}
					}
			}
		
			if($valid == 1)
				$this->load->view('linktrack',$data);
			else
			{			
				$this->output->set_status_header('404');
				$data['pagetitle'] = '404 Page Not Found';
				$this->load->view('404error',$data);
			}

	}
}
