<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url', 'form');
        $this->load->library('session');
        $this->load->helper('security');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
        $this->load->database();
        $this->load->model('Conference_model');
        if ($this->session->userdata('userid') == '') {
            redirect(base_url() . 'logout', 'refresh');
        }
    }

    public function index() {

        $sess_userid = $this->session->userdata('userid');
        $noof_rec = $this->Conference_model->noof_records("user_id", "tbl_user", "user_id='$sess_userid'");
        $data['message'] = $this->session->flashdata('message');
        if (isset($_POST['set_submit']) && !empty($_POST)) {

            $name = $this->form_validation->set_rules('name', 'Profilename', 'trim|required|xss_clean');
            $title = $this->form_validation->set_rules('title', 'Title', 'trim|required|xss_clean');
            $email = $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean|valid_email');
            $description = $this->form_validation->set_rules('description', 'Description', 'trim|required|xss_clean');

            if ($this->form_validation->run() == true) {

                $name = $this->input->post('name');
                $title = $this->input->post('title');
                $email = $this->input->post('email');
                //$editid = $this->input->post('editid');
                //echo $editid;
                $password = $this->input->post('password');
                $description = $this->input->post('description');


                //FILE UPLOADING USING CODEIGNITER START//

                $rimage = $this->Conference_model->showname_fromid("user_pic", "tbl_user", "user_id=$sess_userid");
                if (isset($_FILES) && !empty($_FILES)) {
                    $config['upload_path'] = './assets/images/';
                    $config['allowed_types'] = 'gif|jpg|jpeg|png|bmp';
                    $config['max_size'] = '0';
                    $config['overwrite'] = FALSE;
                    $config['encrypt_name'] = TRUE;

                    $this->load->library('upload', $config);
                    if ($this->upload->do_upload('user_pic')) {
                        $unlinkimage = getcwd() . '/assets/images/' . $rimage;
                        if (file_exists($unlinkimage) && !is_dir($unlinkimage)) {
                            unlink($unlinkimage);
                        }
                        $this->load->library('image_lib');
                        $photo_path = $this->upload->data();
                        $filename = $photo_path['file_name'];
                        //resize:
                        $config['source_image'] = $this->upload->upload_path . $this->upload->file_name;
                        $config['maintain_ratio'] = FALSE;
                        //$config['width'] = 1920;
                        //$config['height'] = 702;
                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                    } else {
                        $filename = $rimage;
                    }
                } else {
                    $filename = $rimage;
                }


                //echo $userPic;
                //die();
                //FILE UPLOADING USING CODEIGNITER END//

                $noof_durc = $this->Conference_model->noof_records("user_id", "tbl_user", "user_email='$email' and user_id!='$sess_userid'");
                $nopass = $this->Conference_model->showname_fromid("password", "tbl_user", "user_id='$sess_userid'");
                if ($noof_durc < 1) {
                    if (empty($password) && $password == "") {
                        //$user_pic = NULL;
                        $update_data = array(
                            'username' => $name,
                            'user_email' => $email,
                            'user_title' => $title,
                            'user_desc' => $description,
                            'user_pic' => $filename
                        );

                        $update_record = $this->Conference_model->update_records("tbl_user", $update_data, "user_id='$sess_userid'");
                    } else if (!empty($password)) {

                        // echo $get_sessu;
                        //die();

                        $new_pwd = $this->input->post('password');

                        $costvalue = $this->Conference_model->costvalue;
                        $options = ['cost' => $costvalue,];
                        $inspwdfrdb = password_hash("$new_pwd", PASSWORD_BCRYPT, $options);

                        $update_datas = array(
                            //'password' 	=>	sha1($new_pwd)
                            'password' => $inspwdfrdb,
                            'user_pic' => $filename
                        );

                        $update_record = $this->Conference_model->update_records('tbl_user', $update_datas, "user_id='$sess_userid'");
                        //UPDATE NEW PSW
                    } else {

                        $update_data = array(
                            'username' => $name,
                            'user_email' => $email,
                            'user_title' => $title,
                            'user_desc' => $description,
                            'user_pic' => $filename
                        );

                        $update_record = $this->Conference_model->update_records("tbl_user", $update_data, "user_id='$sess_userid'");
                    }
                    if ($update_record) {


                        $this->session->set_flashdata('message', '<div class="successmsg notification"><i class="fa fa-check"></i> setting update successfully. </div>');
                    } else {
                        $this->session->set_flashdata('message', '<div class="errormsg notification"><i calss="fa fa-times"></i> setting Could not updated . Please try again. </div>');
                    }
                } else {
                    $this->session->set_flashdata('message', '<div class="errormsg notification"><i class="fa fa-times"></i> The Email ID field must contain a unique value.</div>');
                }

                redirect(base_url() . 'setting');
            } else {
                $data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
            }
        }
        $this->load->view('setting', $data);
    }


    public function deletegalleyimages() {
        $delid = $this->input->post('delid');
        //echo $delid;
        $delimg = $this->input->post('delimg');
        //echo $delimg;
       // die();
        
       // $delnm = $this->input->post('delnm');
        $update_d = array(
                         'user_pic' => NULL
                         );

        if ($this->Conference_model->update_records("tbl_user",$update_d ,"user_id='$delid'")) {
            $delimgs = getcwd() . '/assets/images/' . $delimg;
            if ((file_exists($delimgs)) && (!is_dir($delimgs))) {
                unlink($delimgs);
            }
            echo 'Deleted Successfully';
        } else{
            echo 'Unable to Delete';
        }

        exit();
    }
    

}

?>	