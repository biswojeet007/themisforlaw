<?php
class Search_posts extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url', 'form');
        $this->load->library('session');
        $this->load->helper('security');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
        $this->load->database();  
        $this->load->model('Conference_model');
        $this->load->model('Pagination_model',"pgn");
        
    }

 public function index()
    {   
         
         
        if($this->input->get('search_qa') !="")
        {
            $title = trim($this->input->get('search_qa'));

 
        }
        else{
            $title = str_replace("%20",' ',($this->uri->segment(3))?$this->uri->segment(3):0);
        } 
        
        $data['search_title']=$title;        
         
        $allrecord = $this->pgn->allrecord($title);
        $baseurl =  base_url().$this->router->class.'/'.$this->router->method."/".$title;
        
        $paging=array();
        $paging['base_url'] =$baseurl;
        $paging['total_rows'] = $allrecord;
        $paging['per_page'] = 3;
        $paging['uri_segment']= 4;
        $paging['num_links'] = 5;
        $paging['first_link'] = 'First';
        $paging['first_tag_open'] = '<li>';
        $paging['first_tag_close'] = '</li>';
        $paging['num_tag_open'] = '<li>';
        $paging['num_tag_close'] = '</li>';
        $paging['prev_link'] = 'Prev';
        $paging['prev_tag_open'] = '<li>';
        $paging['prev_tag_close'] = '</li>';
        $paging['next_link'] = 'Next';
        $paging['next_tag_open'] = '<li>';
        $paging['next_tag_close'] = '</li>';
        $paging['last_link'] = 'Last';
        $paging['last_tag_open'] = '<li>';
        $paging['last_tag_close'] = '</li>';
        $paging['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
        $paging['cur_tag_close'] = '</a></li>';
        
        $this->pagination->initialize($paging);    
        
        $data['limit'] = $paging['per_page'];
        $data['number_page'] = $paging['per_page']; 
        $data['offset'] = ($this->uri->segment(4)) ? $this->uri->segment(4):'0';    
        $data['nav'] = $this->pagination->create_links();
        $data['datas'] = $this->pgn->data_list($data['limit'],$data['offset'],$title);
        $data['title'] = $title;

        $this->load->view('search_posts',$data);
    }
  

} 



