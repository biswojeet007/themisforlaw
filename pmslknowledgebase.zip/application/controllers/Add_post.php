<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add_post extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Conference_model');
		if($this->session->userdata('userid') == ''){
			redirect(base_url().'logout','refresh');

		}
		
		
	}

	
	public function index()
	{
		$data['message'] = $this->session->flashdata('message');
		if(isset($_POST['post_submit']) && !empty($_POST)){

			$post_title = $this->form_validation->set_rules('post_title','Title', 'trim|required|xss_clean');
			$post_cat = $this->form_validation->set_rules('selected_topics', 'Tags','trim|required|xss_clean');
			$post_desc = $this->form_validation->set_rules('post_desc','Description','trim|required|xss_clean');
             
            $date = date("Y-m-d H:i:s");
			if($this->form_validation->run() == true){

               $post_title = $this->input->post('post_title');
               $post_desc = $this->input->post('post_desc');
               $sess_userid = $this->session->userdata('userid');


               $insert_data = array(
                               'post_title' => $post_title,
                               'post_desc' => $post_desc,
                               'status' => 0,
                               'posted_date' => $date,
                               'user_id' => $sess_userid
                                
                                );
               $insertdb = $this->Conference_model->insert_records("tbl_posts",$insert_data);
               if($insertdb){
                   
                $postid = $this->db->insert_id();
                $uid = $this->session->userdata('userid');
                $post_tags = $this->input->post('selected_topics');
                //print_r($post_tags);
                //die();
                //exit();
                $postdate = date("Y-m-d H:i:s");
                //multiple id insert query start
            if (($post_tags != '')) {
			//Add Topics
					$selected_topicsArr = explode(',', $post_tags);
					$counttopics = count($selected_topicsArr);
					$insert_rec = NULL;
					for($i=0; $i<$counttopics; $i++)
					{
						$valtopic = $selected_topicsArr[$i];
						//$valtopicid = $this->Common_model->showname_fromid("topicid","tbl_topics","topic='$valtopic' and topic_type='1' and status='1'");
						$valtopicid = $valtopic;
						$query_datachild = array(
							'post_id'	=> $postid,
							'tag_id'		=> $valtopicid,
							'created_date'	=> $postdate
							
						);
						$insert_rec = $this->Conference_model->insert_records("tbl_post_tags", $query_datachild);
					}

		 }	


                //multiple id insert query end
                 /*foreach($post_tags as $postag){

                       $ins_data = array(
			                       'post_id' => $postid,
			                       'tag_id' => $postag,
			                       'created_date' => $postdate
			                           );

                      //print_r($postag);
                       //die();
                       //exit();

                       $insert_tags = $this->Conference_model->insert_records("tbl_user_tags",$ins_data);
                       
                  }*/
 

                   $this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Post added Successfully. </div>');
               }else{

               	$this->session->set_flashdata('message','<div class="errormsg notification"><i calss="fa fa-times"></i> Post Could not added . Please try again. </div>');
               }

               redirect(base_url().'add-post','refresh');
		  }else
			{
				//set the flash data error message if there is one
				$data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
			}
		
	   }
     $this->load->view('add_post',$data);
   }
  
	// ADDITION NEW TAG START


   //Popup Section
	

	//END1

	
	
	 public function addnewtag()
       {

       $ntag = $this->input->post('newtag');
	   $rec_check = $this->Conference_model->noof_records("tag_id","tbl_tags","tag_name='$ntag'");
		
	  if($rec_check>0){
             echo 1;
		    }else{
  
		       $tag_date = date("Y-m-d H:i:s");
		       $insert_tdata = array(
			                      'tag_name' => $ntag,
				                  'status' => 1,
				                  'tag_date' => $tag_date
			                       );
	           $insert_ntag = $this->Conference_model->insert_records("tbl_tags",$insert_tdata);
		      echo 2;
	
	          }
		   	   
	   

   } 
	
	//ADDITION NEW TAG END
      



}

?>	