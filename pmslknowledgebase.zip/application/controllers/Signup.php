<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Conference_model');
	}

	public function index(){

		$data['message'] = $this->session->flashdata('message');
		if(isset($_POST['signup_btn']) && !empty($_POST)){
           
           $this->form_validation->set_rules('username','Username','trim|required|xss_clean');
           $this->form_validation->set_rules('user_email','Email','trim|required|xss_clean|valid_email|is_unique[tbl_user.user_email]');
           $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]|max_length[12]');

           $date = date('Y-m-d H:i:s');

           if($this->form_validation->run() == true){

           	$user_email = $this->input->post('user_email');
           	$username = $this->input->post('username');
           	$password = $this->input->post('password');
           	$costvalue = $this->Conference_model->costvalue;
            $options = ['cost' => $costvalue];
            $inspwdfrdb=password_hash("$password", PASSWORD_BCRYPT, $options);

           	$insert_data = array(
                                
                               'user_email' => $user_email,
                               'username'   => $username,
                                'password' => $inspwdfrdb,
                                'status'  =>0,
                                'created_date' => $date

           	                     );

           	$insertdb = $this->Conference_model->insert_records("tbl_user",$insert_data);

           	if($insertdb){

                 $unicuserid = $this->db->insert_id();
                    /* Signup user - Send Email */                            

                      $link = base_url().'linktrack?pmslknowledgebaseSignupTrackEmail=' . base64_encode($unicuserid) . '__' . base64_encode($user_email);
                      $subjecto = "Verify Your Email Address";
                      $messages = "<!doctype html>
                      <html>
                      <head>
                        <meta charset='utf-8'>
                      </head>
                      <body style='font-family:sans-serif;font-size:13px; line-height:22px;'>
                      <div style='width: 100%;background:#F5F5F5;color: #000;'> 
                      <div style='padding:30px 30px 60px 30px;'>       
                        <div style='text-align:center'><a href='".base_url()."'><img src='".base_url()."assets/images/logo.png' style='margin:auto; margin-top:12px; margin-bottom:12px'></a>
                        </div>
                                            
                       <div style='background-color:#FFF;border:#EAEAEA 1px solid; padding:15px;'>

                        <p style='margin-top:30px; line-height: 31px;'>
                          Hi $username, <br>
                          Thank you for joining PMSLKNOWLEDGEBASE. <br>

                          You're receiving this email as a registered user of Pmslknowledgebase. <br>

                          Before you can be given access to the website we need to verify your registration. <br>
                          To finish signing up, please confirm your email address $user_email <br>

                          <b>Your Email :</b>  $user_email <br>

                          <div style='clear:both'></div>
                          <div style='text-align:center; margin-top:12px; '>
                            <a href='$link' style='display:inline-block; background-color:#b84a6b;color:#fff; padding:8px 22px; text-decoration:none !important;' target='_blank'>Confirm email address</a>
                          </div>
                          <div style='clear:both'></div>
                        </p>
                       </div>
                        <div style='background-color:#FFF;border:#EAEAEA 1px solid; text-align:center; margin-top:12px; padding-top:30px; padding-bottom:10px'>
                        Button not working? Use the link below: <br>
                        <a href='$link' style='text-decoration:none !important;'>$link</a>                                  
                        </div>

                        </div>        
                      </div>

                      </body>";

                      /** Start - Sending Mail **/
                      $mailconfig = Array(
                        'mailtype' => 'html',
                        'charset' => 'iso-8859-1',
                        'wordwrap' => TRUE,
                        'newline'=>'\n',
                        'crlf'=>'\n'
                      );
                      
                      $company_mail = $this->Conference_model->company_mail_id;
                      $from_mail = $this->Conference_model->from_mail_id;                             

                      $this->load->library('email', $mailconfig);
                      //Send Mail To User
                      $this->email->clear();
                      $this->email->from($from_mail, "Pmslknowledgebase");
                      $this->email->to($user_email);
                      $this->email->reply_to($company_mail, 'Pmslknowledgebase');
                      $this->email->subject($subjecto);
                      $this->email->message($messages);
                      $this->email->send();
                      //echo $messages ;
                      
                      /** End - Send Mail **/
                      $this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> Please check your registered email id, we have sent you Verification Link to Activate Your Account..</div>');

           		//$this->session->set_flashdata('message','<div class="successmsg notification"><i class="fa fa-check"></i> You have successfully Registered.</div>');

           	}else{
           		$this->session->set_flashdata('message','<div class="errormsg notification"><i class="fa fa-times"></i> User could not added. Please try again.</div>');
           	}
            
            redirect(base_url().'signup','refresh');
         
           }
          $data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message')); 

		}

		$this->load->view('signup',$data);
	}
}

?>