<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Conference_model');
		$this->load->library('pagination');
	}

	
	public function index()
	{
		$data['message'] = $this->session->flashdata('message');
		$userid = $this->session->userdata('userid');
		$noof_rec = $this->Conference_model->noof_records("post_id", "tbl_posts", "status='1'");
		 $config['base_url'] = base_url().'home/page/';
			$config['first_url'] = base_url();
			$config["uri_segment"] = 3;
			$config['total_rows'] = $noof_rec;
			$config['per_page'] = $this->Conference_model->per_page;
			$config["num_links"] = $this->Conference_model->num_links;
			$config["use_page_numbers"] = TRUE;
			//config for bootstrap pagination class integration
			$config['full_tag_open'] = '<ul class="pagination">';
			$config['full_tag_close'] = '</ul>';
			$config['first_link'] = "&laquo First";
			$config['last_link'] = "Last &raquo";
			$config['first_tag_open'] = '<li  class="page-item ">';
			$config['first_tag_close'] = '</li>';
			$config['prev_link'] = 'Prev';
			$config['prev_tag_open'] = '<li class="page-item">';
			$config['prev_tag_close'] = '</li>';
			$config['next_link'] = 'Next';
			$config['next_tag_open'] = '<li  class="page-item">';
			$config['next_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li  class="page-item">';
			$config['last_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="page-item active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li  class="page-item">';
			$config['num_tag_close'] = '</li>';
			$this->pagination->initialize($config);

			$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
			$per_page = $config["per_page"];
			$startm = $page;
			if($page>1)
			$startm = $page-1;
			$startfrom = $per_page*$startm;
			$data['startfrom'] = $startfrom;


			$data['pagination'] = $this->pagination->create_links();
			$data['rowdk'] = $this->Conference_model->get_records("*","tbl_posts","status='1'","post_id DESC","$per_page","$startfrom");

		$this->load->view('home',$data);
	}

	public function post()
	{
        $data['message'] = $this->session->flashdata('message');
        $sess_userid = $this->session->userdata('userid');
        $sig_id = $this->uri->segment(3);
		$pos_uri = base64_decode($sig_id);
		$this->load->helper('cookie');
		$eventid = 'PMSL'.$pos_uri;
		//$var = time() + (60 * 20);

        if (get_cookie($eventid) == "") {
            // set cookie 
            $cookie = array(
                'name' => "$eventid",
                'value' => 'exist',
                'expire' =>  86400,
                'secure' => false
            );

            set_cookie($cookie);

            $get_viewers = $this->Conference_model->showname_fromid("noof_views", "tbl_posts", "post_id='$pos_uri'");
            $noof_views = array(
                'noof_views' => $get_viewers + 1
            );
            $this->Conference_model->update_records("tbl_posts", $noof_views, "post_id='$pos_uri'");
        }
      
     
    

		$noof_rec = $this->Conference_model->noof_records("post_id","tbl_posts","post_id='$pos_uri'");
		if($noof_rec>0)
		{
			$data['row'] = $this->Conference_model->get_records("*","tbl_posts","post_id=$pos_uri","");
			$data['delrow'] = $this->Conference_model->get_records("post_id","tbl_posts","user_id=$sess_userid","");
			$data['delr'] = $this->Conference_model->get_records("user_id","tbl_posts","post_id=$pos_uri","");
			$data['delrcm'] = $this->Conference_model->get_records("user_id","tbl_comments","post_id=$pos_uri and user_id=$sess_userid","");
			$this->load->view('single', $data);
		}
		else{

			redirect(base_url(),'refresh');
		}
	}


		public function chat_with_us()
		{
		$conemail = $this->input->post('conemail');
		$project = $this->input->post('project');
		$current_full_url = $this->input->post('current_full_url');
		$to = "biswojeet.pmsl@gmail.com";
		$from = "alerts@conferencealert.com";
		$subject = 'Chat Support Inquiry';
		if(empty($project)) {
		$subject = 'Quick question - ConferenceAlert Service Info'; // for SEO Setup Inquiry
		}

		if (($conemail != '') ) { //&& ($project != '')
		$message = "<!doctype html>
		<html>
		<head>
		<meta charset='utf-8'>
		</head>
		<body>

		<p>
		<div style='line-height:25px;font-size:14px'>";
		if(!empty($project)) { // for SEO Setup Inquiry
		$message .= "<div><strong>Project : </strong>$project</div>";
		}
		$message .= "<div><strong>Message : </strong>$conemail</div>";
		/*if(!empty($current_full_url)) {
		$message .= "<div><strong>From URL : </strong>$current_full_url</div>";
		}*/
		$message .= "</div>
		</p>

		</body>
		</html>";

		/* Start - Sending Mail */
		$mailconfig = Array(
		'mailtype' => 'html',
		'charset' => 'iso-8859-1',
		'wordwrap' => TRUE,
		'newline'=>'\n',
		'crlf'=>'\n'
		);

		$this->load->library('email', $mailconfig);
		//Send Mail To Admin
		$this->email->from("alerts@conferencealert.com", "Aston from ConfrenceAlert");
		$this->email->to($to);
		$this->email->cc("biswojeet.pmsl@gmail.com");
		$this->email->reply_to($conemail);
		$this->email->subject($subject);
		$this->email->message($message);
		$this->email->send();
		/* End - Send Mail */
		echo "success";
		}
		else
		{
		echo 'error';
		}
		exit();
		}


      public function comments()
      {

       $user_cmt = $this->input->post('user_cmt');
       $pos_id = $this->input->post('pos_id');
       $us_id = $this->input->post('us_id');
       $comm_date = date("Y-m-d H:i:s");

	   $insert_cdata = array(
			           'user_cmt' => $user_cmt,
			           'user_id' => $us_id,
			           'post_id' => $pos_id,
			           'status' => 1,
				       'commented_date' => $comm_date
				       
			                       );
	     $insert_cmt = $this->Conference_model->insert_records("tbl_comments",$insert_cdata);

         if($insert_cmt){
             echo 1;
         }else{
              echo 0;
         }
           


		     
    } 


    public function check_login()
	{
		$email = $this->input->post('username');
		
		$password = $this->input->post('password');
		
		
		//$pwd = sha1($password);
		$hasingpwd=$this->Conference_model->showname_fromid("password","tbl_user","user_email='$email' and status=1");
		
		$checkdb = $this->Conference_model->get_records("user_id, username, user_email","tbl_user","user_email='$email' and status=1","","1");
		if(password_verify("$password", $hasingpwd))
		{
			$sess_array = array();
			foreach($checkdb as $row)
			{
				$userid = $row['user_id'];
				$username = $row['username'];
				$email_id = $row['user_email'];

			}
			
			$sess_array = array(
				'userid' => $userid,
				'username' => $username,
				'useremail' => $email_id,
				'sess_id' => session_id()
			);
			$this->session->set_userdata($sess_array);
			echo 1;
		}
		else
		{
			echo 0;
		}
		exit();
	}


//VOTING S START
public function likedislikesave()
	{
		$jobid = $_REQUEST['jobid'];
		$employeeid = $_REQUEST['employeeid'];
		$activity = $_REQUEST['activity'];
		//echo $jobid.''.$employeeid.''.$activity;

		if($activity==1)
		{
			$noof_rec = $this->Conference_model->noof_records("voting_id","tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting	='1'");
		}
		else if($activity==2)
		{
			$noof_rec = $this->Conference_model->noof_records("voting_id","tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting	='2'");
		}
		
		if($noof_rec<=0)
		{
			$date = date("Y-m-d H:i:s");
			if ($employeeid != '')
			{
				$query_data = array(
					'vuserid'			=> $employeeid,
					'vpost_id'					=> $jobid,
					'voting'				=> $activity,
					'created_date'			=> $date,
					'created_by'			=> $employeeid
				);

				$insert_rec = $this->Conference_model->insert_records("tbl_post_voting", $query_data); 
				
				if($activity==1)
				{
				
				$delkdslk = $this->Conference_model->delete_records("tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting='2'");
					

				}else{
                 $delkdslk = $this->Conference_model->delete_records("tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting='1'");
				}
				$echo_msg = "new$activity";
				
			}
		}
		else if($activity==1 || $activity==2)
		{
			$delkdslk = $this->Conference_model->delete_records("tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting='$activity'");
			$echo_msg = "updt$activity";
		}
		
		echo $echo_msg;
		exit();
	}
//VOTING S END	


}

?>	