<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Activity extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Conference_model');
		$this->load->library('pagination');
		if($this->session->userdata('userid') == ''){
			redirect(base_url().'logout','refresh');

		}

	}

	
	public function index()
	{
      
        $data['message'] = $this->session->flashdata('message');
        $userid = $this->session->userdata('userid');
		
		    $data['row'] = $this->Conference_model->get_records("*","tbl_posts","user_id='$userid'","post_id DESC","10","");
		    $this->load->view('activity',$data);
		
	}


	public function post()
	{

    $sig_id = $this->uri->segment(3);
		$pos_uri = base64_decode($sig_id);
		$this->load->helper('cookie');
		$eventid = 'PMSL'.$pos_uri;
		//$var = time() + (60 * 20);

        if (get_cookie($eventid) == "") {
            // set cookie 
            $cookie = array(
                'name' => "$eventid",
                'value' => 'exist',
                'expire' =>  86400,
                'secure' => false
            );

            set_cookie($cookie);

            $get_viewers = $this->Conference_model->showname_fromid("noof_views", "tbl_posts", "post_id='$pos_uri'");
            $noof_views = array(
                'noof_views' => $get_viewers + 1
            );
            $this->Conference_model->update_records("tbl_posts", $noof_views, "post_id='$pos_uri'");
        }
      
     
    

		$noof_rec = $this->Conference_model->noof_records("post_id","tbl_posts","post_id='$pos_uri'");
		if($noof_rec>0)
		{
			$data['row'] = $this->Conference_model->get_records("*","tbl_posts","post_id=$pos_uri","");
			$this->load->view('single', $data);
		}
		else{

			redirect(base_url().'activity','refresh');
		}
	}


	 public function comments()
      {

       $user_cmt = $this->input->post('user_cmt');
       $pos_id = $this->input->post('pos_id');
       $us_id = $this->input->post('us_id');
       $comm_date = date("Y-m-d H:i:s");

	   $insert_cdata = array(
			           'user_cmt' => $user_cmt,
			           'user_id' => $us_id,
			           'post_id' => $pos_id,
			           'status' => 1,
				       'commented_date' => $comm_date
				       
			                       );
	     $insert_cmt = $this->Conference_model->insert_records("tbl_comments",$insert_cdata);

         if($insert_cmt){
             echo 1;
         }else{
              echo 0;
         }
           


		     
    } 


  public function commtdel()
	
	{
		
	  $delid = $this->uri->segment(3);
	  $delidsre = $this->uri->segment(4);
	

	  $noof_rec = $this->Conference_model->noof_records("cmt_id","tbl_comments","cmt_id='$delid'");
		if($noof_rec>0)
		{
		
            $del = $this->Conference_model->delete_records("tbl_comments", "cmt_id=$delid");
            if ($del)
            {

                $this->session->set_flashdata('message', '<div class="successmsg notification"><i class="fa fa-check"></i> Comment has been deleted successfully.</div>');
            }
            else{
            	
                $this->session->set_flashdata('message', '<div class="errormsg notification"><i class="fa fa-times"></i> Comment could not deleted. Please try again.</div>');
          }
		}
		redirect(base_url().'home/post/'.$delidsre,'refresh');
	}


	//POSTS DELETION START
  public function posttdel()
	
	{
		
	  $postdelid = $this->uri->segment(3);

	  $noof_rec = $this->Conference_model->noof_records("post_id","tbl_posts","post_id='$postdelid'");
		if($noof_rec>0)
		{
			$noof_comm = $this->Conference_model->noof_records("post_id","tbl_comments","post_id='$postdelid'");
			if($noof_comm>0){
				 $this->session->set_flashdata('message', '<div class="errormsg notification"><i class="fa fa-times"></i> Post Could not be deleted. Comment May be added to this post.</div>');
			}else{
				$del = $this->Conference_model->delete_records("tbl_posts", "post_id=$postdelid");
				$del = $this->Conference_model->delete_records("tbl_post_tags", "post_id=$postdelid");
        $del = $this->Conference_model->delete_records("tbl_post_voting", "vpost_id=$postdelid");
			
		
            if ($del)
            {
               $this->session->set_flashdata('message', '<div class="successmsg notification"><i class="fa fa-check"></i> Post has been deleted successfully.</div>');
            }
            else
            	
                $this->session->set_flashdata('message', '<div class="errormsg notification"><i class="fa fa-times"></i> Post could not deleted. Please try again.</div>');

          }
		}
		redirect(base_url().'activity','refresh');
	}
	//POST DELETION END


    

	//EDIT MODAL COMMENTS START
  public function view_pop()
	{
		$viewid = $this->uri->segment(3);
		$rows1 = $this->Conference_model->get_records("*","tbl_comments","cmt_id='$viewid'","","","");
		if( !empty($rows1) )
		 {
		foreach ($rows1 as $rowss1)
		 {
		$nwecmtname = $rowss1['user_cmt'];
											
		}
	   }
       
       ?>
		<div class="modal-header pupop-sec">
                        <h4 class="modal-title">Comment Details</h4>
                        <button type="button" class="close modal-close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="pupop-view">
                            <div class="row">


                                <div class="col-xl-12 col-lg-12"> 
                              
                            <form class="eventf" method="post" name="form_edit" id="form_edit">
                  <?php $org_cmt =  $this->Conference_model->showname_fromid("user_cmt","tbl_comments","cmt_id='$viewid'") ?>
                                         <div id="msg"></div>
                                     
                                            
                                            <div class="form-group">
                                                <label>Comment Edit</label>
                                                	<textarea class="form-control" id="cmt_editsd" name="cmt_editsd" rows="3" columns="2"><?php echo $org_cmt;?></textarea> 
                                            </div>
                                            <div id="cmt_errors"></div>


                                
                               <div class="reset-button">
                               	<input type="hidden" name="cmid" id="cmid" value="<?php echo $viewid; ?>" />
                                <button type="submit" class="btn btn-primary float-right" name="btnUpdate" id="btnUpdate">Submit</button>
                            </div>

                             </form>
                            </div>
                        </div>

                    </div>
                    <script type="text/javascript">
                    jQuery("#form_edit").validate({
                       rules: {            
                         cmt_editsd: {
                        required: true
               
                           }

                        },
                       messages:{
                     cmt_editsd: {
                      required:"Enter Comments."
                
                      }
                    },

               errorPlacement: function (error, element)
                {
               if (element.attr("name") === "cmt_edit" )
                 error.appendTo("#cmt_errors");
                //else if (element.attr("name") === "password" )
                 //error.appendTo("#password_error");
               else
                 error.insertAfter(element);
                  }
                 });
                </script>
                    <script type="text/javascript">
                     $(document).on('submit', '#form_edit', function(){ 
              			jQuery('#filter_event').html('<div style="text-align:center;margin-top:150px;margin-bottom:100px;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-3x"></i> <span>Processing...</span></div>');
                         $.ajax({
                             url: "<?php echo base_url(); ?>activity/user_comment",
                             type: 'post',                           
                             data: $('#form_edit').serialize(),
         
                             success: function (data) {
                                 jQuery('#msg').html(data);  
                                  //jQuery('#myMod').fadeOut(6000); 
                                 
                                location.reload();                           
                             },
                             error: function (XMLHttpRequest, textStatus, errorThrown) {
                                 alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
                             }
                         }); 
                         return false;              
               }); 
                    	
                    </script>
	<?php
		
		
	}

	//EDIT MODAL COMMENTS END

public function user_comment()
	{
		

				$viewid = $this->input->post('cmid');
				$usercs = $this->input->post('cmt_editsd');
				
				$query_data = array(
					'user_cmt'	=> $usercs

				);
				
				$querydb = $this->Conference_model->update_records('tbl_comments', $query_data, "cmt_id='$viewid'");
				if($querydb)
				{

				echo '<div class="successmsg notification"><i class="fa fa-check"></i> Comment Edited successfully.</div>';
					
				} else {

				echo '<div class="successmsg notification"><i class="fa fa-check"></i> Comment Couldnt be Edited.</div>';
					
					}

					exit;
				}



	//SECTION START FOR QUESTION OR POST EDITSS//
				//EDIT MODAL COMMENTS START
  public function post_pop()
	{
		$poviewid = $this->uri->segment(3);
		$prows = $this->Conference_model->get_records("*","tbl_posts","post_id='$poviewid'","","","");
		if( !empty($prows) )
		 {
		foreach ($prows as $prowss1)
		 {
		$nweposname = $prowss1['post_title'];
    $post_descssd = $prowss1['post_desc'];
											
		}
	   }
       
       ?>
		<div class="modal-header pupop-sec">
                        <h4 class="modal-title">Post Details</h4>
                        <button type="button" class="close modal-close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="pupop-view">
                            <div class="row">


                                <div class="col-xl-12 col-lg-12"> 
                              
                            <form class="eventf" method="post" name="postform_edit" id="postform_edit">
                  <?php 
                  $org_postss =  $this->Conference_model->showname_fromid("post_title","tbl_posts","post_id='$poviewid'");
                  $org_postdesc =  $this->Conference_model->showname_fromid("post_desc","tbl_posts","post_id='$poviewid'");
                  ?>
                                         <div id="msg"></div>
                                     


                                             <div class="form-group">
                                                <label>Post Title</label>
                                                 
               <input type="text" name="postitl" class="form-control"  value="<?php echo $org_postss;?>">         
                                                
                                            </div>
                                            <div id="post_titleerr"></div>
                                           
                                           <div class="clearfix"></div>
                                            
                                            <div class="form-group">
                                                <label>Post Description</label>
                                                	<textarea class="form-control" id="post_editsd" name="post_editsd" rows="3" columns="2"><?php echo $org_postdesc;?></textarea> 
                                                  <div id="chkediter"></div>
                                            </div>
                                            <div id="post_errors"></div>


                                
                               <div class="reset-button">
                               	<input type="hidden" name="uposid" id="uposid" value="<?php echo $poviewid; ?>" />
                                <button type="submit" class="btn btn-primary float-right" name="btnUpdate" id="btnUpdate">Submit</button>
                            </div>

                             </form>
                            </div>
                        </div>

                    </div>
                    <script src="<?php echo base_url(); ?>assets/admin/ckeditor/ckeditor.js" type="text/javascript"></script>
        <script>var base_url = "<?php echo base_url(); ?>"; </script>
        
        <script type="text/javascript">
         CKEDITOR.replace( 'post_editsd');
         </script>
                    <script type="text/javascript">
                    jQuery("#postform_edit").validate({
                      ignore: [],
                       rules: {

                       postitl: {
                           required: true
        
                          },          
                         post_editsd: {
                  required: function()
                           {
                       CKEDITOR.instances.post_editsd.updateElement();
                         }
                        },

                        },
                       messages:{
                        postitl:{
                           required: "Enter Post Title"
        
                          },
                      post_editsd: {
                          required: "Enter Question."
                         }
                    },
               errorPlacement: function (error, element)
                {
               if (element.attr("name") === "post_editsd" )
                 error.appendTo("#chkediter");
               else if (element.attr("name") === "postitl" )
                 error.appendTo("#post_titleerr");
               else
                 error.insertAfter(element);
                  }
                 });
                </script>
                    <script type="text/javascript">
                     $(document).on('submit', '#postform_edit', function(){ 
              			jQuery('#filter_event').html('<div style="text-align:center;margin-top:150px;margin-bottom:100px;color:#377b9e;"><i class="fa fa-spinner fa-spin fa-3x"></i> <span>Processing...</span></div>');
                         $.ajax({
                             url: "<?php echo base_url(); ?>activity/user_posts",
                             type: 'post',                           
                             data: $('#postform_edit').serialize(),
         
                             success: function (data) {
                                 jQuery('#msg').html(data);  
                                  //jQuery('#myMod').fadeOut(6000); 
                                 
                                location.reload();                           
                             },
                             error: function (XMLHttpRequest, textStatus, errorThrown) {
                                 alert("Status: " + textStatus + "\n" + "Error: " + errorThrown);
                             }
                         }); 
                         return false;              
               }); 
                    	
                    </script>
	<?php
		
		
	}

	//EDIT MODAL COMMENTS END

public function user_posts()
	{
		

				$viewidpos = $this->input->post('uposid');
        $usertitle = $this->input->post('postitl');
				$usercspos = $this->input->post('post_editsd');

				
				$query_datasp = array(
					'post_title'	=> $usertitle,
          'post_desc'   => $usercspos

				);
				
				$querydbpo = $this->Conference_model->update_records('tbl_posts', $query_datasp, "post_id='$viewidpos'");
				if($querydbpo)
				{

				echo '<div class="successmsg notification"><i class="fa fa-check"></i> Post Edited successfully.</div>';
					
				} else {

				echo '<div class="successmsg notification"><i class="fa fa-check"></i> Post Couldnt be Edited.</div>';
					
					}

					exit;
				}
	
	//SECTION START FOR QUESTION OR POST EDITSS//			

//VOTING S START
public function likedislikesave()
	{
		$jobid = $_REQUEST['jobid'];
		$employeeid = $_REQUEST['employeeid'];
		$activity = $_REQUEST['activity'];
		//echo $jobid.''.$employeeid.''.$activity;

		if($activity==1)
		{
			$noof_rec = $this->Conference_model->noof_records("voting_id","tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting	='1'");
		}
		else if($activity==2)
		{
			$noof_rec = $this->Conference_model->noof_records("voting_id","tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting	='2'");
		}
		
		if($noof_rec<=0)
		{
			$date = date("Y-m-d H:i:s");
			if ($employeeid != '')
			{
				$query_data = array(
					'vuserid'			=> $employeeid,
					'vpost_id'					=> $jobid,
					'voting'				=> $activity,
					'created_date'			=> $date,
					'created_by'			=> $employeeid
				);

				$insert_rec = $this->Conference_model->insert_records("tbl_post_voting", $query_data); 
				
				if($activity==1)
				{
				
				$delkdslk = $this->Conference_model->delete_records("tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting='2'");
					

				}else{
                 $delkdslk = $this->Conference_model->delete_records("tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting='1'");
				}
				$echo_msg = "new$activity";
				
			}
		}
		else if($activity==1 || $activity==2)
		{
			$delkdslk = $this->Conference_model->delete_records("tbl_post_voting","vuserid='$employeeid' and vpost_id='$jobid' and voting='$activity'");
			$echo_msg = "updt$activity";
		}
		
		echo $echo_msg;
		exit();
	}
//VOTING S END				


}

?>	