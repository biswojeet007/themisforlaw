<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Signin extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Conference_model');
	}

	public function index(){
        $data['message'] = $this->session->flashdata('message');
        
        if (isset($_POST['btnSignin']) && !empty($_POST)) {
            $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            if ($this->form_validation->run() == true) {
                $email         = $this->input->post('email');
                $password      = $this->input->post('password');
                $rec_email     = $this->Conference_model->noof_records("user_id", "tbl_user", "user_email='$email'");
                $rec_email_new = $this->Conference_model->noof_records("user_id", "tbl_user", "user_email='$email' and status='0'");
                
                if ($rec_email > 0) {
                    $hasingpwd = $this->Conference_model->showname_fromid("password", "tbl_user", "user_email='$email' and  status='1'");
                    if (password_verify("$password", $hasingpwd)) {
                        $checkdb    = $this->Conference_model->get_records("user_id, username, user_email", "tbl_user", "user_email='$email' and status='1' ", "", "1");
                        $sess_array = array();
                        foreach ($checkdb as $row) {
                            $user_id       = $row['user_id'];
                            $organisername = $row['username'];
                            $email_id      = $row['user_email'];
                        }
                        $sess_array = array(
                            'userid' => $user_id,
                            'username' => $organisername,
                            'useremail' => $email_id,
                            'sess_id' => session_id()
                        );
                        $this->session->set_userdata($sess_array);
                       redirect(base_url().'add-post','refresh');
                    } else if ($rec_email_new > 0) {
                        $data['message'] = '<div class="errormsg notification"><i class="fa fa-times"></i> Your email is not verified. Please check your mail to verify your email </div>';
                    } else {
                        $data['message'] = '<div class="errormsg notification"><i class="fa fa-times"></i> Invalid Login. Please try again.</div>';
                    }
                } else {
                    $data['message'] = '<div class="errormsg notification"><i class="fa fa-times"></i> Sorry, your email is not recognised</div>';
                }
            } else {
                $data['message'] = (validation_errors() ? validation_errors() : $this->session->flashdata('message'));
            }
        }
        
        $this->load->view('signin', $data);
        
    }
	//Forgott Email Start//

        public function forgot_email()
         {
        $email = $this->input->post('forgotemail');
        $numuserqryinactive = $this->Conference_model->noof_records("user_id", "tbl_user", "user_email='$email' and status = '0' ");
        $numuseractive      = $this->Conference_model->noof_records("user_id", "tbl_user", "user_email='$email' and status= '1' ");
        if ($numuseractive > 0) {
            $row = $this->Conference_model->get_records("*", "tbl_user", "user_email='$email' and status= '1'", "");
            foreach ($row as $rows) {
                $getuserid     = $rows['user_id'];
                $get_user_name = $rows['username'];
            }
            
            $getlink_id    = $this->getGUID();
            $getenclink_id = hash('sha1', $getlink_id);
            $curdatetime   = strtotime("now");
            $expdatetime   = strtotime('+1 day');
            
            $updatedata   = array(
                'temp_password' => $getenclink_id,
                'pwd_created' => $curdatetime
            );
            $updaterecord = $this->Conference_model->update_records("tbl_user", $updatedata, "user_id=$getuserid");
            
            $linktomail = base_url() . 'forgot_password?id=' . $getlink_id;
            if ($updaterecord) {
                $company_mail = $this->Conference_model->company_mail_id;
                /** Start - Sending Mail **/
                $mailconfig   = Array(
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1',
                    'wordwrap' => TRUE,
                    'newline' => '\n',
                    'crlf' => '\n'
                );
                
                $mailcontent = "<!doctype html>
                                            <html>
                                            <head>
                                                <meta charset='utf-8'>
                                            </head>
                                            <body style='font-family:sans-serif;font-size:13px; line-height:22px;'>
                                            <div style='width: 100%;background:#F5F5F5;color: #000;'> 
                                            <div style='padding:30px 30px 60px 30px;'>       
                                              <div style='text-align:center'><a href='" . base_url() . "'><img src='" . base_url() . "assets/images/logo.png' style='margin:auto; margin-top:12px; margin-bottom:12px'></a>
                                              </div>

                                             <div style='background-color:#FFF;border:#EAEAEA 1px solid; padding:15px;'>
                                                <p style='margin-top:30px; line-height: 31px;'>
                                                    Hi $get_user_name, <br>
                                                     Recently a request was submitted to reset your password. If you did not request this, please ignore this email. It will expire and become useless in 24 hours time.<br><br>
                        
                                                            To reset your password, please visit the url below:<br>
                                                            <a style='color:#003580' href='$linktomail'>$linktomail</a><br>
                                                            When you visit the link above, you will have the opportunity to choose a new password.
                                                </p>
                                                            <div style='line-height:25px; margin-top:20px'>
                                                                <div>Sincerely,</div>
                                                                <div>PmslKnowledgebase</div>
                                                            </div>
                                             </div>
                                            </body>";
                
                //echo $mailcontent;
                $subject   = "PmslKnowledgebase password Reset";
                $from_mail = $this->Conference_model->from_mail_id;
                
                $this->load->library('email', $mailconfig);
                $this->email->from($from_mail, "PmslKnowledgebase");
                $this->email->to($email);
                $this->email->subject($subject);
                $this->email->message($mailcontent);
                $this->email->send();
                /** End - Send Mail **/
                //echo $mailcontent;
                echo 1;
                 //echo "one" ;
                //echo "<div class='successmsg notification'><i class='fa fa-check'></i> A link has been sent to your Email ID to change your password. </div>";
            } else {
                echo 2;
            	//echo "two";
                //echo "<div class='errormsg notification'><i class='fa fa-times'></i> Unable to process your request.</div>";
            }

        } else if ($numuserqryinactive > 0) {
            echo 3;
            //echo "<div class='errormsg notification'><i class='fa fa-times'></i> This email id is inactive.</div>";
        } else {
            echo 4;
           // echo "<div class='errormsg notification'><i class='fa fa-times'></i> Invalid email id.</div>";
        }
    //exit();
    }
	//Forgott Email End//

	//Generate Link Start//
       public function getGUID() //Generate GUID - Global unique Identifier
        {
        if (function_exists('com_create_guid') === true) {
            return trim(com_create_guid(), '{}');
        }
        
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(16384, 20479), mt_rand(32768, 49151), mt_rand(0, 65535), mt_rand(0, 65535), mt_rand(0, 65535));
    }
	//Generate Link End//

}

?>