<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tags extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="errormsg notification"><i class="fa fa-times"></i> ', '</div>');
		$this->load->database();
		$this->load->model('Conference_model');
		$this->load->library('pagination');
	}

	
	public function index()
	{
		$data['message'] = $this->session->flashdata('message');
		$userid = $this->session->userdata('userid');
		$data['rowdk'] = $this->Conference_model->get_records("*","tbl_tags","status='1'","tag_name DESC","","");
		$this->load->view('tags',$data);
	}


	public function tagrelated_ques(){
		 $tagdetid = $this->uri->segment(4);
		 $tag_dei = base64_decode($tagdetid);
         $noof_rec = $this->Conference_model->noof_records("post_id","tbl_post_tags","tag_id='$tag_dei'");
       
         if($noof_rec>0){

		    $config['base_url'] = base_url().'tags/tagrelated-ques/'.$tagdetid.'/page/';
			$config['first_url'] = base_url().'tags/tagrelated-ques/'.$tagdetid;
			$config["uri_segment"] = 5;
			$config['total_rows'] = $noof_rec;
			$config['per_page'] = $this->Conference_model->per_page;
			$config["num_links"] = $this->Conference_model->num_links;
			$config["use_page_numbers"] = TRUE;
			//config for bootstrap pagination class integration
			$config['full_tag_open'] = '<ul class="pagination">';
			$config['full_tag_close'] = '</ul>';
			$config['first_link'] = "&laquo First";
			$config['last_link'] = "Last &raquo";
			$config['first_tag_open'] = '<li  class="page-item ">';
			$config['first_tag_close'] = '</li>';
			$config['prev_link'] = 'Prev';
			$config['prev_tag_open'] = '<li class="page-item">';
			$config['prev_tag_close'] = '</li>';
			$config['next_link'] = 'Next';
			$config['next_tag_open'] = '<li  class="page-item">';
			$config['next_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li  class="page-item">';
			$config['last_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="page-item active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li  class="page-item">';
			$config['num_tag_close'] = '</li>';
			$this->pagination->initialize($config);

			$page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
			$per_page = $config["per_page"];
			$startm = $page;
			if($page>1)
			$startm = $page-1;
			$startfrom = $per_page*$startm;
			$data['startfrom'] = $startfrom;


			$data['pagination'] = $this->pagination->create_links();

			$data['value'] = $this->Conference_model->get_records("*","tbl_post_tags","tag_id='$tag_dei'","tag_id DESC","$per_page","$startfrom");

			//$data['value'] = $this->Conference_model->get_records("*","tbl_post_tags","tag_id='$tag_dei'","tag_id DESC","","");

			//$data['rowdk'] = $this->Conference_model->get_records("*","tbl_posts","status='1'","post_id DESC","$per_page","$startfrom");
			  
		   

			$this->load->view('tagrelated_ques', $data);

         }else{
         	redirect(base_url().'tags','refresh');
         }
		
	}


}	